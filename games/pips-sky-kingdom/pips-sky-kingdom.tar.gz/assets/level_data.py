"""The four worlds, built from readable helper calls:
1 'Sky Kingdom', 2 'Ember Caverns' (fire), 3 'Coral Deep' (underwater), 4 'The Void'.

Coordinates are in tiles. y grows downward; the normal ground surface is
row GROUND (26). An entity placed at (tx, ty) stands with its feet on the
bottom edge of tile row ty.
"""

from settings import TILE, SMALL, ELYTRA

LEVEL_W = 262
LEVEL_H = 30
GROUND = 26


class LevelData:
    def __init__(self, rows, entities, start, checkpoints, goal,
                 autoscroll, music_zones, name="SKY KINGDOM", theme="sky", start_form=None):
        self.rows = rows
        self.entities = entities          # list of (kind, tx, ty, extra)
        self.start = start                # (tx, ty)
        self.checkpoints = checkpoints    # list of (tx, ty)
        self.goal = goal                  # (tx, ty) top-left of 2x2 Star Gate
        self.autoscroll = autoscroll      # dict(start_tx, max_ty, end_cam_x) or None
        self.music_zones = music_zones    # list of (from_tx, track)
        self.name = name
        self.theme = theme                # sky | fire | water | void: colours and background
        self.start_form = start_form      # a form Pip always (re)starts this world with


class LevelBuilder:
    def __init__(self, w, h):
        self.w, self.h = w, h
        self.grid = [[' '] * w for _ in range(h)]
        self.entities = []
        self.start = (2, GROUND - 1)
        self.checkpoints = []
        self.goal = None

    def put(self, x, y, ch):
        if 0 <= x < self.w and 0 <= y < self.h:
            self.grid[y][x] = ch

    def fill(self, x0, x1, y0, y1, ch):
        """Fill an inclusive rectangle."""
        for y in range(y0, y1 + 1):
            for x in range(x0, x1 + 1):
                self.put(x, y, ch)

    def row(self, x0, x1, y, ch):
        self.fill(x0, x1, y, y, ch)

    def ground(self, x0, x1, top=GROUND):
        self.fill(x0, x1, top, self.h - 1, 'X')

    def coins(self, x0, x1, y, step=1):
        for x in range(x0, x1 + 1, step):
            self.put(x, y, 'o')

    def pipe(self, x, top, bottom=GROUND - 1, plant=False):
        self.put(x, top, '[')
        self.put(x + 1, top, ']')
        for y in range(top + 1, bottom + 1):
            self.put(x, y, '{')
            self.put(x + 1, y, '}')
        if plant:
            self.entities.append(("snapvine", x, top, None))

    def enemy(self, kind, tx, ty=GROUND - 1, extra=None):
        self.entities.append((kind, tx, ty, extra))

    def stairs_up(self, x0, n, ch='S'):
        for i in range(n):
            self.fill(x0 + i, x0 + i, GROUND - 1 - i, GROUND - 1, ch)

    def checkpoint(self, tx, ty):
        self.checkpoints.append((tx, ty))
        self.entities.append(("checkpoint", tx, ty, len(self.checkpoints) - 1))

    def lava(self, x0, x1, top=GROUND + 1):
        """A lava pit: lava from `top` down to a rock floor on the bottom row
        (so Pip, fireproof with the yellow potion, can't sink out of the world)."""
        self.fill(x0, x1, top, self.h - 2, 'V')
        self.row(x0, x1, self.h - 1, 'S')

    def water(self, x0, x1, top, bottom=None):
        """Fill the empty tiles of an area with water (solid tiles are kept)."""
        for y in range(top, (bottom if bottom is not None else self.h - 1) + 1):
            for x in range(x0, x1 + 1):
                if 0 <= x < self.w and self.grid[y][x] in ' o':
                    if self.grid[y][x] == ' ':
                        self.grid[y][x] = '~'

    def finish(self, autoscroll, music_zones, name, theme, start_form=None):
        rows = [''.join(r) for r in self.grid]
        return LevelData(rows, self.entities, self.start, self.checkpoints, self.goal,
                         autoscroll, music_zones, name, theme, start_form)


def build_level():
    L = LevelBuilder(LEVEL_W, LEVEL_H)
    G = GROUND

    # ------------------------------------------------------------------
    # 1. Sunny Meadow (x 0-44): learn to run, jump and stomp.
    # ------------------------------------------------------------------
    L.ground(0, 44)
    L.start = (3, G - 1)
    L.put(9, G - 4, '?')
    L.put(13, G - 4, 'B')
    L.put(14, G - 4, 'M')
    L.put(15, G - 4, 'B')
    L.put(16, G - 4, '?')
    L.put(17, G - 4, 'B')
    L.put(15, G - 8, '?')
    L.enemy("nutling", 19)
    L.enemy("nutling", 24)
    L.pipe(27, G - 2, plant=True)
    L.coins(30, 32, G - 5)
    L.pipe(34, G - 3)
    L.enemy("nutling", 38)
    L.enemy("nutling", 40)
    L.put(42, G - 5, 'H')               # hidden 1-up heart
    L.coins(45, 47, G - 4)              # coins over the first gap (45-47)

    # ------------------------------------------------------------------
    # 2. Bounce Garden (x 48-71): bounce blocks; hold jump to bounce higher.
    # ------------------------------------------------------------------
    L.ground(48, 60)
    L.row(52, 54, G - 3, 'N')
    L.coins(51, 55, G - 9)              # high coins: reward for a held bounce
    L.put(57, G - 4, '?')
    L.enemy("nutling", 58)
    # bottomless pit 61-71, crossed by two bounce blocks
    L.put(63, G - 1, 'N')
    L.put(67, G - 2, 'N')
    L.coins(64, 66, G - 7)
    L.coins(68, 70, G - 7)

    # ------------------------------------------------------------------
    # 3. Toggle Ruins (x 72-99): red/blue switch puzzle.
    #    Red blocks are solid at the start. The switch at x78 turns the red
    #    wall off and the blue bridge on. The switch over the end of the blue
    #    bridge must be hit mid-jump to bring the red bridge back.
    # ------------------------------------------------------------------
    L.ground(72, 84)
    L.put(78, G - 4, 'T')
    L.fill(83, 83, G - 5, G - 1, 'R')   # red wall
    L.row(85, 91, G, 'b')               # blue bridge
    L.put(91, G - 4, 'T')               # mid-air switch
    L.row(92, 99, G, 'R')               # red bridge
    L.coins(86, 90, G - 2)
    L.coins(93, 98, G - 2)

    # ------------------------------------------------------------------
    # 4. Shell Fields (x 100-140): feather, shells, secret sky road.
    # ------------------------------------------------------------------
    L.ground(100, 158)
    L.checkpoint(103, G - 1)
    L.put(108, G - 4, 'F')
    L.put(109, G - 4, '?')
    L.put(110, G - 4, '?')
    L.enemy("shellback", 116)
    L.fill(124, 125, G - 2, G - 1, 'B')  # brick wall: kick a shell into it!
    L.put(124, G - 6, 'Q')
    L.coins(126, 129, G - 1)
    L.enemy("nutling", 128)
    L.enemy("nutling", 130)
    L.enemy("shellback", 133)
    L.pipe(137, G - 3, plant=True)
    # secret cloud road, reachable by flying with the feather
    L.row(114, 134, 13, '=')
    L.coins(115, 133, 12, step=2)
    L.put(131, 9, 'L')

    # ------------------------------------------------------------------
    # 5. Cloud Tower (x 141-159): vertical climb on one-way clouds.
    # ------------------------------------------------------------------
    L.fill(141, 141, 4, G - 4, 'S')      # left wall, entrance at the bottom
    L.fill(156, 159, 6, G - 1, 'S')      # right wall, top is the exit ledge
    L.row(150, 153, 23, '=')
    L.row(144, 147, 20, '=')
    L.row(150, 153, 17, '=')
    L.row(144, 147, 14, '=')
    L.row(150, 153, 11, '=')
    L.row(152, 155, 8, '=')
    L.coins(145, 146, 19)
    L.coins(151, 152, 16)
    L.coins(145, 146, 13)
    L.coins(151, 152, 10)
    L.enemy("flapper", 148, 18)
    L.enemy("flapper", 147, 11)
    L.checkpoint(157, 5)

    # ------------------------------------------------------------------
    # 6. Sky Bridge (x 160-214): auto-scrolling, bottomless.
    # ------------------------------------------------------------------
    L.row(163, 166, 7, '=')
    L.row(169, 171, 6, '=')
    L.row(174, 177, 8, '=')
    L.put(180, 9, 'N')
    L.row(183, 187, 6, '=')
    L.put(187, 3, 'T')                   # turns the blue platform on
    L.row(190, 195, 7, 'b')
    L.put(195, 3, 'T')                   # hit mid-jump: blue off, red on
    L.row(197, 201, 7, 'R')
    L.row(204, 207, 8, '=')
    L.row(210, 213, 9, '=')
    L.coins(164, 165, 5)
    L.coins(169, 171, 4)
    L.coins(179, 181, 4)
    L.coins(191, 194, 5)
    L.coins(198, 200, 5)
    L.enemy("platform", 170, 11, {"width": 3, "axis": "x", "range": 6, "speed": 0.02})
    L.enemy("flapper", 178, 4)
    L.enemy("flapper", 199, 4)
    L.enemy("flapper", 208, 5)

    # ------------------------------------------------------------------
    # 7. Grand Finale (x 214-261): descend, last enemies, Star Gate.
    # ------------------------------------------------------------------
    L.ground(215, 261)
    for i in range(8):
        L.fill(215 + i, 215 + i, 10 + 2 * i, G - 1, 'S')
    L.put(228, G - 4, '?')
    L.put(229, G - 4, 'M')
    L.put(230, G - 4, '?')
    L.enemy("nutling", 232)
    L.enemy("nutling", 234)
    L.enemy("nutling", 236)
    L.enemy("shellback", 239)
    L.stairs_up(242, 8)
    L.coins(251, 253, G - 6)
    L.goal = (254, G - 5)

    autoscroll = {"start_tx": 160, "max_ty": 12, "end_cam_x": 224 * TILE - 320}
    music_zones = [(0, "main"), (141, "sky"), (214, "main")]
    return L.finish(autoscroll, music_zones, "SKY KINGDOM", "sky")


def build_fire():
    """World 2 'Ember Caverns': lava pits and leaping cinders. The yellow potion
    (first block) makes lava safe: swim through it to the hidden lava treasure."""
    L = LevelBuilder(200, LEVEL_H)
    G = GROUND
    L.fill(0, 199, 0, 1, 'S')                # cave ceiling

    # 1. Cave mouth (x 0-30): the yellow potion
    L.ground(0, 30)
    L.start = (3, G - 1)
    L.put(8, G - 4, 'Y')
    L.put(9, G - 4, '?')
    L.put(10, G - 4, 'B')
    L.enemy("nutling", 16)
    L.enemy("nutling", 22)
    L.coins(25, 28, G - 4)

    # 2. Lava Steps (x 31-52): small pits, cinders leap out of them
    L.lava(31, 33)
    L.enemy("cinder", 32, G + 1)
    L.ground(34, 40)
    L.fill(37, 38, G - 2, G - 1, 'S')
    L.lava(41, 43)
    L.enemy("cinder", 42, G + 1)
    L.ground(44, 52)
    L.put(47, G - 4, '?')
    L.put(48, G - 4, 'M')
    L.put(49, G - 4, '?')
    L.enemy("nutling", 51)

    # 3. Lava Lake (x 53-72): hop the stone stepping stones... or, with the
    #    yellow potion, swim through the lava for the coins and the heart
    L.lava(53, 72, G)
    for x in (55, 60, 65, 70):
        L.fill(x, x + 1, G - 2, L.h - 1, 'S')
    L.coins(57, 59, G + 1)                   # deep in the lava
    L.coins(67, 69, G + 1)
    L.put(63, G + 1, 'L')                    # lava treasure: hit this heart block from below
    L.row(62, 64, L.h - 1, 'S')
    L.enemy("cinder", 58, G + 1)
    L.enemy("cinder", 68, G + 1)

    # 4. Basalt Halls (x 73-130): bricks, shells, and narrow pits
    L.ground(73, 110)
    L.checkpoint(76, G - 1)
    L.stairs_up(82, 3)
    L.fill(85, 89, G - 3, G - 1, 'S')
    L.enemy("nutling", 92)
    L.enemy("nutling", 95)
    L.put(98, G - 4, 'B')
    L.put(99, G - 4, '?')
    L.put(100, G - 4, 'B')
    L.enemy("shellback", 104)
    L.fill(108, 109, G - 2, G - 1, 'B')
    L.lava(111, 113)
    L.enemy("cinder", 112, G + 1)
    L.ground(114, 130)
    L.put(118, G - 4, 'M')
    L.enemy("nutling", 122)
    L.enemy("shellback", 126)

    # 5. Fire Bridge (x 131-170): stone pillars over a long lava pit
    L.lava(131, 160, G)
    for x in (134, 139, 144, 149, 154, 158):
        L.fill(x, x + 1, G - 1 - (x % 3), L.h - 1, 'S')
    L.coins(134, 159, G - 6, step=5)
    L.enemy("cinder", 137, G)
    L.enemy("cinder", 147, G)
    L.enemy("cinder", 156, G)
    L.ground(161, 199)
    L.checkpoint(163, G - 1)

    # 6. The Gate (x 165-199)
    L.enemy("nutling", 170)
    L.enemy("nutling", 173)
    L.stairs_up(178, 6)
    L.coins(185, 187, G - 7)
    L.goal = (190, G - 5)
    return L.finish(None, [(0, "fire")], "EMBER CAVERNS", "fire")


def build_water():
    """World 3 'Coral Deep': swim (hold jump to rise). Keep an eye on the AIR
    meter in the rock tunnels; the water potion on the beach stops drowning."""
    L = LevelBuilder(232, LEVEL_H)
    G = GROUND
    S = 12                                   # the water's surface row

    # 1. Beach (x 0-11), then the open sea
    L.fill(0, 11, S, L.h - 1, 'X')
    L.start = (3, S - 1)
    L.put(6, S - 4, 'P')                     # water potion block
    L.put(8, S - 4, '?')
    L.ground(12, 219)                        # the sea floor
    L.fill(20, 23, G - 4, G - 1, 'S')        # coral rocks
    L.fill(30, 31, G - 7, G - 1, 'S')
    L.coins(30, 31, G - 9)
    L.enemy("jelly", 26, G - 6)
    L.fill(40, 44, G - 3, G - 1, 'S')
    L.put(42, G - 7, '?')
    L.put(43, G - 7, 'M')
    L.enemy("jelly", 48, G - 5)
    L.enemy("jelly", 53, G - 8)

    # 2. The first tunnel (x 60-90): a rock roof, so no air until the end
    L.fill(60, 90, S, 18, 'S')
    L.coins(63, 87, 21, step=3)
    L.fill(70, 71, G - 3, G - 1, 'S')
    L.fill(80, 81, G - 3, G - 1, 'S')
    L.enemy("jelly", 75, G - 2)
    L.enemy("jelly", 85, G - 3)

    # 3. Kelp Garden (x 91-118): open water to breathe, checkpoint
    L.checkpoint(96, G - 1)
    L.fill(102, 104, G - 5, G - 1, 'S')
    L.fill(110, 112, G - 8, G - 1, 'S')
    L.coins(110, 112, G - 10)
    L.enemy("jelly", 107, G - 9)
    L.enemy("jelly", 115, G - 4)

    # 4. The long tunnel (x 120-176) with one air pocket in the middle (x 146-150)
    L.fill(120, 176, S, 17, 'S')
    L.fill(146, 150, 14, 17, ' ')            # air pocket inside the rock
    L.coins(146, 150, 16)
    L.fill(128, 129, G - 4, G - 1, 'S')
    L.fill(138, 140, G - 3, G - 1, 'S')
    L.fill(158, 159, G - 5, G - 1, 'S')
    L.fill(168, 170, G - 3, G - 1, 'S')
    L.enemy("jelly", 134, G - 4)
    L.enemy("jelly", 155, G - 2)
    L.enemy("jelly", 164, G - 6)
    L.checkpoint(180, G - 1)

    # 5. Back to the shore (x 185-231): the sea floor rises to the beach
    for i in range(7):
        L.fill(188 + 2 * i, 189 + 2 * i, G - 2 * i - 1, L.h - 1, 'S')
    L.fill(202, 231, S, L.h - 1, 'X')
    L.water(12, 201, S, G - 1)
    L.fill(146, 150, 14, 15, ' ')            # keep the air in the pocket (water starts at row 16)
    L.coins(206, 209, S - 4)
    L.enemy("nutling", 212, S - 1)
    L.goal = (220, S - 5)
    return L.finish(None, [(0, "water")], "CORAL DEEP", "water")


def build_void():
    """World 4 'The Void': floating islands over nothing. Pip has the elytra:
    hold jump in the air to fly (same meter as the feather) and glide far."""
    L = LevelBuilder(220, LEVEL_H)

    def island(x0, x1, top, depth=2):
        L.fill(x0, x1, top, top + depth - 1, 'S')

    island(0, 9, 20, 3)
    L.start = (3, 19)
    L.put(6, 16, '?')
    island(22, 28, 18)
    L.coins(14, 19, 15)
    L.enemy("flapper", 25, 14)
    island(40, 46, 21)
    L.put(43, 17, 'E')                       # a spare elytra
    L.coins(32, 37, 17)
    island(56, 61, 14)                       # a climb: fly up!
    L.enemy("flapper", 52, 13)
    island(74, 82, 17, 3)
    L.checkpoint(76, 16)
    L.put(80, 13, 'L')                       # a heart (an Ember Berry here would swap the elytra away)
    L.coins(64, 71, 12)
    island(96, 100, 12)
    L.enemy("flapper", 90, 10)
    island(112, 118, 19)
    L.enemy("flapper", 106, 15)
    island(130, 136, 15)
    L.put(133, 11, 'E')
    island(150, 158, 18, 3)
    L.checkpoint(152, 17)
    L.coins(140, 147, 12)
    island(172, 176, 13)
    L.enemy("flapper", 166, 10)
    island(188, 219, 16, 4)
    L.enemy("nutling", 194, 15)
    L.coins(198, 202, 11)
    L.goal = (208, 11)
    return L.finish(None, [(0, "void")], "THE VOID", "void", start_form=ELYTRA)


def build_levels():
    return [build_level(), build_fire(), build_water(), build_void()]
