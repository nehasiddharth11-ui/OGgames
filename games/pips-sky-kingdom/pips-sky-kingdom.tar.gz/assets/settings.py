"""Global constants for Pip's Sky Kingdom: Mark 3."""

GAME_TITLE = "Pip's Sky Kingdom: Mark 3"

# Internal (pixel-art) resolution. The window is scaled up by SDL.
SCREEN_W = 320
SCREEN_H = 240
TILE = 16
FPS = 60
WORLD_ZOOM = 1.0            # the starting zoom (phones start at 1.5); players change it in Settings

# Player forms
SMALL, BIG, FIRE, FEATHER, ELYTRA = 0, 1, 2, 3, 4
FLYING_FORMS = (FEATHER, ELYTRA)

# ---------------------------------------------------------------------------
# Player physics (pixels per frame at 60 FPS)
# ---------------------------------------------------------------------------
PLAYER_W = 12
SMALL_H = 14
BIG_H = 26

WALK_MAX = 1.5
RUN_MAX = 2.5
WALK_ACCEL = 0.055
RUN_ACCEL = 0.075
AIR_CONTROL = 0.85          # fraction of ground acceleration available in the air
SKID_DECEL = 0.40           # turning around on the ground: a short skid (Mark 1/2: 0.17)
AIR_TURN = 0.18             # turning around in the air (Mark 1/2: 0.11)
FRICTION = 0.07
AIR_FRICTION = 0.015

GRAVITY = 0.6               # normal / jump released
GRAVITY_HOLD = 0.21         # while rising with jump held -> variable jump height
MAX_FALL = 4.8
JUMP_BASE = 4.7
JUMP_RUN_BONUS = 0.28       # faster run -> higher jump
COYOTE_FRAMES = 6           # can still jump shortly after leaving a ledge
JUMP_BUFFER_FRAMES = 7      # jump pressed slightly before landing still counts

STOMP_BOUNCE_LO = 3.6
STOMP_BOUNCE_HI = 5.4
NOTE_BOUNCE = 6.2           # big bounce when jump is held as Pip lands on a bounce block

PMETER_MAX = 50             # frames at top speed before the run meter is full
GLIDE_FALL = 0.9

INVULN_FRAMES = 120

# ---------------------------------------------------------------------------
# Game rules
# ---------------------------------------------------------------------------
AUTOSCROLL_SPEED = 0.75
START_LIVES = 5
LEVEL_TIME = 300
HARD_LANDING = 64           # a drop of more than 4 tiles...
HARD_IMPACT = 3.5           # ...hitting the ground this fast: thud + dust

# ---------------------------------------------------------------------------
# Potions (mutations) and breathing
# ---------------------------------------------------------------------------
FIRE_POTION_FRAMES = 150 * FPS      # yellow potion: can't be burnt for 2.5 minutes
WATER_POTION_FRAMES = 300 * FPS     # water potion: can't drown for 5 minutes
AIR_MAX = 20 * FPS                  # 20 seconds of air under water
AIR_REFILL = 6                      # air comes back 6x faster above water

# ---------------------------------------------------------------------------
# Swimming (water, and lava with the yellow potion)
# ---------------------------------------------------------------------------
SWIM_MAX = 1.3              # top swimming speed left / right
SWIM_ACCEL = 0.05
SWIM_FRICTION = 0.03
SWIM_RISE = 1.4             # holding jump swims up at this speed
SWIM_SINK = 0.8             # letting go sinks at this speed
SWIM_STROKE = 2.2           # each press of jump: a quick stroke upward
SWIM_EXIT = 4.2             # a stroke at the surface hops out of the water
