"""The player's settings: display, audio, key / controller bindings and the touch layout.
Saved as settings.json next to the game. Anything missing or broken in that file
simply falls back to its default, so a bad file can never stop the game starting."""

import copy
import json
import os

import pygame

# ---- every action that can be rebound: (id, name shown in the menu) ----
KEY_ACTIONS = (("left", "MOVE LEFT"), ("right", "MOVE RIGHT"), ("up", "MENU UP"), ("down", "MENU DOWN"),
               ("jump", "JUMP"), ("long_jump", "LONG JUMP"), ("run", "RUN"), ("attack", "ATTACK"), ("pause", "PAUSE"),
               ("mute", "MUTE"), ("fullscreen", "FULLSCREEN"))
PAD_ACTIONS = KEY_ACTIONS[:9]
MAX_SLOTS = 4

# One button may do both of these jobs (everything else moves the button to its new job)
SHARE_OK = ({"run", "attack"}, {"up", "jump"})

# Mouse buttons are stored among the keyboard keys as negative numbers
MOUSE_LEFT, MOUSE_RIGHT = -1, -3
MOUSE_NAMES = {-1: "LMB", -2: "MMB", -3: "RMB", -6: "M4", -7: "M5"}
MOUSE_BIND_BUTTONS = (1, 2, 3, 6, 7)

# ---- the default controls ----
DEFAULT_KEYS = {
    "left": [pygame.K_LEFT, pygame.K_a],
    "right": [pygame.K_RIGHT, pygame.K_d],
    "up": [pygame.K_UP, pygame.K_w],
    "down": [pygame.K_DOWN, pygame.K_s],
    "jump": [MOUSE_LEFT, pygame.K_UP, pygame.K_z, pygame.K_SPACE],    # hold = higher
    "long_jump": [MOUSE_RIGHT],                                     # always the full height
    "run": [pygame.K_LCTRL, pygame.K_q, pygame.K_f, pygame.K_LSHIFT],
    "attack": [pygame.K_x, pygame.K_LSHIFT, pygame.K_RSHIFT, pygame.K_j],
    "pause": [pygame.K_RETURN, pygame.K_ESCAPE, pygame.K_p],
    "mute": [pygame.K_m],
    "fullscreen": [pygame.K_F11],
}
DEFAULT_PAD = {
    "left": ["dleft", "ls_left"],
    "right": ["dright", "ls_right"],
    "up": ["dup", "ls_up"],
    "down": ["ddown", "ls_down"],
    "jump": ["a", "dup", "b"],
    "long_jump": [],
    "run": ["l1", "x", "y"],
    "attack": ["r1", "x", "y"],
    "pause": ["start"],
}
# PS4 names, at most 6 letters so they fit on a keybind button
PAD_NAMES = {
    "a": "CROSS", "b": "CIRCLE", "x": "SQUARE", "y": "TRI",
    "l1": "L1", "r1": "R1", "l2": "L2", "r2": "R2", "l3": "L3", "r3": "R3",
    "start": "OPTION", "back": "SHARE",
    "dup": "D-UP", "ddown": "D-DOWN", "dleft": "D-LEFT", "dright": "D-RGHT",
    "ls_up": "LS-UP", "ls_down": "LS-DWN", "ls_left": "LS-L", "ls_right": "LS-R",
    "rs_up": "RS-UP", "rs_down": "RS-DWN", "rs_left": "RS-L", "rs_right": "RS-R",
}
# Touch layout on the 320x240 screen: [x, y, size]. Joystick on the left, jump on the
# right, the run toggle right above jump.
DEFAULT_TOUCH = {
    "stick": [48, 188, 1.0],
    "jump": [276, 194, 1.0],
    "run": [276, 144, 1.0],
    "attack": [226, 206, 1.0],
    "pause": [160, 34, 1.0],
}
QUALITIES = ("LOW", "MEDIUM", "HIGH")
DEFAULTS = {
    "brightness": 100, "quality": "HIGH", "fullscreen": False, "scanlines": False, "show_fps": False,
    "master": 100, "music": 100, "sfx": 100, "muted": False,
    "run_mode": "HOLD", "auto_pause": True,
    "deadzone": 35,
    "touch_mode": "AUTO", "touch_opacity": 60,
    "keys": DEFAULT_KEYS, "pad": DEFAULT_PAD, "touch": DEFAULT_TOUCH,
}
RANGES = {"brightness": (50, 150), "master": (0, 100), "music": (0, 100), "sfx": (0, 100),
          "deadzone": (10, 80), "touch_opacity": (20, 100)}
CHOICES = {"quality": QUALITIES, "run_mode": ("HOLD", "TOGGLE"), "touch_mode": ("AUTO", "ON", "OFF")}
SWITCHES = ("fullscreen", "scanlines", "show_fps", "muted", "auto_pause")

_KEY_NAMES = {
    pygame.K_LSHIFT: "LSHIFT", pygame.K_RSHIFT: "RSHIFT", pygame.K_LCTRL: "LCTRL", pygame.K_RCTRL: "RCTRL",
    pygame.K_LALT: "LALT", pygame.K_RALT: "RALT", pygame.K_RETURN: "ENTER", pygame.K_ESCAPE: "ESC",
    pygame.K_SPACE: "SPACE", pygame.K_BACKSPACE: "BKSP", pygame.K_DELETE: "DEL", pygame.K_INSERT: "INS",
    pygame.K_PAGEUP: "PGUP", pygame.K_PAGEDOWN: "PGDN", pygame.K_CAPSLOCK: "CAPS",
    pygame.K_SEMICOLON: "SEMI", pygame.K_LEFTBRACKET: "LBRACK", pygame.K_RIGHTBRACKET: "RBRACK",
    pygame.K_BACKSLASH: "BSLASH", pygame.K_BACKQUOTE: "TILDE", pygame.K_KP_ENTER: "KPENT",
}


def key_label(code):
    """A short name for a keyboard key, only using letters the pixel font can draw."""
    if code < 0:
        return MOUSE_NAMES.get(code, "MOUSE")
    if code in _KEY_NAMES:
        return _KEY_NAMES[code]
    name = pygame.key.name(code).upper().replace(" ", "")
    if name and len(name) <= 6 and all(c.isalnum() or c in "',.-/=" for c in name):
        return name
    return f"K{code}"[:6]


def label(device, token):
    return key_label(token) if device == "keys" else PAD_NAMES.get(token, str(token).upper()[:6])


class Options(dict):
    def __init__(self, path=None):
        super().__init__(copy.deepcopy(DEFAULTS))
        self.path = path
        if path:
            self._load()

    # ---- load / save ----------------------------------------------------
    def _load(self):
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except (OSError, ValueError):
            return
        if not isinstance(data, dict):
            return
        for key, (lo, hi) in RANGES.items():
            value = data.get(key)
            if isinstance(value, (int, float)) and not isinstance(value, bool):
                self[key] = max(lo, min(hi, int(value)))
        for key, allowed in CHOICES.items():
            if data.get(key) in allowed:
                self[key] = data[key]
        for key in SWITCHES:
            if isinstance(data.get(key), bool):
                self[key] = data[key]
        self._load_binds("keys", data.get("keys"), lambda t: isinstance(t, int) and not isinstance(t, bool))
        self._load_binds("pad", data.get("pad"), lambda t: t in PAD_NAMES)
        self._load_touch(data.get("touch"))

    def _load_binds(self, device, saved, valid):
        if not isinstance(saved, dict):
            return
        for action in self[device]:
            tokens = saved.get(action)
            if isinstance(tokens, list):
                unique = []
                for t in tokens:
                    if valid(t) and t not in unique:
                        unique.append(t)
                self[device][action] = unique[:MAX_SLOTS]

    def _load_touch(self, saved):
        if not isinstance(saved, dict):
            return
        for name in self["touch"]:
            v = saved.get(name)
            if (isinstance(v, list) and len(v) == 3
                    and all(isinstance(n, (int, float)) and not isinstance(n, bool) for n in v)):
                self["touch"][name] = [float(v[0]), float(v[1]), max(0.6, min(1.6, float(v[2])))]

    def save(self):
        """Write to a temporary file first, so a crash can't leave a half-written settings file."""
        if not self.path:
            return
        tmp = self.path + ".tmp"
        try:
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(self, f, indent=1)
            os.replace(tmp, self.path)
        except OSError:
            pass

    def reset(self, *keys):
        """Back to the defaults: the named settings, or all of them."""
        for key in keys or tuple(DEFAULTS):
            self[key] = copy.deepcopy(DEFAULTS[key])

    # ---- rebinding --------------------------------------------------------
    def bind(self, device, action, slot, token):
        """Put a key/button on an action. If another action was using it, it moves
        here, and that action's name is returned so the menu can say so."""
        table = self[device]
        moved_from = None
        for other, tokens in table.items():
            if other != action and token in tokens and {action, other} not in SHARE_OK:
                tokens.remove(token)
                moved_from = other
        tokens = table[action]
        if token in tokens:
            tokens.remove(token)
        if slot < len(tokens):
            tokens[slot] = token
        else:
            tokens.append(token)
        del tokens[MAX_SLOTS:]
        return moved_from

    def clear_bind(self, device, action, slot):
        tokens = self[device][action]
        if slot < len(tokens):
            del tokens[slot]
