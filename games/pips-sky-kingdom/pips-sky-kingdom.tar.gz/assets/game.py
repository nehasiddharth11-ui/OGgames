"""Game states, player logic, camera, rendering and HUD (Pip's Sky Kingdom: Mark 3)."""

import json
import math
import os
import random
import sys

import pygame

from settings import *
from physics import PlayerBody, step_player, move_body, unstick, FLY_MAX
from world import World
from level_data import build_levels
from assets import Assets
from audio import Audio
from controls import Controls
from options import Options, DEFAULT_KEYS, DEFAULT_PAD, MOUSE_BIND_BUTTONS, label
from pixfont import PixelFont
from settings_menu import SettingsMenu
from touch import TouchControls
from entities import (Item, CoinPop, Fireball, Platform, Goal, Shellback,
                      BrickShard, Sparkle, Dust, LandDust, ScorePopup, Puff, Bubble, spawn_from_level)

FLY_BARS = 10
FLY_BAR_FRAMES = FLY_MAX // FLY_BARS          # meter units per bar (0.4 s of flight)

WHITE = (255, 255, 255)
YELLOW = (255, 220, 90)
SKY_BLUE = (140, 220, 255)
SOFT = (220, 230, 255)

# the colour of the dust when Pip lands on each kind of ground (grass gives dirt dust)
GROUND_COLOURS = {
    'X': (196, 124, 70), 'S': (170, 170, 190), 'B': (206, 96, 46), 'Q': (206, 96, 46),
    'U': (150, 100, 60), '?': (250, 190, 60), 'M': (250, 190, 60), 'F': (250, 190, 60),
    'L': (250, 190, 60), 'R': (232, 60, 60), 'b': (60, 120, 240), 'T': (240, 240, 250),
    '[': (40, 176, 168), ']': (40, 176, 168), '{': (40, 176, 168), '}': (40, 176, 168),
    '=': (235, 242, 255), 'Y': (250, 190, 60), 'P': (250, 190, 60), 'E': (250, 190, 60),
}
# each world's own ground and stone colours for the landing dust
THEME_DUST = {
    "fire": {'X': (110, 60, 50), 'S': (96, 70, 70)},
    "water": {'X': (214, 186, 120), 'S': (226, 120, 140)},
    "void": {'X': (70, 44, 110), 'S': (100, 70, 160)},
}

TITLE_ITEMS = ("START GAME", "SETTINGS", "ABOUT", "QUIT GAME")
PAUSE_ITEMS = ("RESUME", "SETTINGS", "ABOUT", "QUIT TO TITLE")
TITLE_MENU_Y, TITLE_MENU_STEP = 178, 10
PAUSE_MENU_Y, PAUSE_MENU_STEP = 156, 10
COSMETIC = (Dust, LandDust, Sparkle, Bubble, Puff)      # effects the graphics setting may thin out
QUALITY_DETAIL = {"HIGH": 1.0, "MEDIUM": 0.5, "LOW": 0.0}
ABOUT_PAGES = 3
ITEM_BLOCKS = "MFLHYPE"         # blocks that release an item when hit


def save_folder():
    """The high score lives next to the game: beside the .exe, or the project folder."""
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


class Player(PlayerBody):
    def __init__(self, x, y, form):
        super().__init__(x, y, form)
        self.invuln = 0
        self.dying = False
        self.death_timer = 0
        self.anim = 0.0
        self.riding = None
        self.spin = 0
        self.transform = 0
        self.old_form = form
        self.combo = 0
        self.peak_y = y          # highest point since leaving the ground (hard landings)

    def set_form(self, form):
        old_h = self.h
        self.old_form = self.form
        self.form = form
        self.h = SMALL_H if form == SMALL else BIG_H
        self.y += old_h - self.h


class Game:
    def __init__(self, screen):
        self.screen = screen
        self.clock = pygame.time.Clock()
        # Everything, text included, is drawn on the pixel-art canvas with the
        # retro pixel font, then scaled up to the window with sharp pixels.
        self.canvas = pygame.Surface((SCREEN_W, SCREEN_H))
        self.pixfont = PixelFont()
        self.font = 1               # text scales: 1 = 8 px tall, 3 = 24 px tall
        self.small_font = 1
        self.big_font = 3
        self.canvas.fill((0, 0, 0))
        self._center_text("LOADING...", 116, self.font)
        self.present()

        self.assets = Assets()
        self.audio = Audio()
        self.options = Options(os.path.join(save_folder(), "settings.json"))
        self.touch = TouchControls(self.options)
        self.controls = Controls(self.options, self.touch)
        self.is_fullscreen = False
        self.scanline_img = None
        self.tap = None                 # a mouse click / finger tap waiting for the menus
        self.settings_from = "title"
        self.settings_menu = SettingsMenu(self)
        self.apply_options()
        self.levels = build_levels()
        self.level_index = 0
        self.level = self.levels[0]
        self.hills = self._make_hills()
        self.frame = 0
        self.state = "title"
        self.lives = START_LIVES
        self.score = 0
        self.coins = 0
        self.running = True
        self.title_sel = self.pause_sel = self.about_page = 0
        self.about_from = "title"
        self.quit_confirm = False
        self.hs_path = os.path.join(save_folder(), "highscore.dat")
        self.high_score, self.wins = self._load_save()
        self.saved = (self.high_score, self.wins)
        self.game_start_high = self.high_score
        self.fire_safe = self.water_safe = 0       # potion timers, in frames
        self.air = AIR_MAX
        self._setup_world(start=True)
        self.audio.play_music("main")

    # ==================================================================
    # High score and win counter (both saved in highscore.dat)
    # ==================================================================
    def _load_save(self):
        try:
            with open(self.hs_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            hs = max(0, min(int(data.get("high_score", 0)), 9999999))
            wins = max(0, min(int(data.get("wins", 0)), 9999))
            return hs, wins
        except (OSError, ValueError, AttributeError, TypeError):
            return 0, 0

    def save_high_score(self):
        if (self.high_score, self.wins) == self.saved:
            return
        self.saved = (self.high_score, self.wins)    # try once per change
        try:
            with open(self.hs_path, "w", encoding="utf-8") as f:
                json.dump({"high_score": self.high_score, "wins": self.wins}, f)
        except OSError:
            pass

    # ==================================================================
    # Setup
    # ==================================================================
    def new_game(self):
        self.game_start_high = self.high_score
        self.lives = START_LIVES
        self.score = 0
        self.coins = 0
        self.checkpoint = -1
        self.carry_form = SMALL
        self.fire_safe = self.water_safe = 0
        self.level_index = 0
        self.level = self.levels[0]
        self._setup_world()
        self.state = "playing"

    def next_world(self):
        """On to the next world, keeping score, lives, power-up and potions."""
        self.level_index += 1
        self.level = self.levels[self.level_index]
        self.checkpoint = -1
        self.carry_form = self.player.form
        self._setup_world()
        self.state = "playing"

    def _setup_world(self, start=False):
        if start:
            self.checkpoint = -1
            self.carry_form = SMALL
            self.level_index = 0
            self.level = self.levels[0]
        lv = self.level
        self.world = World(lv.rows)
        self.entities = []
        self.particles = []
        self.bumps = {}
        self.qcoins = {}
        for kind, tx, ty, extra in lv.entities:
            e = spawn_from_level(kind, tx, ty, extra)
            if kind == "checkpoint" and extra <= self.checkpoint:
                e.reached = True
            self.entities.append(e)
        self.goal = Goal(*lv.goal)
        self.entities.append(self.goal)

        if self.checkpoint >= 0:
            sx, sy = lv.checkpoints[self.checkpoint]
        else:
            sx, sy = lv.start
        form = lv.start_form if lv.start_form is not None else self.carry_form
        self.player = Player(0, 0, form)
        self.player.x = sx * TILE + (TILE - self.player.w) / 2
        self.player.y = (sy + 1) * TILE - self.player.h
        self.player.peak_y = self.player.y
        self.player.was_swimming = None
        self.air = AIR_MAX
        self.time_left = LEVEL_TIME * FPS
        self.autoscroll = "idle"
        self.cam_x = max(0, min(self.player.x - SCREEN_W / 2, self.world.pixel_w - SCREEN_W))
        self.cam_y = max(0, min(self.player.y - 140, self.world.pixel_h - SCREEN_H))
        self.clear_timer = 0
        self.clear_icon = None
        # "WORLD 2  EMBER CAVERNS" when a world starts from the beginning
        self.banner = 150 if not start and self.checkpoint < 0 else 0
        self.music_for_position(force=True)

    def music_for_position(self, force=False):
        tx = (self.player.x + self.player.w / 2) / TILE
        zones = self.level.music_zones
        track = zones[0][1]
        for start, name in zones:
            if tx >= start:
                track = name
        if force or self.audio.current in [n for _, n in zones] + [None]:
            self.audio.play_music(track)

    # ==================================================================
    # Main loop
    # ==================================================================
    def run(self):
        step = 1.0 / FPS
        acc = 0.0
        while self.running:
            dt = self.clock.tick(240) / 1000.0
            if abs(dt - step) < 0.002:
                dt = step
            acc = min(acc + dt, step * 5)
            for e in pygame.event.get():
                if e.type == pygame.QUIT:
                    self.running = False
                elif e.type == pygame.KEYDOWN and self.state == "settings":
                    self.settings_menu.on_key(e.key)
                elif e.type == pygame.WINDOWFOCUSLOST:
                    self.touch.release_all()
                    self.controls.mouse_clear()
                    if self.options["auto_pause"] and self.state == "playing" and not self.player.dying:
                        self.pause_game()
                self.controls.handle_event(e)
                self.handle_pointer(e)
            while acc >= step and self.running:
                self.update()
                acc -= step
            self.draw()
            self.present()
        self.save_high_score()
        self.options.save()

    # ==================================================================
    # Settings, mouse and touch
    # ==================================================================
    def apply_options(self):
        """Make the current settings take effect (called whenever one changes)."""
        o = self.options
        self.audio.set_volumes(o["master"], o["music"], o["sfx"])
        if self.audio.muted != o["muted"]:
            self.audio.toggle_mute()
        if self.is_fullscreen != o["fullscreen"]:
            try:
                pygame.display.toggle_fullscreen()
                self.is_fullscreen = o["fullscreen"]
            except pygame.error:
                o["fullscreen"] = self.is_fullscreen

    def open_settings(self, came_from):
        self.settings_from = came_from
        self.settings_menu.row = -1
        self.state = "settings"
        if came_from == "paused":
            self.audio.pause_music(False)   # so a change of music volume can be heard
        self.audio.play("pause")

    def close_settings(self):
        self.state = self.settings_from
        if self.state == "paused":
            self.audio.pause_music(True)

    def pause_game(self):
        self.state = "paused"
        self.pause_sel = 0
        self.audio.pause_music(True)
        self.audio.play("pause")

    def _mouse_to_canvas(self, pos):
        sw, sh = self.screen.get_size()
        return pos[0] * SCREEN_W / sw, pos[1] * SCREEN_H / sh

    def _finger_to_canvas(self, fx, fy):
        """Fingers report a fraction of the window, which may have black bars around the game."""
        ww, wh = pygame.display.get_window_size()
        sw, sh = self.screen.get_size()
        scale = min(ww / sw, wh / sh)
        x = (fx * ww - (ww - sw * scale) / 2) / scale
        y = (fy * wh - (wh - sh * scale) / 2) / scale
        return x * SCREEN_W / sw, y * SCREEN_H / sh

    def handle_pointer(self, e):
        """Turn mouse and finger events into presses of the on-screen buttons and menus."""
        t = e.type
        if t == pygame.FINGERDOWN:
            self.touch.finger_seen = True
            self.pointer("down", e.finger_id, *self._finger_to_canvas(e.x, e.y))
        elif t == pygame.FINGERMOTION:
            self.pointer("move", e.finger_id, *self._finger_to_canvas(e.x, e.y))
        elif t == pygame.FINGERUP:
            self.pointer("up", e.finger_id, *self._finger_to_canvas(e.x, e.y))
        elif getattr(e, "touch", False):
            return                          # the system's copy of a finger event, already handled
        elif t == pygame.MOUSEBUTTONDOWN and self.mouse_button_down(e):
            pass
        elif t == pygame.MOUSEBUTTONDOWN and e.button == 1:
            self.pointer("down", "mouse", *self._mouse_to_canvas(e.pos))
        elif t == pygame.MOUSEMOTION and e.buttons[0]:
            self.pointer("move", "mouse", *self._mouse_to_canvas(e.pos))
        elif t == pygame.MOUSEBUTTONUP:
            self.controls.mouse_release(e.button)
            if e.button == 1:
                self.pointer("up", "mouse", *self._mouse_to_canvas(e.pos))

    def mouse_button_down(self, e):
        """Returns True if the click was used up: being bound to an action, or
        pressing a mouse button other than left during play."""
        menu = self.settings_menu
        if self.state == "settings" and menu.listen and menu.listen["device"] == "keys":
            if e.button in MOUSE_BIND_BUTTONS:
                menu.on_key(-e.button)
            return True
        if self.state == "playing" and e.button != 1:
            self.controls.mouse_press(e.button)
            return True
        return False

    def pointer(self, what, pid, x, y):
        menu = self.settings_menu
        if self.state == "settings" and menu.editing:
            if what == "down":
                menu.editor_down(pid, x, y)
            elif what == "move":
                menu.editor_move(pid, x, y)
            else:
                menu.editor_up(pid)
        elif what == "up":
            self.touch.up(pid)
        elif what == "move":
            self.touch.move(pid, x, y)
        elif self.state == "playing":
            on_button = self.touch.active() and self.touch.down(pid, x, y)
            if pid == "mouse" and not on_button:
                self.controls.mouse_press(1)
        else:
            self.tap = (int(x), int(y))

    @staticmethod
    def menu_hit(tap, y0, step, count):
        """Which row of a centred menu was tapped, or None."""
        if tap and 60 <= tap[0] < SCREEN_W - 60 and tap[1] >= y0 - 2:
            i = (tap[1] - y0 + 2) // step
            if i < count:
                return i
        return None

    def limit_particles(self):
        """The graphics setting: fewer dust and sparkle effects on medium, none on low."""
        quality = self.options["quality"]
        if quality == "HIGH":
            return
        allow = 10 if quality == "MEDIUM" else 0
        cosmetic = [pt for pt in self.particles if isinstance(pt, COSMETIC)]
        if len(cosmetic) > allow:
            drop = set(map(id, cosmetic[:len(cosmetic) - allow]))
            self.particles = [pt for pt in self.particles if id(pt) not in drop]

    def title_camera(self):
        self.title_scroll = getattr(self, "title_scroll", 0) + 0.5
        self.cam_x = (self.title_scroll % (100 * TILE))
        self.cam_y = self.world.pixel_h - SCREEN_H

    def menu_move(self, inp, sel, count):
        if inp.up_pressed:
            sel = (sel + count - 1) % count
            self.audio.play("tick")
        if inp.down_pressed:
            sel = (sel + 1) % count
            self.audio.play("tick")
        return sel

    def open_about(self, came_from):
        self.about_from = came_from
        self.about_page = 0
        self.state = "about"
        self.audio.play("pause")

    def update(self):
        self.update_state()
        self.limit_particles()

    def update_state(self):
        self.frame += 1
        self.controls.in_play = self.state == "playing"
        inp = self.controls.poll()
        tap, self.tap = self.tap, None
        if inp.mute_pressed:
            self.options["muted"] = not self.options["muted"]
            self.apply_options()
        if inp.fullscreen_pressed:
            self.options["fullscreen"] = not self.options["fullscreen"]
            self.apply_options()
        if self.state != "playing":
            inp.for_menus()
            self.touch.release_all()
            self.controls.mouse_clear()
            if tap and self.state in ("clear", "win", "gameover"):
                inp.jump_pressed = True
        if self.score > self.high_score:
            self.high_score = self.score
        if self.state == "title":
            self.title_camera()
            if self.quit_confirm:
                # "QUIT THE GAME?"  jump or a tap on the left = yes, Enter / Options / attack = no
                if inp.jump_pressed or (tap and tap[0] < SCREEN_W // 2):
                    self.save_high_score()
                    self.running = False
                elif tap or inp.start_pressed or inp.attack_pressed:
                    self.quit_confirm = False
                    self.audio.play("pause")
                return
            self.title_sel = self.menu_move(inp, self.title_sel, len(TITLE_ITEMS))
            chosen = inp.jump_pressed or inp.enter_pressed or (inp.start_pressed and self.title_sel == 0)
            hit = self.menu_hit(tap, TITLE_MENU_Y, TITLE_MENU_STEP, len(TITLE_ITEMS))
            if hit is not None:
                self.title_sel = hit
                chosen = True
            if chosen and self.title_sel == 0:
                self.new_game()
            elif chosen and self.title_sel == 1:
                self.open_settings("title")
            elif chosen and self.title_sel == 2:
                self.open_about("title")
            elif chosen and self.title_sel == 3:
                self.quit_confirm = True
                self.audio.play("pause")
        elif self.state == "paused":
            self.pause_sel = self.menu_move(inp, self.pause_sel, len(PAUSE_ITEMS))
            chosen = inp.jump_pressed or inp.enter_pressed
            hit = self.menu_hit(tap, PAUSE_MENU_Y, PAUSE_MENU_STEP, len(PAUSE_ITEMS))
            if hit is not None:
                self.pause_sel = hit
                chosen = True
            if (inp.start_pressed and not inp.enter_pressed) or (chosen and self.pause_sel == 0):
                self.state = "playing"
                self.audio.pause_music(False)
                self.audio.play("pause")
            elif chosen and self.pause_sel == 1:
                self.open_settings("paused")
            elif chosen and self.pause_sel == 2:
                self.open_about("paused")
            elif chosen and self.pause_sel == 3:
                self.audio.pause_music(False)
                self.to_title()
        elif self.state == "settings":
            if self.settings_from == "title":
                self.title_camera()
            self.settings_menu.update(inp, tap)
        elif self.state == "about":
            if tap:         # tap the left side for the previous page, the right side for the next
                if tap[0] < SCREEN_W // 2:
                    inp.left_pressed = True
                else:
                    inp.jump_pressed = True
            if self.about_from == "title":
                self.title_camera()
            if inp.right_pressed and self.about_page < ABOUT_PAGES - 1:
                self.about_page += 1
                self.audio.play("tick")
            elif inp.left_pressed and self.about_page > 0:
                self.about_page -= 1
                self.audio.play("tick")
            elif inp.jump_pressed and self.about_page < ABOUT_PAGES - 1:
                self.about_page += 1
                self.audio.play("tick")
            elif inp.jump_pressed or inp.start_pressed or inp.attack_pressed:
                self.state = self.about_from
                self.audio.play("pause")
        elif self.state == "playing":
            if inp.start_pressed and not self.player.dying:
                self.pause_game()
                return
            self.update_playing(inp)
        elif self.state == "clear":
            self.update_clear(inp)
        elif self.state == "win":
            self.clear_timer += 1
            if self.clear_timer > 120 and (inp.start_pressed or inp.jump_pressed):
                self.to_title()
        elif self.state == "gameover":
            if self.clear_timer > 0:
                self.clear_timer -= 1
            elif inp.start_pressed or inp.jump_pressed:
                self.to_title()

    def to_title(self):
        self.save_high_score()
        self.state = "title"
        self._setup_world(start=True)
        self.audio.play_music("main")

    # ==================================================================
    # Playing
    # ==================================================================
    def update_playing(self, inp):
        p = self.player
        w = self.world
        if p.transform > 0:
            p.transform -= 1
            return
        if p.dying:
            self.update_death()
            return

        # ---- moving platforms first, then carry the rider ----
        for e in self.entities:
            if isinstance(e, Platform):
                e.update(self)
        if p.riding is not None:
            move_body(p, w, p.riding.dx, p.riding.dy)

        prev_bottom = p.y + p.h
        was_on_ground = p.on_ground
        hits, jumped = step_player(p, inp, w)
        if jumped:
            self.audio.play("swim" if p.swimming else "jump")
        if bool(p.swimming) != bool(p.was_swimming):
            self.audio.play("splash")
            for i in range(6):
                self.particles.append(Puff(p.x + p.w * i / 5, p.y + p.h / 2))
        p.was_swimming = p.swimming
        if p.flying and self.frame % 20 == 0:
            self.audio.play("flap")
        if p.form == ELYTRA and p.gliding and self.frame % 3 == 0:
            # the elytra leaves a sparkling trail behind Pip
            self.particles.append(Sparkle(p.x + p.w / 2 - p.facing * 10, p.y + p.h / 2 + random.randint(-4, 4)))
        if p.on_ground:
            p.combo = 0

        # ---- land on moving platforms ----
        p.riding = None
        if p.vy >= 0:
            for e in self.entities:
                if isinstance(e, Platform) and p.x + p.w > e.x and p.x < e.x + e.w:
                    if prev_bottom <= e.y + 2 + max(e.dy, 0) and p.y + p.h >= e.y:
                        p.y = e.y - p.h
                        if not was_on_ground:
                            p.impact = p.vy
                        p.vy = 0
                        p.on_ground = True
                        p.riding = e
                        break

        # ---- hard landing after a long drop: a soft thud and ground-coloured dust ----
        if (p.on_ground and not was_on_ground and p.y - p.peak_y > HARD_LANDING
                and p.impact >= HARD_IMPACT):
            if p.riding is not None:
                colour = (250, 210, 120)
            else:
                ty = int((p.y + p.h + 1) // TILE)
                c = w.get(int((p.x + p.w / 2) // TILE), ty)
                if c == ' ':
                    c = w.get(int(p.x // TILE), ty)
                if c == ' ':
                    c = w.get(int((p.x + p.w - 1) // TILE), ty)
                colours = dict(GROUND_COLOURS, **THEME_DUST.get(self.level.theme, {}))
                colour = colours.get(c, colours['X'])
            for i in range(14):
                vx = (-1 if i < 7 else 1) * (0.6 + random.random() * 1.4)
                vy = -(0.7 + random.random() * 1.1)
                self.particles.append(LandDust(p.x + p.w * (i + 0.5) / 14, p.y + p.h - 2, vx, vy, colour))
            self.audio.play("land")
        if p.on_ground:
            p.peak_y = p.y
        elif p.y < p.peak_y:
            p.peak_y = p.y

        # ---- blocks hit from below ----
        if hits.top_tiles:
            cx = p.x + p.w / 2
            tx, ty = min(hits.top_tiles, key=lambda t: abs((t[0] + 0.5) * TILE - cx))
            self.hit_block(tx, ty, by_player=True)
        if p.vy < -1 and any(w.get(tx, ty) == 'N' for tx, ty in hits.bottom_tiles):
            self.audio.play("bounce")
            for t in hits.bottom_tiles:
                if w.get(*t) == 'N':
                    self.bumps[t] = 10

        # ---- skid dust ----
        if p.skidding and self.frame % 4 == 0:
            self.particles.append(Dust(p.x + p.w / 2 - p.facing * 6, p.y + p.h - 2))

        # ---- attacks (R1 / Square / X / Shift / J) ----
        if inp.attack_pressed:
            if p.form == FIRE:
                if sum(isinstance(e, Fireball) for e in self.entities) < 2:
                    self.entities.append(Fireball(p.x + (p.w if p.facing > 0 else -8),
                                                  p.y + 6, p.facing))
                    self.audio.play("fireball")
            elif p.form in FLYING_FORMS and p.spin == 0:
                p.spin = 18
                self.audio.play("spin")
        if p.spin:
            p.spin -= 1
            self.spin_attack()

        # ---- coins in the map ----
        x0, x1 = int(p.x // TILE), int((p.x + p.w - 1) // TILE)
        y0, y1 = int(p.y // TILE), int((p.y + p.h - 1) // TILE)
        for ty in range(y0, y1 + 1):
            for tx in range(x0, x1 + 1):
                if w.get(tx, ty) == 'o':
                    w.set(tx, ty, ' ')
                    self.collect_coin(tx * TILE + 8, ty * TILE + 8)

        # ---- hazards / falling ----
        if w.touches_hazard(p.x, p.y, p.w, p.h):
            self.hurt_player()
        if p.y > w.pixel_h:
            self.kill_player()
            return
        if w.touches_lava(p.x, p.y, p.w, p.h) and not self.fire_safe:
            self.burn_player()
            return

        # ---- breathing: AIR runs out with Pip's head under water ----
        head_wet = w.liquid_at(p.x + p.w / 2, p.y + 3) == '~'
        if head_wet and not self.water_safe:
            self.air -= 1
            if self.air < 5 * FPS and self.air % FPS == 0:
                self.audio.play("air")
            if self.frame % 50 == 0:
                self.particles.append(Bubble(p.x + p.w / 2 + p.facing * 5, p.y + 2))
            if self.air <= 0:
                self.air = 0
                self.kill_player()          # drowned
                return
        else:
            self.air = min(AIR_MAX, self.air + AIR_REFILL)

        # ---- potion timers (they count down only while playing) ----
        if self.fire_safe:
            self.fire_safe -= 1
            if self.fire_safe == 10 * FPS:
                self.audio.play("air")
        if self.water_safe:
            self.water_safe -= 1
            if self.water_safe == 10 * FPS:
                self.audio.play("air")
        if self.banner:
            self.banner -= 1

        # ---- autoscroll ----
        a = self.level.autoscroll
        if (a and self.autoscroll == "idle" and p.x + p.w / 2 >= a["start_tx"] * TILE
                and p.y < a["max_ty"] * TILE):
            self.autoscroll = "active"
        if self.autoscroll == "active":
            self.cam_x += AUTOSCROLL_SPEED
            if self.cam_x >= a["end_cam_x"]:
                self.cam_x = a["end_cam_x"]
                self.autoscroll = "done"
            if p.x < self.cam_x:
                p.x = self.cam_x
                if p.vx < 0:
                    p.vx = 0
                if w.rect_hits_solid(p.x, p.y, p.w, p.h):
                    self.kill_player()      # crushed by the scrolling screen
                    return
            if p.x + p.w > self.cam_x + SCREEN_W:
                p.x = self.cam_x + SCREEN_W - p.w

        # ---- entities ----
        for e in self.entities:
            if not e.active:
                if e.always_active or self.cam_x - 48 < e.x < self.cam_x + SCREEN_W + 48:
                    e.active = True
                else:
                    continue
            if isinstance(e, Platform):
                continue
            if e.dead:
                e.update_dead()
            else:
                e.update(self)
            if e.y > w.pixel_h + 64 or (e.is_enemy and e.x < self.cam_x - 320 and self.autoscroll != "idle"):
                e.alive = False
        self.player_vs_entities(inp, prev_bottom)
        self.entities = [e for e in self.entities if e.alive]

        if p.invuln:
            p.invuln -= 1
        for k in list(self.bumps):
            self.bumps[k] -= 1
            if self.bumps[k] <= 0:
                del self.bumps[k]
        for pt in self.particles:
            pt.update()
        self.particles = [pt for pt in self.particles if pt.alive]

        # ---- timer ----
        self.time_left -= 1
        if self.time_left <= 0:
            self.time_left = 0
            self.kill_player()
        elif self.time_left == 100 * FPS:
            self.audio.play("pause")

        self.update_camera()
        self.music_for_position()

    def update_camera(self):
        p = self.player
        w = self.world
        if self.autoscroll != "active":
            target = p.x + p.w / 2 - SCREEN_W / 2 + p.facing * 16
            self.cam_x += (target - self.cam_x) * 0.12
            if self.autoscroll == "done":
                self.cam_x = max(self.cam_x, self.level.autoscroll["end_cam_x"] - SCREEN_W)
        self.cam_x = max(0, min(self.cam_x, w.pixel_w - SCREEN_W))
        sy = p.y + p.h / 2 - self.cam_y
        target_y = self.cam_y
        if sy < 80:
            target_y = p.y + p.h / 2 - 80
        elif sy > 150:
            target_y = p.y + p.h / 2 - 150
        self.cam_y += (target_y - self.cam_y) * 0.18
        self.cam_y = max(0, min(self.cam_y, w.pixel_h - SCREEN_H))

    def player_vs_entities(self, inp, prev_bottom):
        p = self.player
        for e in self.entities:
            if not e.active or e.dead or not e.alive or not e.overlaps(p):
                continue
            if isinstance(e, Item):
                if e.emerge <= 0:
                    self.collect_item(e)
                continue
            if not e.is_enemy:
                continue
            if isinstance(e, Shellback) and e.state == "shell":
                if p.vy > 0 and prev_bottom <= e.y + 6:
                    e.stomp(self)
                    self.bounce_player(inp)
                elif e.grace == 0:
                    e.kick(self, 1 if p.x + p.w / 2 < e.x + e.w / 2 else -1)
                continue
            stomp_window = max(6, p.vy + 3)
            if e.stompable and p.vy > 0 and prev_bottom <= e.y + stomp_window:
                e.stomp(self)
                p.combo += 1
                self.add_score(100 * (2 ** min(p.combo - 1, 6)), e.x, e.y - 8)
                self.bounce_player(inp)
            else:
                harmful = e.touch_harmful() if isinstance(e, Shellback) else e.harmful
                if e.burns and self.fire_safe:
                    harmful = False          # the yellow potion: fire can't burn Pip
                if harmful:
                    self.hurt_player()

    def bounce_player(self, inp):
        p = self.player
        p.vy = -(STOMP_BOUNCE_HI if inp.jump else STOMP_BOUNCE_LO)
        p.jumping = True
        p.on_ground = False

    def spin_attack(self):
        p = self.player
        rx0, rx1 = p.x - 10, p.x + p.w + 10
        ry0, ry1 = p.y + p.h / 2, p.y + p.h
        for e in self.entities:
            if (e.is_enemy and not e.dead and e.kill_by_shell and
                    e.x < rx1 and e.x + e.w > rx0 and e.y < ry1 and e.y + e.h > ry0):
                e.kill(self, 200)
                self.audio.play("kick")
        if p.spin == 10:
            ty = int((p.y + p.h - 4) // TILE)
            for tx in (int(rx0 // TILE), int(rx1 // TILE)):
                if self.world.get(tx, ty) in "B?MFLQYPE":
                    self.hit_block(tx, ty, from_shell=True)

    # ==================================================================
    # Blocks, items, scoring
    # ==================================================================
    def hit_block(self, tx, ty, by_player=False, from_shell=False):
        w = self.world
        c = w.get(tx, ty)
        p = self.player
        big = p.form != SMALL
        px, py = tx * TILE, ty * TILE
        if c == '?':
            w.set(tx, ty, 'U')
            self.entities.append(CoinPop(px, py - TILE))
            self.collect_coin(None, None, popup=False)
            self.bumps[(tx, ty)] = 10
        elif c in ITEM_BLOCKS:
            w.set(tx, ty, 'U')
            if c == 'M':
                kind = "sunfruit" if p.form == SMALL else "ember"
            elif c == 'F':
                kind = "feather"
            elif c in "YPE":
                kind = {"Y": "fire_potion", "P": "water_potion", "E": "elytra"}[c]
            else:
                kind = "heart"
            item = Item(px + 1, py, kind)
            if kind == "feather":
                item.y = py - TILE
            self.entities.append(item)
            self.audio.play("appear")
            self.bumps[(tx, ty)] = 10
        elif c == 'Q':
            left = self.qcoins.get((tx, ty), 8) - 1
            self.qcoins[(tx, ty)] = left
            self.entities.append(CoinPop(px, py - TILE))
            self.collect_coin(None, None, popup=False)
            self.bumps[(tx, ty)] = 10
            if left <= 0:
                w.set(tx, ty, 'U')
        elif c == 'B':
            if big or from_shell:
                w.set(tx, ty, ' ')
                for vx, vy in ((-1.2, -5), (1.2, -5), (-1, -3), (1, -3)):
                    self.particles.append(BrickShard(px + 6, py + 6, vx, vy))
                self.audio.play("break")
                self.add_score(50, None, None)
            else:
                self.bumps[(tx, ty)] = 10
                self.audio.play("bump")
        elif c == 'T':
            w.toggle ^= 1
            self.bumps[(tx, ty)] = 10
            self.audio.play("toggle")
            unstick(p, w)
            for e in self.entities:
                if e.is_enemy and hasattr(e, "walk_physics"):
                    unstick(e, w)
        elif by_player:
            self.audio.play("bump")
        # bumping a block knocks out enemies standing on it
        for e in self.entities:
            if (e.is_enemy and not e.dead and abs(e.y + e.h - py) < 3 and
                    e.x + e.w > px and e.x < px + TILE):
                e.kill(self, 200)

    def collect_coin(self, x, y, popup=True):
        self.coins += 1
        self.add_score(50, None, None)
        self.audio.play("coin")
        if x is not None:
            self.particles.append(Sparkle(x, y))
        if self.coins >= 100:
            self.coins -= 100
            self.one_up()

    def one_up(self):
        self.lives += 1
        self.audio.play("oneup")
        self.particles.append(ScorePopup(self.player.x, self.player.y - 10, "1UP"))

    def collect_item(self, item):
        p = self.player
        item.alive = False
        if item.kind == "heart":
            self.one_up()
            return
        self.add_score(1000, item.x, item.y)
        if item.kind == "fire_potion":
            self.fire_safe = FIRE_POTION_FRAMES
            self.particles.append(ScorePopup(p.x - 20, p.y - 22, "FIREPROOF!"))
            self.audio.play("potion")
            return
        if item.kind == "water_potion":
            self.water_safe = WATER_POTION_FRAMES
            self.air = AIR_MAX
            self.particles.append(ScorePopup(p.x - 24, p.y - 22, "WATER BREATH!"))
            self.audio.play("potion")
            return
        new_form = {"sunfruit": BIG if p.form == SMALL else p.form,
                    "ember": FIRE, "feather": FEATHER, "elytra": ELYTRA}[item.kind]
        if p.form == self.level.start_form:
            new_form = p.form                 # never trade away the world's own gear (the elytra)
        if new_form != p.form:
            p.set_form(new_form)
            unstick(p, self.world)
            p.transform = 36
        self.audio.play("powerup")

    def add_score(self, points, x, y):
        self.score += points
        if x is not None:
            self.particles.append(ScorePopup(x, y, str(points)))

    def reach_checkpoint(self, cp):
        if cp.index > self.checkpoint:
            self.checkpoint = cp.index
        self.audio.play("checkpoint")
        self.particles.append(ScorePopup(cp.x - 12, cp.y - 10, "CHECKPOINT"))

    # ==================================================================
    # Damage, death, clear
    # ==================================================================
    def hurt_player(self):
        p = self.player
        if p.invuln or p.dying or p.transform:
            return
        if p.form == self.level.start_form:
            # a world's own gear (the Void's elytra) can't be knocked off - over
            # the void that would be certain death. The hit empties the FLY meter.
            p.fly = 0
            p.invuln = INVULN_FRAMES
            self.audio.play("powerdown")
            return
        if p.form != SMALL:
            p.set_form(SMALL)
            p.invuln = INVULN_FRAMES
            p.transform = 30
            self.audio.play("powerdown")
        else:
            self.kill_player()

    def burn_player(self):
        """Fell into lava without the yellow potion."""
        p = self.player
        if p.dying:
            return
        self.audio.play("burn")
        for i in range(8):
            self.particles.append(LandDust(p.x + p.w * i / 7, p.y + p.h - 4,
                                           (i - 3.5) * 0.3, -1.5 - random.random() * 1.5, (255, 140, 40)))
        self.kill_player()

    def kill_player(self):
        p = self.player
        if p.dying:
            return
        p.dying = True
        p.death_timer = 0
        p.vy = -5.0
        p.vx = 0
        if p.form != SMALL:
            p.set_form(SMALL)
        self.audio.stop_music()
        self.audio.play_music("death", loop=False)

    def update_death(self):
        p = self.player
        p.death_timer += 1
        if p.death_timer > 30:
            p.vy = min(p.vy + 0.25, 5)
            p.y += p.vy
        if p.death_timer > 170:
            self.lives -= 1
            self.carry_form = SMALL
            self.fire_safe = self.water_safe = 0      # potions wear off when Pip loses a life
            if self.lives <= 0:
                self.save_high_score()
                self.state = "gameover"
                self.clear_timer = 90
                self.audio.play_music("gameover", loop=False)
            else:
                self._setup_world()

    def last_world(self):
        return self.level_index == len(self.levels) - 1

    def course_clear(self, icon):
        self.state = "clear"
        self.clear_icon = icon
        self.clear_timer = 0
        self.audio.stop_music()
        self.audio.play_music("clear", loop=False)
        if self.last_world():
            self.wins += 1                    # all four worlds beaten: one more win!
            self.save_high_score()

    def update_clear(self, inp):
        self.clear_timer += 1
        for pt in self.particles:
            pt.update()
        self.particles = [pt for pt in self.particles if pt.alive]
        if self.clear_timer > 150 and self.time_left > 0:
            # each remaining second is worth 50 points
            self.time_left = max(0, self.time_left - FPS)
            self.score += 50
            if self.frame % 3 == 0:
                self.audio.play("tick")
        if self.clear_timer == 150 and self.clear_icon:
            bonus = {"sun": 1000, "moon": 2000, "star": 5000}[self.clear_icon]
            self.add_score(bonus, self.goal.x, self.goal.y - 12)
            self.audio.play("oneup")
        if self.clear_timer > 240 and self.time_left <= 0:
            self.high_score = max(self.high_score, self.score)
            self.save_high_score()            # only writes when the high score changed
            if inp.start_pressed or inp.jump_pressed:
                if self.last_world():
                    self.state = "win"
                    self.clear_timer = 0
                    self.audio.play_music("win", loop=False)
                else:
                    self.next_world()

    # ==================================================================
    # Drawing
    # ==================================================================
    def _make_hills(self):
        far = pygame.Surface((640, 120), pygame.SRCALPHA)
        for cx, r in ((60, 70), (220, 50), (350, 85), (520, 60), (640, 70), (0, 70)):
            pygame.draw.circle(far, (120, 170, 220), (cx, 120 + r // 3), r)
        self.bg_cloud = pygame.Surface((44, 23), pygame.SRCALPHA)
        pygame.draw.ellipse(self.bg_cloud, (255, 255, 255, 85), (0, 7, 44, 14))
        pygame.draw.ellipse(self.bg_cloud, (255, 255, 255, 85), (10, 0, 24, 16))
        # pieces of the new worlds' backgrounds, made once (not every frame)
        glow = pygame.Surface((SCREEN_W, 60), pygame.SRCALPHA)
        for y in range(60):
            glow.fill((255, 90, 20, int(y * 1.4)), (0, y, SCREEN_W, 1))
        ray = pygame.Surface((30, SCREEN_H), pygame.SRCALPHA)
        pygame.draw.polygon(ray, (200, 240, 255, 26), [(10, 0), (22, 0), (30, SCREEN_H), (0, SCREEN_H)])
        self.bg_parts = {"glow": glow, "ray": ray}
        near = pygame.Surface((640, 90), pygame.SRCALPHA)
        for cx, r in ((40, 40), (160, 55), (300, 35), (420, 60), (560, 45), (680, 40), (-80, 55)):
            pygame.draw.circle(near, (96, 196, 110), (cx, 90 + r // 4), r)
            pygame.draw.circle(near, (130, 220, 140), (cx - r // 3, 90 - r + r // 4 + 10), 4)
        return far, near

    THEME_SKY = {
        "sky": ((74, 116, 222), (132, 202, 255)),
        "fire": ((30, 8, 10), (110, 30, 20)),
        "water": ((40, 120, 200), (10, 40, 100)),
        "void": ((6, 2, 14), (30, 10, 50)),
    }

    def sky_color(self):
        t = self.cam_y / max(1, self.world.pixel_h - SCREEN_H)
        top, bottom = self.THEME_SKY[self.level.theme]
        return tuple(int(top[i] + (bottom[i] - top[i]) * t) for i in range(3))

    def draw_background(self, surf):
        theme = self.level.theme
        if theme != "sky":
            self.draw_theme_background(surf, theme)
            return
        surf.fill(self.sky_color())
        detail = QUALITY_DETAIL[self.options["quality"]]
        if not detail:
            return
        far, near = self.hills
        ground_screen = GROUND_Y - self.cam_y
        for layer, factor, h in ((far, 0.2, 120), (near, 0.45, 90)):
            off = -(self.cam_x * factor) % 640
            y = ground_screen - h + (10 if layer is near else 0)
            if y < SCREEN_H:
                surf.blit(layer, (off - 640, y))
                surf.blit(layer, (off, y))
        # faint parallax clouds (translucent so they never read as platforms)
        for i in range(int(8 * detail)):
            cx = (i * 173 - self.cam_x * 0.3) % (SCREEN_W + 120) - 60
            cy = 30 + (i * 53) % 120 - self.cam_y * 0.3 + 70
            surf.blit(self.bg_cloud, (cx, cy - 7))

    def draw_theme_background(self, surf, theme):
        """Ember Caverns: glowing rock and drifting embers. Coral Deep: light
        rays and rising bubbles. The Void: twinkling stars."""
        surf.fill(self.sky_color())
        f = self.frame
        detail = QUALITY_DETAIL[self.options["quality"]]
        if not detail:
            return
        if theme == "fire":
            for i in range(6):                          # far cave pillars
                x = (i * 97 - self.cam_x * 0.25) % (SCREEN_W + 80) - 40
                pygame.draw.rect(surf, (55, 18, 18), (x, 0, 22 + (i * 7) % 18, SCREEN_H))
            surf.blit(self.bg_parts["glow"], (0, SCREEN_H - 60))
            for i in range(int(18 * detail)):           # embers floating up
                x = (i * 53 - self.cam_x * 0.5 + math.sin(f * 0.02 + i) * 8) % SCREEN_W
                y = SCREEN_H - ((f * (0.4 + i % 3 * 0.2) + i * 37) % (SCREEN_H + 20))
                surf.fill((255, 170 - (i % 3) * 40, 40), (x, y, 2, 2))
        elif theme == "water":
            for i in range(5):                          # light rays from the surface
                x = (i * 83 - self.cam_x * 0.2) % (SCREEN_W + 120) - 60
                surf.blit(self.bg_parts["ray"], (x, 0))
            for i in range(int(14 * detail)):           # bubbles rising
                x = (i * 61 - self.cam_x * 0.4 + math.sin(f * 0.05 + i) * 4) % SCREEN_W
                y = SCREEN_H - ((f * (0.5 + i % 4 * 0.15) + i * 47) % (SCREEN_H + 10))
                pygame.draw.circle(surf, (190, 230, 255), (int(x), int(y)), 1 + i % 2, 1)
        else:                                           # the void
            for i in range(int(60 * detail)):
                x = (i * 137 - self.cam_x * (0.1 + (i % 3) * 0.1)) % SCREEN_W
                y = (i * 71 - self.cam_y * 0.1) % SCREEN_H
                b = 120 + int(100 * math.sin(f * 0.05 + i * 1.7))
                surf.fill((b, b, min(255, b + 40)), (x, y, 1 + (i % 7 == 0), 1 + (i % 7 == 0)))
            for k, (cx, cy, r, col) in enumerate(((60, 50, 30, (70, 30, 120)), (250, 140, 22, (30, 60, 120)))):
                x = (cx - self.cam_x * 0.05) % (SCREEN_W + 80) - 40
                pygame.draw.circle(surf, col, (int(x), cy), r)

    def draw_liquids(self, surf):
        """Water and lava are drawn over Pip, see-through, so he looks submerged."""
        w = self.world
        tx0, ty0 = int(self.cam_x // TILE), int(self.cam_y // TILE)
        ox, oy = int(self.cam_x), int(self.cam_y)
        frame = 0 if self.options["quality"] == "LOW" else (self.frame // 10) % 4
        for ty in range(max(0, ty0), min(w.h, ty0 + SCREEN_H // TILE + 2)):
            row = w.liquid[ty]
            above = w.liquid[ty - 1] if ty > 0 else [None] * w.w
            for tx in range(max(0, tx0), min(w.w, tx0 + SCREEN_W // TILE + 2)):
                c = row[tx]
                if c is None:
                    continue
                kind = "deep" if above[tx] == c or w.is_solid(tx, ty - 1) else "surface"
                surf.blit(self.assets.liquids[c][kind][frame], (tx * TILE - ox, ty * TILE - oy))

    def tile_image(self, c, tx, ty):
        t = self.assets.tiles
        theme = self.assets.theme_tiles[self.level.theme]
        w = self.world
        if c == 'X':
            key = 'dirt' if w.get(tx, ty - 1) == 'X' else 'grass'
            return theme.get(key, t[key])
        if c == 'S':
            return theme.get('S', t['S'])
        if c in '?MFLYPE':
            return t[f'star{(self.frame // 8) % 4}']
        if c == 'o':
            return self.assets.coin[(self.frame // 8) % 4]
        if c == 'T':
            return t[f'T{w.toggle}']
        if c == 'R':
            return t['R_on'] if w.toggle == 0 else t['R_off']
        if c == 'b':
            return t['b_on'] if w.toggle == 1 else t['b_off']
        if c == 'H':
            return None
        return t.get(c)

    def title_view(self):
        """The title screen (or its About page) shows the level scrolling by, without Pip."""
        return (self.state == "title" or (self.state == "about" and self.about_from == "title")
                or (self.state == "settings" and self.settings_from == "title"))

    def draw_world(self, surf):
        self.draw_background(surf)
        tx0, ty0 = int(self.cam_x // TILE), int(self.cam_y // TILE)
        ox, oy = int(self.cam_x), int(self.cam_y)
        for ty in range(ty0, ty0 + SCREEN_H // TILE + 2):
            for tx in range(tx0, tx0 + SCREEN_W // TILE + 2):
                c = self.world.get(tx, ty)
                if c in ' ~V' or (tx < 0 or tx >= self.world.w):
                    continue
                img = self.tile_image(c, tx, ty)
                if img is None:
                    continue
                bump = self.bumps.get((tx, ty), 0)
                dy = -int(math.sin(bump / 10 * math.pi) * 5) if bump else 0
                surf.blit(img, (tx * TILE - ox, ty * TILE - oy + dy))
        for e in self.entities:
            if e.active or self.title_view():
                if -64 < e.x - self.cam_x < SCREEN_W + 64:
                    e.draw(surf, self)
        if not self.title_view():
            self.draw_player(surf)
        self.draw_liquids(surf)
        for pt in self.particles:
            pt.draw(surf, self)

    def draw_player(self, surf):
        p = self.player
        if p.invuln and (self.frame // 3) % 2 and not p.transform:
            return
        form = p.form
        if p.transform:
            form = p.form if (p.transform // 4) % 2 == 0 else p.old_form
        if p.dying:
            pose = "jump"
        elif not p.on_ground:
            pose = "jump"
        elif abs(p.vx) > 0.1:
            p.anim += abs(p.vx) * 0.09
            pose = ("walk1", "stand", "walk2", "stand")[int(p.anim) % 4]
        else:
            pose = "stand"
        if form == ELYTRA and p.gliding and not p.on_ground:
            pose = "jump"                     # elytra: wings held wide open, a smooth glide
        elif form == FEATHER and p.gliding and not p.on_ground:
            pose = "jump" if (self.frame // (4 if p.flying else 6)) % 2 else "stand"   # wings flap
        facing = p.facing
        if p.spin:
            facing = 1 if (p.spin // 3) % 2 else -1
        img = self.assets.pip[form][pose][facing]
        x = round(p.x + p.w / 2 - 8 - self.cam_x)
        y = round(p.y + p.h - img.get_height() - self.cam_y)
        if p.dying:
            img = pygame.transform.flip(img, False, p.death_timer > 30)
        surf.blit(img, (x, y))

    def draw_hud(self, surf):
        bar = pygame.Surface((SCREEN_W, 16), pygame.SRCALPHA)
        bar.fill((0, 0, 0, 140))
        surf.blit(bar, (0, 0))
        self._text(surf, f"PIP x{self.lives}", 4, 4)
        surf.blit(self.assets.coin[0], (54, 0))
        self._text(surf, f"x{self.coins:02d}", 70, 4)
        self._text(surf, f"{self.score:07d}", 100, 4)
        # run meter
        pm = self.player.pmeter
        for i in range(6):
            filled = pm >= (i + 1) * PMETER_MAX / 6
            col = (255, 220, 70) if filled else (90, 90, 110)
            x = 166 + i * 8
            pygame.draw.polygon(surf, col, [(x, 4), (x + 5, 8), (x, 12)])
        full = pm >= PMETER_MAX
        pcol = (255, 90, 90) if full and (self.frame // 6) % 2 else (90, 90, 110)
        pygame.draw.rect(surf, pcol, (214, 2, 11, 12))
        self._text(surf, "P", 216, 4)
        timer = f"TIME {math.ceil(self.time_left / FPS):03d}"
        self._text(surf, timer, SCREEN_W - 4 - self.pixfont.width(timer), 4)
        if self.audio.muted:
            self._text(surf, "MUTED", SCREEN_W - 4 - self.pixfont.width("MUTED"), 44, (255, 170, 170))
        # feather / elytra fly meter: 10 white bars with a bluish outline, 0.4 s of flight each
        if self.player.form in FLYING_FORMS:
            bars = (self.player.fly + FLY_BAR_FRAMES - 1) // FLY_BAR_FRAMES
            self._text(surf, "FLY", 4, 20, (200, 225, 255))
            for i in range(FLY_BARS):
                x = 32 + i * 7
                surf.fill((70, 120, 210), (x, 19, 6, 9))
                surf.fill((255, 255, 255) if i < bars else (20, 30, 60), (x + 1, 20, 4, 7))
        # air meter under water: 10 bubbles, 2 seconds each
        if self.air < AIR_MAX and not self.water_safe:
            self._text(surf, "AIR", 4, 32, (170, 220, 255))
            left = math.ceil(self.air / (AIR_MAX / 10))
            low = self.air < 5 * FPS and (self.frame // 8) % 2
            for i in range(10):
                c = (255, 90, 90) if low else (200, 235, 255)
                pygame.draw.circle(surf, c if i < left else (40, 60, 90), (36 + i * 7, 36), 3, 0 if i < left else 1)
        # active potion effects at the top right: icon + time left
        x = SCREEN_W - 4
        for frames, icon, col in ((self.water_safe, self.assets.icon_water, (150, 210, 255)),
                                  (self.fire_safe, self.assets.icon_fire, (255, 220, 90))):
            if not frames:
                continue
            secs = math.ceil(frames / FPS)
            text = f"{secs // 60}:{secs % 60:02d}"
            ending = frames < 10 * FPS and (self.frame // 10) % 2
            tw = self.pixfont.width(text)
            x -= tw
            self._text(surf, text, x, 20, (255, 255, 255) if ending else col)
            x -= 14
            surf.blit(icon, (x, 18))
            x -= 8
        # world name banner when a world starts
        if self.banner and self.state == "playing":
            self._center_text(f"WORLD {self.level_index + 1}", 70, 2, YELLOW)
            self._center_text(self.level.name, 92, 2, WHITE)

    def _text(self, surf, text, x, y, col=WHITE, font=None, shadow=True):
        self.pixfont.draw(surf if surf is not None else self.canvas, text, x, y, col,
                          font or self.font, shadow)

    def _center_text(self, text, y, font=None, col=WHITE, surf=None):
        font = font or self.font
        self._text(surf, text, (SCREEN_W - self.pixfont.width(text, font)) // 2, y, col, font)

    def present(self):
        """Scale the pixel-art canvas up to the window (sharp pixels) and show it."""
        self.screen.blit(pygame.transform.scale(self.canvas, self.screen.get_size()), (0, 0))
        pygame.display.flip()

    def draw_panel(self, surf, rect):
        panel = pygame.Surface(rect.size, pygame.SRCALPHA)
        panel.fill((10, 14, 40, 210))
        surf.blit(panel, rect.topleft)
        pygame.draw.rect(surf, (255, 220, 120), rect, 1)

    def _bind_help(self, device, action, limit=11):
        """An action's buttons, as many as fit in the help table's column."""
        text = ""
        for token in self.options[device].get(action, ()):
            name = label(device, token)
            joined = text + "/" + name if text else name
            if len(joined) > limit:
                break
            text = joined
        return text or "-"

    def _move_help(self, device, defaults, default_text):
        o = self.options[device]
        if o["left"] == defaults["left"] and o["right"] == defaults["right"]:
            return default_text
        left = label(device, o["left"][0]) if o["left"] else "-"
        right = label(device, o["right"][0]) if o["right"] else "-"
        return left + " " + right

    def draw_controls_help(self, surf, y):
        rows = [
            ("", "KEYBOARD", "PS4 CONTROLLER"),
            ("MOVE", self._move_help("keys", DEFAULT_KEYS, "ARROWS/WASD"), self._move_help("pad", DEFAULT_PAD, "D-PAD/STICK")),
            ("JUMP", self._bind_help("keys", "jump"), self._bind_help("pad", "jump")),
            ("LONG JUMP", self._bind_help("keys", "long_jump"), self._bind_help("pad", "long_jump")),
            ("RUN", self._bind_help("keys", "run"), self._bind_help("pad", "run")),
            ("ATTACK", self._bind_help("keys", "attack"), self._bind_help("pad", "attack")),
            ("PAUSE", self._bind_help("keys", "pause"), self._bind_help("pad", "pause")),
            ("MUTE", self._bind_help("keys", "mute"), "-"),
            ("FULLSCREEN", self._bind_help("keys", "fullscreen"), "-"),
        ]
        for i, cols in enumerate(rows):
            col = YELLOW if i == 0 else SOFT
            for text, x in zip(cols, (18, 100, 196)):
                self._text(surf, text, x, y + i * 10, col)

    def draw_menu(self, surf, items, sel, y, step):
        for i, item in enumerate(items):
            w = self.pixfont.width(item)
            x = (SCREEN_W - w) // 2
            if i == sel:
                self._text(surf, item, x, y + i * step, YELLOW)
                if (self.frame // 15) % 2 == 0:
                    self._text(surf, ">", x - 16, y + i * step, YELLOW)
                    self._text(surf, "<", x + w + 9, y + i * step, YELLOW)
            else:
                self._text(surf, item, x, y + i * step, WHITE)

    def draw_about(self, surf):
        self.draw_panel(surf, pygame.Rect(6, 4, SCREEN_W - 12, SCREEN_H - 8))
        if self.about_page == 0:
            intro = [
                "A BRAND-NEW ADVENTURE IN THE",
                "TIMELESS STYLE OF THE CLASSIC 8-BIT",
                "PLATFORMERS - THE PICK-UP-AND-PLAY",
                "FUN THAT MADE GAMES LIKE MARIO",
                "LEGENDS!",
                "",
                "RUN, JUMP, SWIM AND FLY WITH PIP",
                "ACROSS FOUR WORLDS: THE SKY KINGDOM,",
                "THE LAVA-FILLED EMBER CAVERNS, THE",
                "UNDERWATER CORAL DEEP AND THE",
                "ENDLESS VOID - THEN THE STAR GATE!",
                "",
                "BEAT ALL FOUR WORLDS TO ADD A WIN.",
                "ORIGINAL ART, MUSIC AND CHIPTUNE",
                "SOUND - MARK 3 EDITION.",
            ]
            self._center_text("PIP'S SKY KINGDOM", 12, 2, YELLOW, surf)
            for i, line in enumerate(intro):
                self._center_text(line, 38 + i * 11, 1, SOFT, surf)
        elif self.about_page == 2:
            extra = [
                (self.assets.fire_potion, "YELLOW POTION", ["FIREPROOF FOR 2:30 - LAVA AND",
                                                            "FIRE CAN'T BURN YOU, AND YOU", "CAN SWIM IN LAVA!"]),
                (self.assets.water_potion, "WATER POTION", ["NO DROWNING FOR 5:00 - THE AIR", "METER STAYS FULL UNDER WATER."]),
                (self.assets.elytra, "ELYTRA", ["THE VOID'S WINGS: FLY LIKE THE", "FEATHER, CLIMB HIGHER AND GLIDE", "FAST AND FAR. ATTACK = SPIN."]),
            ]
            self._center_text("MUTATIONS", 12, 2, YELLOW, surf)
            y = 36
            for icon, name, lines in extra:
                surf.blit(icon, (16, y - 4))
                self._text(surf, name, 40, y, SKY_BLUE)
                y += 10
                for line in lines:
                    self._text(surf, line, 40, y, SOFT)
                    y += 10
                y += 4
            self._center_text("POTION TIMERS SHOW AT THE TOP", 172, 1, YELLOW, surf)
            self._center_text("OF THE SCREEN. UNDER WATER, WATCH", 183, 1, YELLOW, surf)
            self._center_text("THE AIR BUBBLES!", 194, 1, YELLOW, surf)
        else:
            power = [
                (self.assets.sunfruit, "SUNFRUIT", ["GROW BIG! SMASH BRICKS AND", "SURVIVE AN EXTRA HIT."]),
                (self.assets.ember, "EMBER BERRY", ["BECOME FIRE PIP AND THROW",
                                                    "BOUNCING FIREBALLS (ATTACK)."]),
                (self.assets.feather, "SKY FEATHER", ["HOLD JUMP IN THE AIR TO FLY -",
                                                      "WATCH THE FLY METER!", "ATTACK = SPIN ATTACK."]),
                (self.assets.heart, "HEART", ["AN EXTRA LIFE!"]),
            ]
            self._center_text("POWER-UPS", 12, 2, YELLOW, surf)
            y = 36
            for icon, name, lines in power:
                surf.blit(icon, (16, y - 4))
                self._text(surf, name, 40, y, SKY_BLUE)
                y += 10
                for line in lines:
                    self._text(surf, line, 40, y, SOFT)
                    y += 10
                y += 4
            self._center_text("GRAB THE STAR AT THE STAR GATE", 184, 1, YELLOW, surf)
            self._center_text("FOR THE BIGGEST BONUS!", 195, 1, YELLOW, surf)
        # footer on every page: the win counter and how to turn pages
        self._text(surf, f"WINS {self.wins}", 14, 220, (170, 255, 170))
        nav = f"{self.about_page + 1}/{ABOUT_PAGES}  LEFT/RIGHT  ENTER: BACK"
        self._text(surf, nav, SCREEN_W - 14 - self.pixfont.width(nav), 220, WHITE)

    def draw(self):
        self.draw_scene()
        self.draw_overlays(self.canvas)

    def draw_overlays(self, surf):
        """Things on top of everything: touch buttons, FPS, scanlines and brightness."""
        o = self.options
        if self.state == "playing" and self.touch.active():
            self.touch.draw(surf, self.pixfont)
        if o["show_fps"]:
            text = f"{self.clock.get_fps():.0f} FPS"
            self._text(surf, text, SCREEN_W - 3 - self.pixfont.width(text), SCREEN_H - 8, (170, 255, 170))
        if o["scanlines"]:
            if self.scanline_img is None:
                self.scanline_img = pygame.Surface((SCREEN_W, SCREEN_H), pygame.SRCALPHA)
                for y in range(0, SCREEN_H, 2):
                    self.scanline_img.fill((0, 0, 0, 60), (0, y, SCREEN_W, 1))
            surf.blit(self.scanline_img, (0, 0))
        b = o["brightness"]
        if b < 100:
            v = round(b * 2.55)
            surf.fill((v, v, v), special_flags=pygame.BLEND_RGB_MULT)
        elif b > 100:
            v = round((b - 100) * 1.2)
            surf.fill((v, v, v), special_flags=pygame.BLEND_RGB_ADD)

    def draw_scene(self):
        surf = self.canvas
        cx = SCREEN_W // 2
        self.draw_world(surf)
        if self.state == "settings":
            self.settings_menu.draw(surf)
            return
        if self.state == "title":
            self.draw_panel(surf, pygame.Rect(12, 4, SCREEN_W - 24, SCREEN_H - 8))
            self._center_text("PIP'S", 10, self.big_font, YELLOW)
            self._center_text("SKY KINGDOM", 36, self.big_font, SKY_BLUE)
            surf.blit(self.assets.pip[SMALL]["stand"][1], (cx - 50, 66))
            surf.blit(self.assets.pip[FEATHER]["jump"][-1], (cx + 34, 58))
            surf.blit(self.assets.nutling[(self.frame // 10) % 2], (cx - 8, 68))
            self.draw_controls_help(surf, 88)
            self.draw_menu(surf, TITLE_ITEMS, self.title_sel, TITLE_MENU_Y, TITLE_MENU_STEP)
            self._center_text(f"HIGH SCORE {self.high_score:07d}   WINS {self.wins}", 220, 1, YELLOW)
            if self.quit_confirm:
                self.draw_panel(surf, pygame.Rect(56, 94, SCREEN_W - 112, 52))
                self._center_text("QUIT THE GAME?", 106, 1, WHITE)
                self._center_text("JUMP: YES    ENTER: NO", 126, 1, YELLOW)
            return
        if self.state == "about" and self.about_from == "title":
            self.draw_about(surf)
            return
        self.draw_hud(surf)
        if self.state == "paused":
            self.draw_panel(surf, pygame.Rect(12, 20, SCREEN_W - 24, SCREEN_H - 24))
            self._center_text("PAUSED", 26, self.big_font, YELLOW)
            self._text(surf, f"SCORE {self.score:07d}", 22, 54)
            self._center_text(f"WINS {self.wins}", 54, 1, (170, 255, 170))
            hs = f"HIGH {self.high_score:07d}"
            self._text(surf, hs, SCREEN_W - 22 - self.pixfont.width(hs), 54, YELLOW)
            self.draw_controls_help(surf, 66)
            self.draw_menu(surf, PAUSE_ITEMS, self.pause_sel, PAUSE_MENU_Y, PAUSE_MENU_STEP)
            self._center_text("UP/DOWN: CHOOSE   ENTER: OK", 200, 1, WHITE)
            self._center_text("ESC / OPTIONS: RESUME", 212, 1, WHITE)
        elif self.state == "about":
            self.draw_about(surf)
        elif self.state == "clear":
            if self.clear_timer > 60:
                self.draw_panel(surf, pygame.Rect(40, 50, SCREEN_W - 80, 128))
                self._center_text("WORLD CLEAR!", 58, 2, YELLOW)
                icon = self.assets.goal_icons[self.clear_icon]
                surf.blit(icon, (cx - 8, 80))
                self._center_text(f"{self.clear_icon.upper()} BONUS", 100, 1, WHITE)
                if self.time_left <= 0 and self.clear_timer > 240:
                    if self.last_world():
                        self._center_text("ALL 4 WORLDS BEATEN!", 116, 1, SKY_BLUE)
                    else:
                        nxt = self.levels[self.level_index + 1]
                        self._center_text(f"NEXT: WORLD {self.level_index + 2}", 116, 1, SKY_BLUE)
                        self._center_text(nxt.name, 127, 1, SKY_BLUE)
                    if self.score > self.game_start_high:
                        self._center_text("NEW HIGH SCORE!", 140, 1, YELLOW)
                    if (self.frame // 30) % 2 == 0:
                        self._center_text("PRESS ENTER / JUMP", 154, 1, WHITE)
                self._center_text(f"WINS {self.wins}", 166, 1, (170, 255, 170))
        elif self.state == "win":
            self.draw_panel(surf, pygame.Rect(30, 40, SCREEN_W - 60, 150))
            self._center_text("YOU WIN!", 50, 3, YELLOW)
            self._center_text("PIP SAVED ALL FOUR WORLDS!", 84, 1, SKY_BLUE)
            for i, (form, x) in enumerate(((SMALL, -60), (FIRE, -30), (FEATHER, 4), (ELYTRA, 34))):
                bob = int(math.sin(self.frame * 0.1 + i) * 3)
                surf.blit(self.assets.pip[form]["jump" if bob < 0 else "stand"][1], (cx + x, 100 + bob))
            self._center_text(f"SCORE {self.score:07d}", 136, 1, WHITE)
            self._center_text(f"TOTAL WINS: {self.wins}", 148, 1, (170, 255, 170))
            if self.score > self.game_start_high:
                self._center_text("NEW HIGH SCORE!", 160, 1, YELLOW)
            if self.clear_timer > 120 and (self.frame // 30) % 2 == 0:
                self._center_text("PRESS ENTER / JUMP", 174, 1, WHITE)
        elif self.state == "gameover":
            self.draw_panel(surf, pygame.Rect(60, 80, SCREEN_W - 120, 88))
            self._center_text("GAME OVER", 92, 2, (255, 110, 110))
            if self.score > self.game_start_high:
                self._center_text("NEW HIGH SCORE!", 114, 1, YELLOW)
            if self.clear_timer == 0:
                self._center_text("PRESS ENTER / OPTIONS", 132, 1, WHITE)
            self._center_text(f"WINS {self.wins}", 150, 1, (170, 255, 170))


GROUND_Y = 26 * TILE
