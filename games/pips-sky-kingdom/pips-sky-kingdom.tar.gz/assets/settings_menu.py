"""The Settings screen: tabs for display, audio, game, keyboard, controller and touch,
plus the drag-and-drop editor for the on-screen touch buttons."""

import pygame

from options import KEY_ACTIONS, PAD_ACTIONS, MAX_SLOTS, QUALITIES, label
from settings import SCREEN_W, SCREEN_H, FPS
from touch import EDIT_NAMES

WHITE = (255, 255, 255)
YELLOW = (255, 220, 90)
SOFT = (220, 230, 255)
DIM = (120, 130, 170)
GREEN = (170, 255, 170)

TABS = ("DISPLAY", "AUDIO", "GAME", "KEYS", "PAD", "TOUCH")
ROW_Y, ROW_STEP = 37, 14
LABEL_X, CONTROL_X, CONTROL_W = 14, 150, 104
SLOT_X, SLOT_STEP, SLOT_W = 100, 53, 50
TAB_Y = 20
LISTEN_FRAMES = 6 * FPS
BACK_RECT = pygame.Rect(SCREEN_W - 56, 7, 44, 11)
# the layout editor's tool bar: (id, text, x, width)
EDIT_TOOLS = (("smaller", "SIZE-", 4, 48), ("bigger", "SIZE+", 56, 48), ("reset", "RESET", 196, 48), ("done", "DONE", 248, 68))
QUALITY_HELP = {"LOW": "PLAIN BACKGROUNDS, NO DUST. FASTEST.",
                "MEDIUM": "FEWER BACKGROUND DETAILS AND DUST.",
                "HIGH": "EVERYTHING ON. BEST LOOK."}


def slider(key, name, lo, hi, step, help_text=""):
    return {"kind": "slider", "key": key, "name": name, "lo": lo, "hi": hi, "step": step, "help": help_text}


def choice(key, name, values, help_text=""):
    return {"kind": "choice", "key": key, "name": name, "values": values, "help": help_text}


def switch(key, name, help_text=""):
    return {"kind": "choice", "key": key, "name": name, "values": (False, True), "help": help_text}


def action(name, run, confirm=True, help_text=""):
    return {"kind": "action", "name": name, "run": run, "confirm": confirm, "help": help_text}


def binding(device, action_id, name):
    return {"kind": "bind", "device": device, "action": action_id, "name": name, "help": ""}


class SettingsMenu:
    def __init__(self, game):
        self.game = game
        self.options = game.options
        self.tab = 0
        self.row = -1               # -1 = the tab bar
        self.slot = 0
        self.listen = None          # {"device", "action", "slot", "timer"} while waiting for a button
        self.message = ""
        self.message_timer = 0
        self.armed = None           # a reset row waiting for its second press
        self.editing = False        # the touch layout editor
        self.edit_sel = "stick"
        self.drag = None            # (pointer id, offset x, offset y)
        self.prev_pad = set()
        self.rows_by_tab = (
            [slider("brightness", "BRIGHTNESS", 50, 150, 10, "HOW BRIGHT THE WHOLE GAME LOOKS."),
             choice("quality", "GRAPHICS", QUALITIES),
             switch("fullscreen", "FULLSCREEN"),
             switch("scanlines", "SCANLINES", "AN OLD TV LOOK WITH DARK LINES."),
             switch("show_fps", "SHOW FPS", "FRAMES PER SECOND, BOTTOM RIGHT.")],
            [slider("master", "MASTER VOLUME", 0, 100, 10),
             slider("music", "MUSIC", 0, 100, 10),
             slider("sfx", "SOUND EFFECTS", 0, 100, 10),
             switch("muted", "MUTE ALL")],
            [choice("run_mode", "RUN MODE", ("HOLD", "TOGGLE"), "TOGGLE: TAP RUN ONCE TO KEEP RUNNING."),
             switch("auto_pause", "AUTO-PAUSE", "PAUSE IF YOU SWITCH TO ANOTHER WINDOW."),
             action("RESET ALL SETTINGS", self.reset_all)],
            [binding("keys", a, n) for a, n in KEY_ACTIONS]
            + [action("RESET KEYBOARD", lambda: self.reset_part("keys"))],
            [slider("deadzone", "STICK DEADZONE", 10, 80, 5, "HOW FAR THE STICK MOVES BEFORE IT COUNTS.")]
            + [binding("pad", a, n) for a, n in PAD_ACTIONS]
            + [action("RESET CONTROLLER", lambda: self.reset_part("pad"))],
            [choice("touch_mode", "TOUCH BUTTONS", ("AUTO", "ON", "OFF"), "AUTO: SHOWN ON TOUCH SCREENS."),
             slider("touch_opacity", "BUTTON OPACITY", 20, 100, 10),
             action("EDIT BUTTON LAYOUT", self.open_editor, confirm=False, help_text="DRAG AND RESIZE THE BUTTONS."),
             action("RESET BUTTON LAYOUT", lambda: self.reset_part("touch"))],
        )

    # ---- helpers ------------------------------------------------------------
    @property
    def rows(self):
        return self.rows_by_tab[self.tab]

    def say(self, text):
        self.message = text
        self.message_timer = 4 * FPS

    def reset_all(self):
        self.options.reset()
        self.say("ALL SETTINGS BACK TO DEFAULT")

    def reset_part(self, key):
        self.options.reset(key)
        self.say("BACK TO THE DEFAULT")

    def open_editor(self):
        self.editing = True
        self.edit_sel = "stick"
        self.drag = None

    def leave(self):
        self.listen = None
        self.game.controls.frozen = False
        self.armed = None
        self.options.save()
        self.game.close_settings()

    def change(self, row, direction):
        """Slider or choice row: step the value, wrapping for choices."""
        if row["kind"] == "slider":
            value = max(row["lo"], min(row["hi"], self.options[row["key"]] + row["step"] * direction))
            if value == self.options[row["key"]]:
                return
            self.options[row["key"]] = value
        else:
            values = row["values"]
            i = values.index(self.options[row["key"]])
            self.options[row["key"]] = values[(i + direction) % len(values)]
        self.game.apply_options()
        self.game.audio.play("tick")

    def activate(self, row):
        kind = row["kind"]
        if kind == "choice":
            self.change(row, 1)
        elif kind == "bind":
            self.start_listen(row)
        elif kind == "action":
            if row["confirm"] and self.armed is not row:
                self.armed = row
                self.game.audio.play("tick")
                return
            self.armed = None
            row["run"]()
            self.game.apply_options()
            self.game.audio.play("pause")

    # ---- rebinding ----------------------------------------------------------
    def start_listen(self, row):
        self.slot = min(self.slot, len(self.options[row["device"]][row["action"]]), MAX_SLOTS - 1)
        self.listen = {"device": row["device"], "action": row["action"], "slot": self.slot,
                       "timer": LISTEN_FRAMES}
        self.game.controls.frozen = True
        self.prev_pad = set(self.game.controls.pad_held)
        self.game.audio.play("pause")

    def stop_listen(self):
        self.listen = None
        self.game.controls.frozen = False

    def capture(self, token):
        li = self.listen
        moved = self.options.bind(li["device"], li["action"], li["slot"], token)
        names = dict(KEY_ACTIONS)
        text = label(li["device"], token)
        if moved:
            self.say(f"{text} MOVED: {names[moved]} TO {names[li['action']]}")
        else:
            self.say(f"{names[li['action']]}: {text}")
        self.game.controls.wait_release = (li["device"], token)
        self.stop_listen()
        self.game.audio.play("coin")

    def on_key(self, key):
        """A keyboard key went down (called straight from the event loop)."""
        if self.listen:
            if key == pygame.K_ESCAPE:
                self.stop_listen()
                self.game.controls.wait_release = ("keys", key)     # Esc must not also leave the menu
            elif self.listen["device"] == "keys":
                if key in (pygame.K_DELETE, pygame.K_BACKSPACE):
                    li = self.listen
                    self.options.clear_bind(li["device"], li["action"], li["slot"])
                    self.say("BUTTON REMOVED")
                    self.stop_listen()
                else:
                    self.capture(key)
        elif key in (pygame.K_DELETE, pygame.K_BACKSPACE) and self.row >= 0 and not self.editing:
            row = self.rows[self.row]
            if row["kind"] == "bind":
                self.options.clear_bind(row["device"], row["action"], self.slot)
                self.say("BUTTON REMOVED")

    # ---- update -------------------------------------------------------------
    def update(self, inp, tap):
        if self.message_timer:
            self.message_timer -= 1
        if self.editing:
            if inp.start_pressed or inp.attack_pressed:
                self.close_editor()
            return
        if self.listen:
            self.update_listen(tap)
            return
        if tap:
            self.handle_tap(*tap)
            return
        ok = inp.jump_pressed or inp.enter_pressed
        if inp.start_pressed and not inp.enter_pressed:
            self.leave()
            self.game.audio.play("pause")
            return
        rows = self.rows
        if inp.up_pressed or inp.down_pressed:
            self.armed = None
            self.row = (self.row + (1 if inp.down_pressed else -1) + 1) % (len(rows) + 1) - 1
            self.game.audio.play("tick")
        step = (1 if inp.right_pressed else 0) - (1 if inp.left_pressed else 0)
        row = rows[self.row] if self.row >= 0 else None
        if row is None:
            if step:
                self.select_tab((self.tab + step) % len(TABS))
        elif step and row["kind"] in ("slider", "choice"):
            self.change(row, step)
        elif step and row["kind"] == "bind":
            self.slot = (self.slot + step) % MAX_SLOTS
            self.game.audio.play("tick")
        if row is not None and ok:
            self.activate(row)
        elif row is not None and inp.attack_pressed and row["kind"] == "bind" and row["device"] == "pad":
            self.options.clear_bind("pad", row["action"], self.slot)
            self.say("BUTTON REMOVED")

    def update_listen(self, tap):
        li = self.listen
        li["timer"] -= 1
        if tap or li["timer"] <= 0:
            self.stop_listen()
            return
        pad = self.game.controls.pad_held
        if li["device"] == "pad":
            new = sorted(pad - self.prev_pad)
            if new:
                self.capture(new[0])
                return
        self.prev_pad = set(pad)

    def select_tab(self, tab):
        self.tab = tab
        self.row = -1
        self.armed = None
        self.message_timer = 0
        self.game.audio.play("tick")

    # ---- mouse and touch ----------------------------------------------------
    def handle_tap(self, x, y):
        if BACK_RECT.collidepoint(x, y):
            self.leave()
            self.game.audio.play("pause")
            return
        for i, rect in enumerate(self.tab_rects()):
            if rect.collidepoint(x, y):
                self.select_tab(i)
                return
        if y < ROW_Y - 2:
            return
        i = (y - ROW_Y + 2) // ROW_STEP
        if not 0 <= i < len(self.rows):
            return
        self.row = i
        row = self.rows[i]
        if row["kind"] == "slider":
            frac = max(0.0, min(1.0, (x - CONTROL_X) / CONTROL_W))
            value = row["lo"] + round(frac * (row["hi"] - row["lo"]) / row["step"]) * row["step"]
            if x >= CONTROL_X - 8:
                self.options[row["key"]] = value
                self.game.apply_options()
                self.game.audio.play("tick")
        elif row["kind"] == "choice":
            self.change(row, -1 if x < CONTROL_X + CONTROL_W / 2 else 1)
        elif row["kind"] == "bind":
            if x >= SLOT_X:
                self.slot = min(MAX_SLOTS - 1, max(0, (x - SLOT_X) // SLOT_STEP))
                self.start_listen(row)
        else:
            self.activate(row)

    def tab_rects(self):
        rects, x = [], 10
        for name in TABS:
            w = len(name) * 8 + 5
            rects.append(pygame.Rect(x, TAB_Y - 2, w, 12))
            x += w + 4
        return rects

    # ---- the touch layout editor -----------------------------------------------
    def close_editor(self):
        self.editing = False
        self.drag = None
        self.options.save()
        self.game.audio.play("pause")

    def editor_down(self, pid, x, y):
        if y < 16:
            for tool, _text, tx, tw in EDIT_TOOLS:
                if tx <= x < tx + tw:
                    self.use_tool(tool)
            return
        touch = self.game.touch
        name = touch.button_at(x, y)
        if name:
            self.edit_sel = name
            layout = self.options["touch"][name]
            self.drag = (pid, layout[0] - x, layout[1] - y)

    def editor_move(self, pid, x, y):
        if self.drag and self.drag[0] == pid:
            layout = self.options["touch"][self.edit_sel]
            layout[0], layout[1] = x + self.drag[1], y + self.drag[2]
            self.game.touch.clamp(self.edit_sel)

    def editor_up(self, pid):
        if self.drag and self.drag[0] == pid:
            self.drag = None

    def use_tool(self, tool):
        layout = self.options["touch"][self.edit_sel]
        if tool in ("smaller", "bigger"):
            size = layout[2] + (0.1 if tool == "bigger" else -0.1)
            layout[2] = round(max(0.6, min(1.6, size)), 1)
            self.game.touch.clamp(self.edit_sel)
            self.game.audio.play("tick")
        elif tool == "reset":
            self.options.reset("touch")
            self.game.audio.play("tick")
        else:
            self.close_editor()

    # ---- drawing --------------------------------------------------------------
    def draw(self, surf):
        if self.editing:
            self.draw_editor(surf)
            return
        g = self.game
        g.draw_panel(surf, pygame.Rect(6, 4, SCREEN_W - 12, SCREEN_H - 8))
        g._text(surf, "SETTINGS", 12, 8, YELLOW)
        pygame.draw.rect(surf, DIM, BACK_RECT, 1)
        g._text(surf, "BACK", BACK_RECT.x + 7, BACK_RECT.y + 2, WHITE)
        for i, (name, rect) in enumerate(zip(TABS, self.tab_rects())):
            on = i == self.tab
            if on:
                surf.fill((70, 80, 150), rect)
            if on and self.row < 0:
                pygame.draw.rect(surf, YELLOW, rect, 1)
            g._text(surf, name, rect.x + 3, rect.y + 2, YELLOW if on else SOFT)
        for i, row in enumerate(self.rows):
            self.draw_row(surf, row, ROW_Y + i * ROW_STEP, i == self.row)
        self.draw_footer(surf)

    def draw_row(self, surf, row, y, selected):
        g = self.game
        colour = YELLOW if selected else WHITE
        kind = row["kind"]
        if kind == "bind":
            g._text(surf, row["name"], LABEL_X, y + 2, colour)
            tokens = self.options[row["device"]][row["action"]]
            for slot in range(MAX_SLOTS):
                rect = pygame.Rect(SLOT_X + slot * SLOT_STEP, y, SLOT_W, 12)
                listening = (self.listen and self.listen["action"] == row["action"]
                             and self.listen["device"] == row["device"] and self.listen["slot"] == slot)
                surf.fill((90, 60, 20) if listening else (25, 32, 70), rect)
                on = selected and slot == self.slot
                pygame.draw.rect(surf, YELLOW if on or listening else DIM, rect, 1)
                if listening:
                    text = "..." if (g.frame // 15) % 2 else "PRESS"
                elif slot < len(tokens):
                    text = label(row["device"], tokens[slot])
                else:
                    text = "-"
                tw = g.pixfont.width(text)
                g._text(surf, text, rect.x + (SLOT_W - tw) // 2, y + 3, WHITE if slot < len(tokens) else DIM)
        elif kind == "slider":
            g._text(surf, row["name"], LABEL_X, y + 2, colour)
            value = self.options[row["key"]]
            frac = (value - row["lo"]) / (row["hi"] - row["lo"])
            rect = pygame.Rect(CONTROL_X, y + 2, CONTROL_W, 8)
            surf.fill((25, 32, 70), rect)
            surf.fill(YELLOW if selected else SOFT, (rect.x, rect.y, round(frac * CONTROL_W), 8))
            pygame.draw.rect(surf, DIM, rect, 1)
            g._text(surf, f"{value}%", CONTROL_X + CONTROL_W + 6, y + 2, colour)
        elif kind == "choice":
            g._text(surf, row["name"], LABEL_X, y + 2, colour)
            value = self.options[row["key"]]
            text = ("ON" if value else "OFF") if isinstance(value, bool) else str(value)
            g._text(surf, "<", CONTROL_X, y + 2, colour)
            g._text(surf, ">", CONTROL_X + CONTROL_W - 7, y + 2, colour)
            tw = g.pixfont.width(text)
            g._text(surf, text, CONTROL_X + (CONTROL_W - tw) // 2, y + 2, colour)
        else:
            text = "PRESS AGAIN TO CONFIRM" if self.armed is row else row["name"]
            g._text(surf, text, LABEL_X, y + 2, (255, 150, 120) if self.armed is row else colour)

    def footer_text(self):
        """(top line, bottom line) under the rows."""
        if self.listen:
            secs = self.listen["timer"] // FPS + 1
            if self.listen["device"] == "keys":
                return f"PRESS A KEY OR CLICK ({secs})", "ESC: CANCEL   DEL: REMOVE"
            return f"PRESS A CONTROLLER BUTTON ({secs})", "ESC OR WAIT: CANCEL"
        row = self.rows[self.row] if self.row >= 0 else None
        top = ""
        if self.message_timer:
            top = self.message
        elif row is not None and row["kind"] == "choice" and row["key"] == "quality":
            top = QUALITY_HELP[self.options["quality"]]
        elif row is not None:
            top = row["help"]
        if not top and TABS[self.tab] == "PAD":
            pads = self.game.controls.pad_names()
            top = ("FOUND: " + pads[0]).upper()[:37] if pads else "NO CONTROLLER CONNECTED"
        if row is None:
            bottom = "LEFT/RIGHT: TAB  DOWN: SETTINGS"
        elif row["kind"] == "bind" and row["device"] == "keys":
            bottom = "ENTER: REBIND  DEL: REMOVE  ESC: BACK"
        elif row["kind"] == "bind":
            bottom = "CROSS: SET  ATTACK: CLEAR  OPT: BACK"
        elif row["kind"] == "action":
            bottom = "ENTER: OK   ESC: BACK"
        else:
            bottom = "LEFT/RIGHT: CHANGE   ESC: BACK"
        return top, bottom

    def draw_footer(self, surf):
        g = self.game
        top, bottom = self.footer_text()
        if top:
            g._center_text(top, 212, 1, GREEN if self.message_timer or self.listen else SOFT, surf)
        g._center_text(bottom, 224, 1, DIM, surf)

    def draw_editor(self, surf):
        g = self.game
        touch = g.touch
        surf.fill((10, 14, 40), (0, 0, SCREEN_W, 16))
        for _tool, text, x, w in EDIT_TOOLS:
            rect = pygame.Rect(x, 2, w, 12)
            surf.fill((70, 80, 150), rect)
            pygame.draw.rect(surf, YELLOW, rect, 1)
            g._text(surf, text, x + (w - g.pixfont.width(text)) // 2, 4)
        for name in self.options["touch"]:
            touch.draw_button(surf, g.pixfont, name, selected=name == self.edit_sel)
        size = round(self.options["touch"][self.edit_sel][2] * 100)
        g._center_text(f"{EDIT_NAMES[self.edit_sel]} {size}%", 70, 1, YELLOW, surf)
        g._center_text("DRAG A BUTTON TO MOVE IT", 82, 1, WHITE, surf)
