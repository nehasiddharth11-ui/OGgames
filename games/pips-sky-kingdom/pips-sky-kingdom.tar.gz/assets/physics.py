"""Player movement + tile collision (Mark 3 rules, the same as the PSP version).

Kept identical to the PSP's game.c (step_player / move_body) so the level
solver (solver.py) checks the level with the physics the PSP really uses:
  * bounce block: a normal full jump, or the big 6.2 bounce when jump is held
    or pressed just before landing
  * O (long jump): always a full-height jump
"""

from settings import *

# PSP-only physics (game.c): faster falling after the top of a jump, except with
# the feather, and feather flight driven by a 10-bar fly meter.
# The meter counts in small units: flying uses FLY_DRAIN per frame, standing on
# the ground refills FLY_REFILL per frame (60 frames = 1 second).
GRAVITY_FALL = 0.8
MAX_FALL_FAST = 5.6
FLY_DRAIN = 4
FLY_MAX = 960               # 10 bars x 96 units: a bar lasts 24 frames (0.4 s) of flight
FLY_SPEED = 0.96            # climb speed (was 1.2, now 20% weaker)
FLY_REFILL = 1              # 96 frames (1.6 s) on the ground refills one bar

# The elytra uses the same fly meter, with a better flight: a stronger, snappier
# climb, a faster glide that keeps its speed, and a gentler glide fall.
ELYTRA_SPEED = 1.44
ELYTRA_AIR_MAX = 3.2
ELYTRA_GLIDE_FALL = 0.5


class InputState:
    __slots__ = ("left", "right", "up", "down", "run", "jump",
                 "jump_pressed", "long_pressed", "run_pressed", "start_pressed")

    def __init__(self):
        self.left = self.right = self.up = self.down = False
        self.run = self.jump = False
        self.jump_pressed = self.long_pressed = self.run_pressed = self.start_pressed = False


class Hits:
    __slots__ = ("left", "right", "bottom", "top", "top_tiles", "bottom_tiles")

    def __init__(self):
        self.left = self.right = self.bottom = self.top = False
        self.top_tiles = []
        self.bottom_tiles = []


def move_body(b, world, dx, dy):
    """Move an object with x, y, w, h through the tile map. X then Y."""
    hits = Hits()
    if dx:
        b.x += dx
        y0 = int(b.y // TILE)
        y1 = int((b.y + b.h - 0.001) // TILE)
        if dx > 0:
            tx = int((b.x + b.w - 0.001) // TILE)
            for ty in range(y0, y1 + 1):
                if world.is_solid(tx, ty):
                    b.x = tx * TILE - b.w
                    hits.right = True
                    break
        else:
            tx = int(b.x // TILE)
            for ty in range(y0, y1 + 1):
                if world.is_solid(tx, ty):
                    b.x = (tx + 1) * TILE
                    hits.left = True
                    break
    if dy:
        prev_bottom = b.y + b.h
        b.y += dy
        x0 = int(b.x // TILE)
        x1 = int((b.x + b.w - 0.001) // TILE)
        if dy > 0:
            ty = int((b.y + b.h - 0.001) // TILE)
            top = ty * TILE
            for tx in range(x0, x1 + 1):
                if world.is_solid(tx, ty) or (
                        world.is_oneway(tx, ty) and prev_bottom <= top + 0.5):
                    hits.bottom = True
                    hits.bottom_tiles.append((tx, ty))
            if hits.bottom:
                b.y = top - b.h
        else:
            ty = int(b.y // TILE)
            for tx in range(x0, x1 + 1):
                if world.is_solid(tx, ty, from_below=True):
                    hits.top = True
                    hits.top_tiles.append((tx, ty))
            if hits.top:
                b.y = (ty + 1) * TILE
    return hits


def unstick(b, world):
    """After toggle blocks change, push a body up out of anything solid."""
    if not world.rect_hits_solid(b.x, b.y, b.w, b.h):
        return
    for d in range(1, 40):
        if not world.rect_hits_solid(b.x, b.y - d, b.w, b.h):
            b.y -= d
            return


class PlayerBody:
    def __init__(self, x, y, form=SMALL):
        self.form = form
        self.w = PLAYER_W
        self.h = SMALL_H if form == SMALL else BIG_H
        self.x = float(x)
        self.y = float(y)
        self.vx = 0.0
        self.vy = 0.0
        self.on_ground = False
        self.coyote = 0
        self.jump_buffer = 0
        self.jumping = False
        self.bouncing = False
        self.buffer_long = False
        self.pmeter = 0
        self.fly = FLY_MAX
        self.flying = False
        self.swimming = None    # '~' or 'V' while in a liquid
        self.facing = 1
        self.skidding = False
        self.gliding = False
        self.impact = 0.0       # falling speed when Pip last hit the ground


def _sign(v):
    return (v > 0) - (v < 0)


def step_swim(b, inp, world):
    """One frame of swimming in water (or lava, with the yellow potion)."""
    slow = 0.7 if b.swimming == 'V' else 1.0          # lava is thicker
    direction = (1 if inp.right else 0) - (1 if inp.left else 0)
    if direction:
        b.facing = direction
        if b.vx * direction < SWIM_MAX * slow:
            b.vx += direction * SWIM_ACCEL
        if abs(b.vx) > SWIM_MAX * slow:
            b.vx = _sign(b.vx) * SWIM_MAX * slow
    elif abs(b.vx) <= SWIM_FRICTION:
        b.vx = 0.0
    else:
        b.vx -= _sign(b.vx) * SWIM_FRICTION
    b.pmeter = max(0, b.pmeter - 1)
    b.flying = b.gliding = b.skidding = False
    b.jumping = b.bouncing = False
    b.coyote = b.jump_buffer = 0

    at_surface = world.liquid_at(b.x + b.w / 2, b.y - 2) is None
    can_hop = at_surface and not world.rect_hits_solid(b.x, b.y - 8, b.w, 8)
    stroke = False
    if can_hop and (inp.jump_pressed or (inp.jump and b.vy < -0.5)):
        stroke = True
        b.vy = -SWIM_EXIT              # leap out onto the shore (press, or swim up holding jump)
        b.jumping = True
    elif inp.jump_pressed:
        stroke = True
        b.vy = min(b.vy, -SWIM_STROKE * slow)
    elif inp.jump:
        b.vy += (-SWIM_RISE * slow - b.vy) * 0.1
    else:
        b.vy += (SWIM_SINK * slow - b.vy) * 0.06

    hits = move_body(b, world, b.vx, b.vy)
    if hits.left or hits.right:
        b.vx = 0.0
    if hits.top:
        b.vy = 0.3
    b.on_ground = hits.bottom
    if hits.bottom:
        b.impact = 0.0
        b.vy = 0.0
    return hits, stroke


def step_player(b, inp, world):
    """Advance the player one frame. Returns the Hits record plus flags."""
    b.swimming = world.liquid_at(b.x + b.w / 2, b.y + b.h / 2)
    if b.swimming:
        return step_swim(b, inp, world)
    run = inp.run
    max_speed = RUN_MAX if run else WALK_MAX
    direction = (1 if inp.right else 0) - (1 if inp.left else 0)
    accel = RUN_ACCEL if run else WALK_ACCEL
    if not b.on_ground:
        accel *= AIR_CONTROL
    soaring = b.form == ELYTRA and not b.on_ground and inp.jump
    if soaring:
        max_speed = ELYTRA_AIR_MAX      # the elytra glides fast...
        accel = RUN_ACCEL

    b.skidding = False
    if direction:
        b.facing = direction
        if b.vx * direction < 0:
            b.vx += direction * (SKID_DECEL if b.on_ground else AIR_TURN)
            b.skidding = b.on_ground
        elif abs(b.vx) < max_speed:
            b.vx += direction * accel
            if abs(b.vx) > max_speed:
                b.vx = direction * max_speed
        else:
            b.vx -= _sign(b.vx) * FRICTION
            if abs(b.vx) < max_speed:
                b.vx = _sign(b.vx) * max_speed
    else:
        fr = FRICTION if b.on_ground else (0.0 if soaring else AIR_FRICTION)   # ...and keeps its speed
        if abs(b.vx) <= fr:
            b.vx = 0.0
        else:
            b.vx -= _sign(b.vx) * fr

    if b.on_ground:
        if run and abs(b.vx) >= RUN_MAX - 0.01:
            b.pmeter = min(PMETER_MAX, b.pmeter + 1)
        else:
            b.pmeter = max(0, b.pmeter - 1)

    jumped = False
    if inp.jump_pressed:
        b.jump_buffer = JUMP_BUFFER_FRAMES
        b.buffer_long = inp.long_pressed
    elif b.jump_buffer > 0:
        b.jump_buffer -= 1
    if b.on_ground:
        b.coyote = COYOTE_FRAMES
    elif b.coyote > 0:
        b.coyote -= 1

    if b.jump_buffer > 0 and (b.on_ground or b.coyote > 0):
        b.vy = -(JUMP_BASE + abs(b.vx) * JUMP_RUN_BONUS)
        b.on_ground = False
        b.coyote = 0
        b.jump_buffer = 0
        b.jumping = True
        b.bouncing = b.buffer_long
        jumped = True

    b.flying = False
    wings = b.form in FLYING_FORMS
    if wings and not b.on_ground and inp.jump and b.fly > 0:
        elytra = b.form == ELYTRA
        speed = ELYTRA_SPEED if elytra else FLY_SPEED
        if b.fly < FLY_MAX // 2:
            speed *= b.fly / (FLY_MAX // 2)
        if b.y < 24:
            speed = 0.0       # hover at the top of the level instead of leaving it
        b.fly = max(0, b.fly - FLY_DRAIN)
        if b.vy > -speed:
            b.vy += (-speed - b.vy) * (0.25 if elytra else 0.15)
            b.flying = True
            b.jumping = False
            b.bouncing = False
    if wings and b.on_ground and b.fly < FLY_MAX:
        b.fly = min(FLY_MAX, b.fly + FLY_REFILL)

    if not b.flying:
        if b.vy < 0 and ((inp.jump and b.jumping) or b.bouncing):
            b.vy += GRAVITY_HOLD
        elif b.vy >= 0 and not wings:
            b.vy += GRAVITY_FALL
        else:
            b.vy += GRAVITY
    if b.vy >= 0:
        b.jumping = False
        b.bouncing = False
    cap = MAX_FALL if wings else MAX_FALL_FAST
    if b.vy > cap:
        b.vy = cap
    b.gliding = b.flying
    glide = ELYTRA_GLIDE_FALL if b.form == ELYTRA else GLIDE_FALL
    if wings and not b.on_ground and inp.jump and not b.flying and b.vy > glide:
        b.vy = glide
        b.gliding = True

    hits = move_body(b, world, b.vx, b.vy)
    if hits.left or hits.right:
        b.vx = 0.0
    if hits.top:
        b.vy = 0.5
        b.jumping = False
        b.bouncing = False
    if hits.bottom:
        b.impact = b.vy
        bounce = any(world.get(tx, ty) == 'N' for tx, ty in hits.bottom_tiles)
        if bounce:
            jumping_now = inp.jump or b.jump_buffer > 0
            b.vy = -NOTE_BOUNCE if jumping_now else -(JUMP_BASE + abs(b.vx) * JUMP_RUN_BONUS)
            b.jump_buffer = 0
            b.jumping = True
            b.bouncing = True
            b.on_ground = False
        else:
            b.vy = 0.0
            b.on_ground = True
    else:
        b.on_ground = False
    return hits, jumped
