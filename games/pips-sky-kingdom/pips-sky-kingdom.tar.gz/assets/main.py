# /// script
# dependencies = ["pygame-ce"]
# ///
"""Pip's Sky Kingdom for the OGgames website. The game code is the same as the PC
version; this file only swaps in a game loop that a web browser can run."""

import asyncio
import os
import platform
import sys

import pygame

from settings import SCREEN_W, SCREEN_H, FPS

TEST_WIN = False    # the test build sets this to True: jumps straight to the win screen
LOG_EVERY = 600     # frames between progress lines in the browser's console


def log(text):
    try:
        platform.window.console.log("OGGAMES: " + text)
    except Exception:
        print(text)


SAVE_FILES = ("highscore.dat", "settings.json")


def restore_saves(folder):
    """A browser forgets its files when the page closes, so saves live in localStorage."""
    for name in SAVE_FILES:
        try:
            text = platform.window.localStorage.getItem("pip_" + name)
            if text:
                with open(os.path.join(folder, name), "w", encoding="utf-8") as f:
                    f.write(str(text))
        except Exception as e:
            log(f"no saved {name}: {e}")


def backup_saves(folder, last):
    for name in SAVE_FILES:
        try:
            with open(os.path.join(folder, name), encoding="utf-8") as f:
                text = f.read()
            if last.get(name) != text:
                last[name] = text
                platform.window.localStorage.setItem("pip_" + name, text)
        except Exception:
            pass        # not written yet, or the browser blocks storage: the game still runs


def tell_site_game_beaten():
    """The site's "you beat it" popup with the YouTube link."""
    try:
        platform.window.eval("window.parent.postMessage({source:'oggames',type:'complete'},'*')")
    except Exception as e:
        print("could not reach the site:", e)


async def main():
    pygame.mixer.pre_init(44100, -16, 2, 2048)   # a roomier buffer: no crackles if a frame runs late
    pygame.init()
    pygame.display.set_caption("Pip's Sky Kingdom")
    screen = pygame.display.set_mode((SCREEN_W * 2, SCREEN_H * 2))
    screen.fill((0, 0, 0))
    pygame.display.flip()
    await asyncio.sleep(0)

    # right click is the long jump, so the browser's right-click menu must stay away
    try:
        platform.window.eval("document.addEventListener('contextmenu',function(e){e.preventDefault()})")
    except Exception as e:
        print("context menu:", e)
    pygame.display.toggle_fullscreen = lambda: None     # the site's Fullscreen button does this job

    t0 = pygame.time.get_ticks()
    from game import Game, save_folder
    folder = save_folder()
    restore_saves(folder)
    g = Game(screen)
    last_saves = {}
    try:
        if int(platform.window.navigator.maxTouchPoints) > 0:
            g.touch.finger_seen = True      # a phone or tablet: show the joystick and buttons right away
    except Exception as e:
        log(f"touch check: {e}")
    step = 1.0 / FPS
    acc = 0.0
    told = False
    frames = 0
    log(f"game started, set-up took {pygame.time.get_ticks() - t0} ms, {len(getattr(g.audio, 'sfx', {}))} sounds")
    try:
        platform.window.eval("window.focus();var c=document.getElementById('canvas');if(c){c.focus()}"
                             ";window.parent.postMessage({source:'oggames',type:'ready'},'*')")
    except Exception as e:
        print("focus:", e)
    while True:
        dt = g.clock.tick(240) / 1000.0
        if abs(dt - step) < 0.002:
            dt = step
        acc = min(acc + dt, step * 5)
        for e in pygame.event.get():
            if e.type == pygame.KEYDOWN and g.state == "settings":
                g.settings_menu.on_key(e.key)
            elif e.type == pygame.WINDOWFOCUSLOST:
                g.touch.release_all()
                g.controls.mouse_clear()
                if g.options["auto_pause"] and g.state == "playing" and not g.player.dying:
                    g.pause_game()
            g.controls.handle_event(e)
            g.handle_pointer(e)
        while acc >= step and g.running:
            g.update()
            acc -= step
        if not g.running:           # QUIT GAME: a web page can't close, so go back to the menu
            g.running = True
            g.quit_confirm = False
        g.draw()
        g.present()
        frames += 1
        if TEST_WIN and frames == 200:
            g.new_game()
            g.state = "win"
            g.clear_timer = 0
        if frames % LOG_EVERY == 0:
            p = g.player
            log(f"frames={frames} fps={g.clock.get_fps():.1f} state={g.state} x={p.x:.1f} y={p.y:.1f} "
                f"brightness={g.options['brightness']} music={g.audio.current}:{g.audio.music_channel.get_busy() if g.audio.enabled else 'off'}")
        if frames % 60 == 0:
            backup_saves(folder, last_saves)
        if g.state == "win" and not told:
            told = True
            log("beaten")
            g.save_high_score()
            backup_saves(folder, last_saves)
            tell_site_game_beaten()
        await asyncio.sleep(0)


asyncio.run(main())
