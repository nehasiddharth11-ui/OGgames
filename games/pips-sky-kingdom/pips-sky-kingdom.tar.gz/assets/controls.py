"""Keyboard + gamepad (PS4 DualShock 4, Xbox, generic) + touch input.

Every action reads its buttons from the player's options (Settings > KEYS and PAD),
and the defaults are in options.py. The arrow keys and D-pad always work in menus,
so a player can't lock themselves out by rebinding everything.
"""

import sys

import pygame

from options import Options
from physics import InputState

try:
    from pygame._sdl2 import controller as sdl_controller
except ImportError:  # very old pygame builds
    sdl_controller = None

# SDL game controllers: PS4 A = Cross, B = Circle, X = Square, Y = Triangle
CTRL_BUTTONS = {
    "a": pygame.CONTROLLER_BUTTON_A, "b": pygame.CONTROLLER_BUTTON_B,
    "x": pygame.CONTROLLER_BUTTON_X, "y": pygame.CONTROLLER_BUTTON_Y,
    "l1": pygame.CONTROLLER_BUTTON_LEFTSHOULDER, "r1": pygame.CONTROLLER_BUTTON_RIGHTSHOULDER,
    "l3": pygame.CONTROLLER_BUTTON_LEFTSTICK, "r3": pygame.CONTROLLER_BUTTON_RIGHTSTICK,
    "start": pygame.CONTROLLER_BUTTON_START, "back": pygame.CONTROLLER_BUTTON_BACK,
    "dup": pygame.CONTROLLER_BUTTON_DPAD_UP, "ddown": pygame.CONTROLLER_BUTTON_DPAD_DOWN,
    "dleft": pygame.CONTROLLER_BUTTON_DPAD_LEFT, "dright": pygame.CONTROLLER_BUTTON_DPAD_RIGHT,
}
# Pads SDL doesn't recognise: button numbers for the DirectInput DS4 and for everything else
DS4_BUTTONS = {0: "x", 1: "a", 2: "b", 3: "y", 4: "l1", 5: "r1", 6: "l2", 7: "r2",
               8: "back", 9: "start", 10: "l3", 11: "r3"}
GENERIC_BUTTONS = {0: "a", 1: "b", 2: "x", 3: "y", 4: "l1", 5: "r1", 6: "back", 7: "start", 8: "l3", 9: "start"}
# Web browsers give every known pad this "standard" layout
BROWSER_BUTTONS = {0: "a", 1: "b", 2: "x", 3: "y", 4: "l1", 5: "r1", 6: "l2", 7: "r2", 8: "back", 9: "start",
                   10: "l3", 11: "r3", 12: "dup", 13: "ddown", 14: "dleft", 15: "dright"}
# A DS4 on Windows through SDL's own driver (no hat: its D-pad is buttons)
DS4_SDL_BUTTONS = {0: "a", 1: "b", 2: "x", 3: "y", 4: "back", 6: "start", 7: "l3", 8: "r3", 9: "l1", 10: "r1",
                   11: "dup", 12: "ddown", 13: "dleft", 14: "dright"}

NAV_KEYS = (pygame.K_UP, pygame.K_DOWN, pygame.K_LEFT, pygame.K_RIGHT)
NAV_TOKENS = ("dup", "ddown", "dleft", "dright", "ls_up", "ls_down", "ls_left", "ls_right")


def _axis_tokens(ax, ay, dead, prefix, out):
    if ax < -dead:
        out.add(prefix + "_left")
    if ax > dead:
        out.add(prefix + "_right")
    if ay < -dead:
        out.add(prefix + "_up")
    if ay > dead:
        out.add(prefix + "_down")


def _key_held(k, mouse, code):
    """A keyboard key, or a mouse button (stored as a negative number)."""
    return code in mouse if code < 0 else k[code]


class Controls:
    def __init__(self, options=None, touch=None):
        self.options = options if options is not None else Options()
        self.touch = touch
        pygame.joystick.init()
        if sdl_controller:
            sdl_controller.init()
        self.pads = []                     # list of ("ctrl"|"joy", device)
        self.prev = PadInput()
        self.state = PadInput()
        self.pad_held = set()              # every controller button held right now
        self.frozen = False                # the Settings menu is waiting for a new button
        self.in_play = False               # the run toggle only changes during play
        self.run_latched = False
        self.wait_release = None           # ("keys"|"pad", button) just bound: ignore it until let go
        self.mouse_down = set()            # mouse buttons held since a click during play
        self.mouse_fresh = set()           # clicks not yet seen, so a very quick click still counts
        self.refresh_devices()

    # ------------------------------------------------------------------
    def refresh_devices(self):
        self.pads = []
        for i in range(pygame.joystick.get_count()):
            try:
                if sdl_controller and sdl_controller.is_controller(i):
                    self.pads.append(("ctrl", sdl_controller.Controller(i)))
                else:
                    joy = pygame.joystick.Joystick(i)
                    joy.init()
                    self.pads.append(("joy", joy))
            except pygame.error:
                pass

    def mouse_press(self, button):
        self.mouse_down.add(-button)
        self.mouse_fresh.add(-button)

    def mouse_release(self, button):
        self.mouse_down.discard(-button)

    def mouse_clear(self):
        self.mouse_down.clear()
        self.mouse_fresh.clear()

    def handle_event(self, e):
        if e.type in (pygame.JOYDEVICEADDED, pygame.JOYDEVICEREMOVED):
            self.refresh_devices()

    def pad_names(self):
        names = []
        for kind, dev in self.pads:
            try:
                names.append(dev.name if kind == "ctrl" else dev.get_name())
            except Exception:
                names.append("Gamepad")
        return names

    # ------------------------------------------------------------------
    def read_pads(self):
        """The set of controller buttons (by name) held on every connected pad."""
        held = set()
        dead = self.options["deadzone"] / 100
        for kind, dev in self.pads:
            try:
                if kind == "ctrl":
                    for token, button in CTRL_BUTTONS.items():
                        if dev.get_button(button):
                            held.add(token)
                    _axis_tokens(dev.get_axis(pygame.CONTROLLER_AXIS_LEFTX) / 32767,
                                 dev.get_axis(pygame.CONTROLLER_AXIS_LEFTY) / 32767, dead, "ls", held)
                    _axis_tokens(dev.get_axis(pygame.CONTROLLER_AXIS_RIGHTX) / 32767,
                                 dev.get_axis(pygame.CONTROLLER_AXIS_RIGHTY) / 32767, dead, "rs", held)
                    if dev.get_axis(pygame.CONTROLLER_AXIS_TRIGGERLEFT) / 32767 > 0.5:
                        held.add("l2")
                    if dev.get_axis(pygame.CONTROLLER_AXIS_TRIGGERRIGHT) / 32767 > 0.5:
                        held.add("r2")
                else:
                    self._read_joystick(dev, dead, held)
            except pygame.error:
                continue
        return held

    @staticmethod
    def _read_joystick(joy, dead, held):
        """Fallback for pads SDL does not recognise as game controllers."""
        name = joy.get_name().lower()
        ds4 = "ps4" in name or "wireless controller" in name or "dualshock" in name
        if sys.platform == "emscripten":
            layout = BROWSER_BUTTONS
        elif ds4 and not joy.get_numhats() and joy.get_numbuttons() >= 15:
            layout = DS4_SDL_BUTTONS
        else:
            layout = DS4_BUTTONS if ds4 else GENERIC_BUTTONS
        for i, token in layout.items():
            if i < joy.get_numbuttons() and joy.get_button(i):
                held.add(token)
        if joy.get_numhats():
            hx, hy = joy.get_hat(0)
            if hx < 0:
                held.add("dleft")
            if hx > 0:
                held.add("dright")
            if hy > 0:
                held.add("dup")
            if hy < 0:
                held.add("ddown")
        if joy.get_numaxes() >= 2:
            _axis_tokens(joy.get_axis(0), joy.get_axis(1), dead, "ls", held)

    # ------------------------------------------------------------------
    def poll(self):
        k = pygame.key.get_pressed()
        pad = self.read_pads()
        self.pad_held = pad
        mouse = self.mouse_down | self.mouse_fresh
        self.mouse_fresh = set()
        if self.wait_release:
            device, token = self.wait_release
            if (_key_held(k, mouse, token) if device == "keys" else token in pad):
                self.frozen_frame()
                return self.state
            self.wait_release = None
        if self.frozen:
            self.frozen_frame()
            return self.state

        keys, pads = self.options["keys"], self.options["pad"]

        def held(action):
            return (any(_key_held(k, mouse, c) for c in keys[action])
                    or any(t in pad for t in pads.get(action, ())))

        def held_off_nav(action):
            """Held using a button that isn't also a menu direction."""
            return (any(k[c] for c in keys[action] if c >= 0 and c not in NAV_KEYS and c not in keys["up"])
                    or any(t in pad for t in pads.get(action, ()) if t not in NAV_TOKENS and t not in pads["up"]))

        s = PadInput()
        s.left, s.right, s.up, s.down = held("left"), held("right"), held("up"), held("down")
        long_jump = held("long_jump")
        s.jump, s.attack = held("jump") or long_jump, held("attack")
        run = held("run")
        start = held("pause")
        mute, fullscreen = held("mute"), held("fullscreen")
        jump_safe, attack_safe = held_off_nav("jump") or held_off_nav("long_jump"), held_off_nav("attack")

        t = self.touch.read() if self.touch and self.touch.active() else None
        if t:
            s.left |= t.left
            s.right |= t.right
            s.up |= t.up
            s.down |= t.down
            s.jump |= t.jump
            s.attack |= t.attack
            start |= t.pause
            jump_safe |= t.jump
            attack_safe |= t.attack

        # run: hold the button, or tap it on and off (the Run Mode setting)
        p = self.prev
        s.run_button = run
        if self.options["run_mode"] == "TOGGLE":
            if self.in_play and run and not p.run_button:
                self.run_latched = not self.run_latched
            run = self.run_latched
        s.run = run or bool(t and t.run)

        s.jump_pressed = s.jump and not p.jump
        s.long_held = long_jump
        s.long_pressed = long_jump and not p.long_held
        s.run_pressed = s.run and not p.run
        s.attack_pressed = s.attack and not p.attack
        s.start_held = start
        s.start_pressed = start and not p.start_held
        s.mute_pressed = mute and not p.mute_held
        s.mute_held = mute
        s.fullscreen_pressed = fullscreen and not p.fullscreen_held
        s.fullscreen_held = fullscreen
        # menu moves: one step per push of the D-pad / stick / arrow keys
        s.up_pressed = s.up and not p.up
        s.down_pressed = s.down and not p.down
        s.left_pressed = s.left and not p.left
        s.right_pressed = s.right and not p.right

        # in menus, Up (which also jumps) must only move the cursor
        s.esc_held = k[pygame.K_ESCAPE]
        s.esc_pressed = s.esc_held and not p.esc_held
        s.jump_is_nav = s.jump and not jump_safe
        s.attack_is_nav = s.attack and not attack_safe
        # these always work in menus, whatever has been rebound
        menu = (k[pygame.K_UP] or "dup" in pad, k[pygame.K_DOWN] or "ddown" in pad,
                k[pygame.K_LEFT] or "dleft" in pad, k[pygame.K_RIGHT] or "dright" in pad,
                (not keys["jump"] and k[pygame.K_SPACE]) or (not pads["jump"] and "a" in pad),
                k[pygame.K_ESCAPE] or k[pygame.K_RETURN] or "start" in pad,
                k[pygame.K_RETURN] or "a" in pad)
        s.menu_held = menu
        s.menu_edge = tuple(now and not old for now, old in zip(menu, p.menu_held))
        self.prev = s
        self.state = s
        return s

    def frozen_frame(self):
        """No input at all: every button must be let go or pressed afresh afterwards."""
        self.prev = self.state = PadInput()


class PadInput(InputState):
    """InputState plus attack, menu moves and pause / mute / fullscreen bookkeeping."""
    __slots__ = ("start_held", "attack", "attack_pressed", "run_button",
                 "up_pressed", "down_pressed", "left_pressed", "right_pressed",
                 "mute_held", "mute_pressed", "fullscreen_held", "fullscreen_pressed",
                 "jump_is_nav", "attack_is_nav", "menu_held", "menu_edge", "enter_pressed", "long_held", "esc_held", "esc_pressed")

    def __init__(self):
        super().__init__()
        self.start_held = False
        self.attack = self.attack_pressed = self.run_button = False
        self.up_pressed = self.down_pressed = self.left_pressed = self.right_pressed = False
        self.mute_held = self.mute_pressed = self.fullscreen_held = self.fullscreen_pressed = False
        self.jump_is_nav = self.attack_is_nav = False
        self.menu_held = self.menu_edge = (False,) * 7
        self.enter_pressed = False
        self.long_held = False
        self.esc_held = self.esc_pressed = False

    def for_menus(self):
        """Turn gameplay input into menu input (called when not playing)."""
        up, down, left, right, ok, back, enter = self.menu_edge
        self.up_pressed = self.up_pressed or up
        self.down_pressed = self.down_pressed or down
        self.left_pressed = self.left_pressed or left
        self.right_pressed = self.right_pressed or right
        self.jump_pressed = (self.jump_pressed and not self.jump_is_nav) or ok
        self.attack_pressed = self.attack_pressed and not self.attack_is_nav
        self.start_pressed = self.start_pressed or back
        self.enter_pressed = enter
