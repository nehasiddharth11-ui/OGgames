"""Tile map and the rules that decide which tiles are solid.

Tile legend
-----------
' '  empty              'X'  ground             'S'  stone block
'B'  brick              '?'  coin block         'M'  power-up block
'F'  feather block      'L'  heart (1-up) block 'H'  hidden heart block
'Q'  multi-coin brick   'U'  used block         'N'  bounce block
'T'  toggle switch      'R'  red toggle block   'b'  blue toggle block
'='  one-way cloud      '^'  spikes             'o'  coin
'[' ']' '{' '}'  pipe top-left / top-right / body-left / body-right
'~'  water (swim)       'V'  lava (burns; swim in it with the yellow potion)
'Y'  yellow potion block 'P'  water potion block  'E'  elytra block
"""

from settings import TILE

SOLID_TILES = frozenset("XSB?MFLQUNT[]{}YPE")
ONEWAY_TILES = frozenset("=")
LIQUID_TILES = frozenset("~V")


class World:
    def __init__(self, rows):
        self.grid = [list(r) for r in rows]
        self.h = len(self.grid)
        self.w = len(self.grid[0])
        self.toggle = 0          # 0 -> red blocks solid, 1 -> blue blocks solid
        self.pixel_w = self.w * TILE
        self.pixel_h = self.h * TILE
        # where the water / lava is, kept apart from the tiles so collecting a
        # coin under water doesn't leave a hole of air behind
        self.liquid = [[c if c in LIQUID_TILES else None for c in r] for r in self.grid]
        for ty in range(self.h):
            for tx in range(self.w):
                if self.grid[ty][tx] == 'o':
                    for nx, ny in ((tx - 1, ty), (tx + 1, ty), (tx, ty - 1)):
                        c = self.get(nx, ny)
                        if c in LIQUID_TILES:
                            self.liquid[ty][tx] = c
                            break

    def get(self, tx, ty):
        if tx < 0 or tx >= self.w:
            return 'S'           # invisible walls at the level edges
        if ty < 0 or ty >= self.h:
            return ' '
        return self.grid[ty][tx]

    def set(self, tx, ty, ch):
        if 0 <= tx < self.w and 0 <= ty < self.h:
            self.grid[ty][tx] = ch

    def is_solid(self, tx, ty, from_below=False):
        c = self.get(tx, ty)
        if c in SOLID_TILES:
            return True
        if c == 'R':
            return self.toggle == 0
        if c == 'b':
            return self.toggle == 1
        if c == 'H':
            return from_below    # hidden blocks only exist when hit from below
        return False

    def is_oneway(self, tx, ty):
        return self.get(tx, ty) in ONEWAY_TILES

    def is_support(self, tx, ty):
        return self.is_solid(tx, ty) or self.is_oneway(tx, ty)

    def rect_hits_solid(self, x, y, w, h):
        x0, x1 = int(x // TILE), int((x + w - 0.001) // TILE)
        y0, y1 = int(y // TILE), int((y + h - 0.001) // TILE)
        for ty in range(y0, y1 + 1):
            for tx in range(x0, x1 + 1):
                if self.is_solid(tx, ty):
                    return True
        return False

    def liquid_at(self, px, py):
        """'~' (water), 'V' (lava) or None at a pixel position."""
        tx, ty = int(px // TILE), int(py // TILE)
        if 0 <= tx < self.w and 0 <= ty < self.h:
            return self.liquid[ty][tx]
        return None

    def touches_lava(self, x, y, w, h):
        """Lava burns as soon as Pip's feet dip 4 px into it."""
        x0, x1 = int(x // TILE), int((x + w - 0.001) // TILE)
        y0, y1 = int(y // TILE), int((y + h - 0.001) // TILE)
        for ty in range(y0, y1 + 1):
            for tx in range(x0, x1 + 1):
                if 0 <= tx < self.w and 0 <= ty < self.h and self.liquid[ty][tx] == 'V' \
                        and y + h > ty * TILE + 4:
                    return True
        return False

    def touches_hazard(self, x, y, w, h):
        """Spikes occupy the lower 10 px of their tile."""
        x0, x1 = int(x // TILE), int((x + w - 0.001) // TILE)
        y0, y1 = int(y // TILE), int((y + h - 0.001) // TILE)
        for ty in range(y0, y1 + 1):
            for tx in range(x0, x1 + 1):
                if self.get(tx, ty) == '^' and y + h > ty * TILE + 6:
                    return True
        return False
