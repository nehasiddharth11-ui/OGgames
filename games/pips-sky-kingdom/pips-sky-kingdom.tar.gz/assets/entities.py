"""Enemies, items, projectiles, platforms and effects."""

import math
import random

import pygame

from settings import TILE, SCREEN_W, SCREEN_H, SMALL, BIG, FIRE, FEATHER
from physics import move_body

ENEMY_GRAVITY = 0.3
ENEMY_MAX_FALL = 4.5


class Entity:
    stompable = False
    harmful = False
    burns = False              # fire hurts: the yellow potion protects against it
    kill_by_fire = False
    kill_by_shell = False
    is_enemy = False
    always_active = False

    def __init__(self, x, y, w, h):
        self.x, self.y, self.w, self.h = float(x), float(y), w, h
        self.vx = self.vy = 0.0
        self.on_ground = False
        self.alive = True
        self.dead = False          # playing the "flip and fall" death
        self.active = False

    @classmethod
    def at_tile(cls, tx, ty, *args):
        """Create so that the entity stands on the bottom of tile (tx, ty)."""
        e = cls(0, 0, *args)
        e.x = tx * TILE + (TILE - e.w) / 2
        e.y = (ty + 1) * TILE - e.h
        return e

    def overlaps(self, o):
        return (self.x < o.x + o.w and self.x + self.w > o.x and
                self.y < o.y + o.h and self.y + self.h > o.y)

    def walk_physics(self, world, turn_at_ledges=False):
        self.vy = min(self.vy + ENEMY_GRAVITY, ENEMY_MAX_FALL)
        if turn_at_ledges and self.on_ground and self.vx:
            ahead = self.x + self.w + 1 if self.vx > 0 else self.x - 1
            foot = int((self.y + self.h + 2) // TILE)
            if not world.is_support(int(ahead // TILE), foot):
                self.vx = -self.vx
        hits = move_body(self, world, self.vx, self.vy)
        if hits.left or hits.right:
            self.vx = -self.vx
        if hits.bottom:
            self.vy = 0
        self.on_ground = hits.bottom
        return hits

    def kill(self, game, points=100):
        """Knocked out by a shell, fireball, spin or bumped block."""
        if self.dead:
            return
        self.dead = True
        self.vy = -3.5
        self.vx = 0.8 if random.random() < 0.5 else -0.8
        game.add_score(points, self.x, self.y)

    def update_dead(self):
        self.vy += 0.25
        self.x += self.vx
        self.y += self.vy

    def update(self, game):
        pass

    def draw(self, surf, game):
        pass

    def blit(self, surf, game, img, dx=0, dy=0, flip_v=False):
        if flip_v or self.dead:
            img = pygame.transform.flip(img, False, True)
        surf.blit(img, (round(self.x - game.cam_x + dx), round(self.y - game.cam_y + dy)))


# ---------------------------------------------------------------------------
# Enemies
# ---------------------------------------------------------------------------
class Nutling(Entity):
    stompable = harmful = kill_by_fire = kill_by_shell = is_enemy = True

    def __init__(self, x, y):
        super().__init__(x, y, 14, 14)
        self.vx = -0.5
        self.squash = 0
        self.anim = 0

    def stomp(self, game):
        self.squash = 30
        self.harmful = False
        self.stompable = False
        self.kill_by_fire = self.kill_by_shell = False
        game.audio.play("stomp")

    def update(self, game):
        if self.squash:
            self.squash -= 1
            if self.squash == 0:
                self.alive = False
            return
        self.walk_physics(game.world)
        self.anim += 1

    def draw(self, surf, game):
        a = game.assets
        if self.squash:
            self.blit(surf, game, a.nutling_flat, -1, self.h - 7)
        else:
            self.blit(surf, game, a.nutling[(self.anim // 10) % 2], -1, -2)


class Shellback(Entity):
    stompable = harmful = kill_by_fire = kill_by_shell = is_enemy = True
    SLIDE_SPEED = 3.6

    def __init__(self, x, y):
        super().__init__(x, y, 14, 14)
        self.vx = -0.45
        self.state = "walk"        # walk | shell | slide
        self.timer = 0
        self.grace = 0
        self.anim = 0
        self.combo = 0

    def stomp(self, game):
        game.audio.play("stomp")
        if self.state in ("walk", "slide"):
            self.state = "shell"
            self.vx = 0
            self.timer = 480
            self.grace = 8
        else:
            self.kick(game, 1 if game.player.x + game.player.w / 2 < self.x + self.w / 2 else -1)

    def kick(self, game, direction):
        self.state = "slide"
        self.vx = direction * self.SLIDE_SPEED
        self.grace = 12
        self.combo = 0
        game.audio.play("kick")
        game.add_score(100, self.x, self.y)

    def touch_harmful(self):
        if self.state == "shell":
            return False
        if self.state == "slide" and self.grace > 0:
            return False
        return True

    def update(self, game):
        if self.grace:
            self.grace -= 1
        w = game.world
        if self.state == "walk":
            self.walk_physics(w, turn_at_ledges=True)
            self.anim += 1
        elif self.state == "shell":
            self.walk_physics(w)
            self.timer -= 1
            if self.timer <= 0:
                self.state = "walk"
                self.vx = -0.45 if game.player.x < self.x else 0.45
        else:
            prev_vx = self.vx
            hits = self.walk_physics(w)
            if hits.left or hits.right:
                # smash bricks / activate blocks the shell slams into
                tx = int((self.x + (self.w + 1 if prev_vx > 0 else -1)) // TILE)
                for ty in {int(self.y // TILE), int((self.y + self.h - 1) // TILE)}:
                    game.hit_block(tx, ty, from_shell=True)
                game.audio.play("bump")
            # knock out other enemies
            for e in game.entities:
                if e is not self and e.is_enemy and not e.dead and e.kill_by_shell and e.overlaps(self):
                    self.combo += 1
                    e.kill(game, 100 * (2 ** min(self.combo, 6)))
                    game.audio.play("shell_hit")
            if abs(self.x - game.cam_x - SCREEN_W / 2) > SCREEN_W:
                self.alive = False

    def draw(self, surf, game):
        a = game.assets
        if self.state == "walk":
            face = 1 if self.vx > 0 else -1
            self.blit(surf, game, a.shellback[face][(self.anim // 10) % 2], -1, -2)
        else:
            wobble = 1 if self.state == "shell" and self.timer < 90 and (self.timer // 4) % 2 else 0
            self.blit(surf, game, a.shell, -1 + wobble, -2)


class Flapper(Entity):
    stompable = harmful = kill_by_fire = kill_by_shell = is_enemy = True

    def __init__(self, x, y):
        super().__init__(x, y, 14, 10)
        self.base_y = None
        self.t = random.random() * 6
        self.vx = -0.35

    def stomp(self, game):
        game.audio.play("stomp")
        self.kill(game, 200)

    def update(self, game):
        if self.base_y is None:
            self.base_y = self.y
        self.t += 0.05
        p = game.player
        target = -0.45 if p.x < self.x else 0.45
        self.vx += (target - self.vx) * 0.01
        self.x += self.vx
        self.y = self.base_y + math.sin(self.t) * 18

    def draw(self, surf, game):
        img = game.assets.flapper[int(self.t * 3) % 2]
        if self.vx > 0:
            img = pygame.transform.flip(img, True, False)
        self.blit(surf, game, img, -1, -1)


class Jelly(Flapper):
    """A jellyfish that bobs up and down in the water. It stings: swim around it."""
    stompable = False

    def update(self, game):
        if self.base_y is None:
            self.base_y = self.y
        self.t += 0.03
        self.y = self.base_y + math.sin(self.t) * 22

    def draw(self, surf, game):
        self.blit(surf, game, game.assets.jelly[int(self.t * 4) % 2], -1, -3)


class Cinder(Entity):
    """A fire sprite that hides in the lava and leaps out of it. It burns, so
    only the yellow potion makes it safe to touch."""
    harmful = is_enemy = True
    burns = True
    always_active = True

    def __init__(self, x, y):
        super().__init__(x, y, 10, 10)
        self.home_y = None
        self.timer = random.randint(30, 150)
        self.t = 0

    def update(self, game):
        self.t += 1
        if self.home_y is None:
            self.home_y = self.y + 6            # resting a little under the surface
            self.y = self.home_y
        if self.vy == 0 and self.y >= self.home_y:
            self.timer -= 1
            if self.timer <= 0:
                self.vy = -6.2
                self.timer = 150
            return
        self.vy += 0.2
        self.y += self.vy
        if self.y >= self.home_y:
            self.y = self.home_y
            self.vy = 0

    def draw(self, surf, game):
        if self.vy == 0 and self.y >= self.home_y:
            return                              # hidden in the lava
        img = game.assets.cinder[(self.t // 4) % 2]
        self.blit(surf, game, img, -3, -3, flip_v=self.vy > 0)


class Snapvine(Entity):
    harmful = kill_by_fire = kill_by_shell = is_enemy = True

    def __init__(self, x, y):
        super().__init__(x, y, 12, 18)
        self.home_y = None
        self.timer = 90
        self.phase = "hidden"     # hidden | rising | out | sinking
        self.offset = 0.0         # pixels risen out of the pipe
        self.anim = 0

    @classmethod
    def on_pipe(cls, tx, ty):
        e = cls(0, 0)
        e.x = (tx + 1) * TILE - e.w / 2
        e.home_y = ty * TILE      # top of the pipe
        e.y = e.home_y
        return e

    def update(self, game):
        self.anim += 1
        p = game.player
        near = abs((p.x + p.w / 2) - (self.x + self.w / 2)) < 30
        if self.phase == "hidden":
            self.timer -= 1
            if self.timer <= 0 and not near:
                self.phase = "rising"
        elif self.phase == "rising":
            self.offset += 0.6
            if self.offset >= 20:
                self.offset = 20
                self.phase, self.timer = "out", 80
        elif self.phase == "out":
            self.timer -= 1
            if self.timer <= 0:
                self.phase = "sinking"
        else:
            self.offset -= 0.6
            if self.offset <= 0:
                self.offset = 0
                self.phase, self.timer = "hidden", 100
        self.y = self.home_y - self.offset
        self.h = max(1, int(self.offset))
        self.harmful = self.offset > 2

    def draw(self, surf, game):
        if self.offset <= 0:
            return
        img = game.assets.plant[(self.anim // 12) % 2]
        visible = int(self.offset)
        if self.dead:
            self.blit(surf, game, img, -2, 0)
            return
        area = pygame.Rect(0, 0, 16, visible)
        surf.blit(img, (round(self.x - 2 - game.cam_x), round(self.home_y - visible - game.cam_y)), area)


# ---------------------------------------------------------------------------
# Items
# ---------------------------------------------------------------------------
class Item(Entity):
    always_active = True

    def __init__(self, x, y, kind):
        super().__init__(x, y, 14, 14)
        self.kind = kind
        self.emerge = 16.0        # pixels left to rise out of the block
        self.t = 0
        self.vx = 0.0
        if kind == "feather":
            self.emerge = 0
            self.vy = -3.0
        self.base_y = None

    FLOATERS = ("fire_potion", "water_potion", "elytra")   # stay above their block

    def update(self, game):
        self.t += 1
        if self.emerge > 0:
            self.y -= 0.5
            self.emerge -= 0.5
            if self.emerge <= 0 and self.kind in ("sunfruit", "heart"):
                self.vx = 1.0 if game.player.x < self.x else -1.0
            return
        if self.kind in self.FLOATERS:
            if self.base_y is None:
                self.base_y = self.y
            self.y = self.base_y + math.sin(self.t * 0.08) * 1.5
            return
        if self.kind in ("sunfruit", "heart"):
            self.walk_physics(game.world)
        elif self.kind == "feather":
            if self.vy < 0:
                self.vy += 0.15
                self.y += self.vy
            else:
                self.x += math.sin(self.t * 0.06) * 1.2
                self.y += 0.45
        if self.y > game.world.pixel_h:
            self.alive = False

    def draw(self, surf, game):
        a = game.assets
        img = {"sunfruit": a.sunfruit, "ember": a.ember, "feather": a.feather, "heart": a.heart,
               "fire_potion": a.fire_potion, "water_potion": a.water_potion, "elytra": a.elytra}[self.kind]
        if self.emerge > 0:
            shown = int(16 - self.emerge)
            area = pygame.Rect(0, 0, 16, shown)
            surf.blit(img, (round(self.x - 1 - game.cam_x), round(self.y - game.cam_y)), area)
        else:
            self.blit(surf, game, img, -1, -2)


class CoinPop(Entity):
    always_active = True

    def __init__(self, x, y):
        super().__init__(x, y, 16, 16)
        self.vy = -5.0
        self.t = 0

    def update(self, game):
        self.t += 1
        self.vy += 0.3
        self.y += self.vy
        if self.t > 30:
            self.alive = False
            game.particles.append(Sparkle(self.x + 8, self.y + 8))

    def draw(self, surf, game):
        self.blit(surf, game, game.assets.coin[(self.t // 3) % 4])


class Fireball(Entity):
    always_active = True

    def __init__(self, x, y, direction):
        super().__init__(x, y, 8, 8)
        self.vx = 3.8 * direction
        self.vy = 1.5
        self.t = 0

    def update(self, game):
        self.t += 1
        self.vy = min(self.vy + 0.35, 4)
        hits = move_body(self, game.world, self.vx, self.vy)
        if hits.bottom:
            self.vy = -3.2
        if hits.left or hits.right or hits.top or self.t > 240:
            self.alive = False
            game.particles.append(Puff(self.x + 4, self.y + 4))
            game.audio.play("bump")
            return
        for e in game.entities:
            if e.is_enemy and not e.dead and e.kill_by_fire and e.overlaps(self):
                e.kill(game, 200)
                game.audio.play("kick")
                self.alive = False
                game.particles.append(Puff(self.x + 4, self.y + 4))
                return
        if abs(self.x - game.cam_x - SCREEN_W / 2) > SCREEN_W:
            self.alive = False

    def draw(self, surf, game):
        self.blit(surf, game, game.assets.fireball[(self.t // 3) % 4])


# ---------------------------------------------------------------------------
# Level objects
# ---------------------------------------------------------------------------
class Platform(Entity):
    always_active = True

    def __init__(self, tx, ty, width=3, axis="x", rng=4, speed=0.02):
        super().__init__(tx * TILE, ty * TILE, width * TILE, 8)
        self.bx, self.by = self.x, self.y
        self.axis, self.range, self.speed = axis, rng * TILE, speed
        self.phase = 0.0
        self.dx = self.dy = 0.0

    def update(self, game):
        self.phase += self.speed
        off = (1 - math.cos(self.phase)) / 2 * self.range
        nx = self.bx + (off if self.axis == "x" else 0)
        ny = self.by + (off if self.axis == "y" else 0)
        self.dx, self.dy = nx - self.x, ny - self.y
        self.x, self.y = nx, ny

    def draw(self, surf, game):
        r = pygame.Rect(round(self.x - game.cam_x), round(self.y - game.cam_y), self.w, self.h)
        pygame.draw.rect(surf, (250, 210, 120), r)
        pygame.draw.rect(surf, (150, 90, 40), r, 1)
        for i in range(r.x + 4, r.right - 2, 8):
            pygame.draw.line(surf, (200, 140, 70), (i, r.y + 2), (i, r.bottom - 3))


class Checkpoint(Entity):
    always_active = True

    def __init__(self, tx, ty, index):
        super().__init__(tx * TILE + 4, (ty + 1) * TILE - 32, 8, 32)
        self.index = index
        self.reached = False
        self.wave = 0

    def update(self, game):
        self.wave += 1
        if not self.reached and self.overlaps(game.player) and not game.player.dying:
            self.reached = True
            game.reach_checkpoint(self)

    def draw(self, surf, game):
        x = round(self.x - game.cam_x)
        y = round(self.y - game.cam_y)
        pygame.draw.rect(surf, (230, 230, 240), (x + 3, y, 2, 32))
        pygame.draw.circle(surf, (255, 220, 60), (x + 4, y), 2)
        col = (80, 220, 110) if self.reached else (200, 200, 210)
        h = 0 if self.reached else 16
        wv = int(math.sin(self.wave * 0.15) * 1.5)
        pts = [(x + 5, y + 2 + h), (x + 17, y + 6 + h + wv), (x + 5, y + 11 + h)]
        pygame.draw.polygon(surf, col, pts)


class Goal(Entity):
    always_active = True
    ICONS = ("sun", "moon", "star")

    def __init__(self, tx, ty):
        super().__init__(tx * TILE, ty * TILE, 32, 32)
        self.t = 0
        self.taken = None

    def current_icon(self):
        return self.ICONS[(self.t // 8) % 3]

    def update(self, game):
        self.t += 1
        if self.taken is None and self.overlaps(game.player) and not game.player.dying:
            self.taken = self.current_icon()
            game.course_clear(self.taken)

    def draw(self, surf, game):
        x = round(self.x - game.cam_x)
        y = round(self.y - game.cam_y)
        glow = 120 + int(60 * math.sin(self.t * 0.1))
        pygame.draw.rect(surf, (40, 30, 80), (x, y, 32, 32))
        pygame.draw.rect(surf, (glow, glow, 255), (x, y, 32, 32), 2)
        pygame.draw.rect(surf, (255, 255, 255), (x + 4, y + 4, 24, 24), 1)
        if self.taken is None:
            icon = game.assets.goal_icons[self.current_icon()]
            surf.blit(icon, (x + 8, y + 8))
        for k in range(4):
            a = self.t * 0.05 + k * math.pi / 2
            px = x + 16 + math.cos(a) * 22
            py = y + 16 + math.sin(a) * 22
            pygame.draw.circle(surf, (255, 250, 180), (int(px), int(py)), 1)


# ---------------------------------------------------------------------------
# Particles (visual only)
# ---------------------------------------------------------------------------
class Particle:
    def __init__(self, x, y):
        self.x, self.y = x, y
        self.alive = True
        self.t = 0

    def update(self):
        self.t += 1


class BrickShard(Particle):
    def __init__(self, x, y, vx, vy):
        super().__init__(x, y)
        self.vx, self.vy = vx, vy

    def update(self):
        super().update()
        self.vy += 0.25
        self.x += self.vx
        self.y += self.vy
        if self.t > 90:
            self.alive = False

    def draw(self, surf, game):
        r = pygame.Rect(round(self.x - game.cam_x), round(self.y - game.cam_y), 5, 5)
        pygame.draw.rect(surf, (206, 96, 46), r)
        pygame.draw.rect(surf, (110, 44, 20), r, 1)


class Sparkle(Particle):
    def update(self):
        super().update()
        if self.t > 16:
            self.alive = False

    def draw(self, surf, game):
        x, y = round(self.x - game.cam_x), round(self.y - game.cam_y)
        r = 1 + self.t // 4
        c = (255, 255, 200)
        pygame.draw.line(surf, c, (x - r, y), (x + r, y))
        pygame.draw.line(surf, c, (x, y - r), (x, y + r))


class Puff(Particle):
    def update(self):
        super().update()
        if self.t > 14:
            self.alive = False

    def draw(self, surf, game):
        x, y = round(self.x - game.cam_x), round(self.y - game.cam_y)
        pygame.draw.circle(surf, (255, 255, 255), (x, y), 2 + self.t // 3, 1)


class Bubble(Particle):
    """Air bubbles rising from Pip under water."""

    def update(self):
        super().update()
        self.y -= 0.7
        self.x += math.sin(self.t * 0.3) * 0.3
        if self.t > 40:
            self.alive = False

    def draw(self, surf, game):
        x, y = round(self.x - game.cam_x), round(self.y - game.cam_y)
        pygame.draw.circle(surf, (220, 240, 255), (x, y), 2, 1)


class Dust(Particle):
    def update(self):
        super().update()
        self.y -= 0.3
        if self.t > 12:
            self.alive = False

    def draw(self, surf, game):
        x, y = round(self.x - game.cam_x), round(self.y - game.cam_y)
        pygame.draw.circle(surf, (240, 240, 230), (x, y), max(1, 3 - self.t // 4))


class LandDust(Particle):
    """A puff of ground-coloured dust when Pip lands after a long drop."""

    def __init__(self, x, y, vx, vy, color):
        super().__init__(x, y)
        self.vx, self.vy, self.color = vx, vy, color

    def update(self):
        super().update()
        self.vy += 0.07
        self.vx *= 0.93
        self.x += self.vx
        self.y += self.vy
        if self.t > 26:
            self.alive = False

    def draw(self, surf, game):
        r = 3 if self.t < 9 else (2 if self.t < 18 else 1)   # shrinks as it settles
        x, y = round(self.x - game.cam_x), round(self.y - game.cam_y)
        surf.fill(self.color, (x - r // 2, y - r // 2, r, r))


class ScorePopup(Particle):
    def __init__(self, x, y, text):
        super().__init__(x, y)
        self.text = text

    def update(self):
        super().update()
        self.y -= 0.6
        if self.t > 45:
            self.alive = False

    def draw(self, surf, game):
        game._text(surf, self.text, self.x - game.cam_x, self.y - game.cam_y,
                   font=game.small_font)


def spawn_from_level(kind, tx, ty, extra):
    if kind == "nutling":
        return Nutling.at_tile(tx, ty)
    if kind == "shellback":
        return Shellback.at_tile(tx, ty)
    if kind == "flapper":
        return Flapper.at_tile(tx, ty)
    if kind == "jelly":
        return Jelly.at_tile(tx, ty)
    if kind == "cinder":
        return Cinder.at_tile(tx, ty)
    if kind == "snapvine":
        return Snapvine.on_pipe(tx, ty)
    if kind == "platform":
        return Platform(tx, ty, extra["width"], extra["axis"], extra["range"], extra["speed"])
    if kind == "checkpoint":
        return Checkpoint(tx, ty, extra)
    raise ValueError(kind)
