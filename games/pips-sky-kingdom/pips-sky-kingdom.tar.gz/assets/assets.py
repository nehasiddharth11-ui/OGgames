"""All graphics, generated in code. Every character here is original art."""

import math
import pygame

from settings import TILE, SMALL, BIG, FIRE, FEATHER, ELYTRA


def grid_surface(rows, palette, width=16):
    surf = pygame.Surface((width, len(rows)), pygame.SRCALPHA)
    for y, row in enumerate(rows):
        row = row.ljust(width, '.')[:width]
        for x, ch in enumerate(row):
            if ch != '.':
                surf.set_at((x, y), palette[ch])
    return surf


def flip(s):
    return pygame.transform.flip(s, True, False)


# ---------------------------------------------------------------------------
# Pip, the hero
# ---------------------------------------------------------------------------
PIP_BASE = {
    'K': (44, 26, 36), 'O': (244, 146, 52), 'o': (196, 104, 34),
    'W': (255, 238, 204), 'G': (78, 184, 92), 'g': (40, 122, 62),
    'L': (150, 230, 90), 'E': (255, 255, 255), 'P': (24, 20, 44),
    'C': (255, 140, 160), 'S': (228, 58, 72), 'B': (122, 72, 40),
}
FORM_SWAPS = {
    SMALL: {}, BIG: {},
    FIRE: {'G': (232, 74, 48), 'g': (150, 34, 26), 'S': (255, 206, 60),
           'L': (255, 190, 60), 'W': (255, 246, 222)},
    FEATHER: {'G': (110, 170, 250), 'g': (56, 98, 196), 'S': (250, 250, 255),
              'L': (200, 230, 255)},
    ELYTRA: {'G': (120, 84, 170), 'g': (70, 44, 110), 'S': (90, 220, 210),
             'L': (180, 150, 230)},
}

PIP_HEAD = [
    "......LL........",
    ".....LLg........",
    "....KKKKKKK.....",
    "...KGGGGGGGK....",
    "..KGGGGGGGGgK...",
    "..KGGOOOOOOgK...",
    "..KGOOOEPOEPK...",
    "..KOOOOEPOEPK...",
    "..KOOCOOOOOCK...",
    "...KOOOOOKOK....",
]
SMALL_BODY = [
    "...KSSSSSSSK....",
    "..KOKWWWWWKOK...",
    "..KOKWWWWWKOK...",
    "...KoWWWWWoK....",
]
SMALL_LEGS = {
    "stand": ["...KBBK.KBBK....", "...KKKK.KKKK...."],
    "walk1": ["..KBBK...KBBK...", "..KKKK...KKKK..."],
    "walk2": ["....KBBKKBBK....", "....KKKKKKKK...."],
    "jump":  ["..KBBK....KBBK..", "..KKK......KKK.."],
}
BIG_BODY = [
    "...KSSSSSSSSK...",
    "..KOKWWWWWWKOK..",
    "..KOKWWWWWWKOK..",
    ".KOOKWWWWWWKOOK.",
    ".KOOKWWWWWWKOOK.",
    ".KOOKWWWWWWKOOK.",
    "..KKKWWWWWWKKK..",
    "....KWWWWWWK....",
    "....KoWWWWoK....",
    "....KooooooK....",
    "....KoooKooK....",
]
BIG_LEGS = {
    "stand": ["....KooKKooK....", "....KooKKooK....", "....KBBKKBBK....",
              "....KBBKKBBK....", "...KBBBKKBBBK...", "...KKKKK.KKKK..."],
    "walk1": ["...KooK..KooK...", "...KooK..KooK...", "..KBBK....KBBK..",
              "..KBBK....KBBK..", "..KBBBK...KBBBK.", "..KKKKK...KKKKK."],
    "walk2": ["....KooKKooK....", ".....KoooooK....", ".....KBBBBK.....",
              ".....KBBBBK.....", "....KBBBBBBK....", "....KKKKKKKK...."],
    "jump":  ["...KooK..KooK...", "..KooK....KooK..", "..KBBK....KBBK..",
              ".KBBK......KBBK.", ".KBBBK.....KBBBK", ".KKKKK.....KKKKK"],
}


def make_pip_frames():
    """frames[form][pose][facing] -> Surface, facing 1 (right) or -1."""
    frames = {}
    for form in (SMALL, BIG, FIRE, FEATHER, ELYTRA):
        pal = dict(PIP_BASE)
        pal.update(FORM_SWAPS[form])
        frames[form] = {}
        for pose in ("stand", "walk1", "walk2", "jump"):
            if form == SMALL:
                rows = PIP_HEAD + SMALL_BODY + SMALL_LEGS[pose]
            else:
                rows = PIP_HEAD + BIG_BODY + BIG_LEGS[pose]
            s = grid_surface(rows, pal)
            if form == FEATHER:
                s = add_wings(s, up=(pose == "jump"))
            elif form == ELYTRA:
                s = add_elytra(s, spread=(pose == "jump"))
            frames[form][pose] = {1: s, -1: flip(s)}
    return frames


def add_elytra(s, spread):
    """Two long wing cases on Pip's back (facing right); spread wide when gliding."""
    out = pygame.Surface((s.get_width(), s.get_height()), pygame.SRCALPHA)
    body, edge, shine = (96, 70, 150), (40, 26, 70), (170, 140, 230)
    if spread:
        wing = [(6, 11), (0, 8), (0, 12), (2, 20), (6, 17)]
    else:
        wing = [(5, 11), (2, 12), (1, 20), (3, 24), (5, 20)]
    pygame.draw.polygon(out, body, wing)
    pygame.draw.polygon(out, edge, wing, 1)
    pygame.draw.line(out, shine, wing[0], wing[2] if spread else wing[3])
    out.blit(s, (0, 0))
    return out


def add_wings(s, up):
    """Little white wings on Pip's back for the feather form (facing right)."""
    out = s.copy()
    w = (250, 250, 255)
    k = (90, 120, 190)
    y = 12
    pts = [(0, y), (1, y - 1), (2, y - 2), (3, y - 2), (1, y + 1), (2, y), (3, y)] if up else \
          [(0, y + 2), (1, y + 2), (2, y + 1), (3, y + 1), (1, y + 3), (2, y + 2), (3, y + 2)]
    for px, py in pts:
        out.set_at((px, py), w)
    out.set_at((pts[0][0], pts[0][1]), k)
    return out


# ---------------------------------------------------------------------------
# Enemies
# ---------------------------------------------------------------------------
NUT_PAL = {'K': (40, 22, 20), 'C': (170, 108, 50), 'c': (118, 70, 32),
           'N': (234, 184, 112), 'n': (190, 138, 78), 'E': (255, 255, 255),
           'P': (20, 10, 10), 'F': (92, 52, 30)}
NUTLING = [
    ".......KK.......",
    ".......Kc.......",
    "....KKKKKKKK....",
    "...KCCCCCCCCK...",
    "..KCcCcCcCcCCK..",
    "..KKKKKKKKKKKK..",
    "..KNNNNNNNNNNK..",
    "..KNEEPNNPEENK..",
    "..KNEPKNNKPENK..",
    "..KNNNNNNNNNNK..",
    "..KnNNKKKKNNnK..",
    "...KnNNNNNNnK...",
    "....KnnnnnnK....",
]
NUT_FEET = [
    ["...KFFKKKKFFK...", "..KFFFK..KFFFK..", "..KKKKK..KKKKK.."],
    ["....KFFKKFFK....", "...KFFFKKFFFK...", "...KKKKKKKKKK..."],
]

SHELL_PAL = {'K': (20, 30, 50), 'H': (64, 172, 210), 'h': (30, 108, 152),
             'Y': (250, 222, 96), 'D': (250, 204, 128), 'E': (255, 255, 255),
             'P': (10, 10, 30)}
SHELLBACK_TOP = [
    "................",
    "................",
    "......KKKKK.....",
    "....KKHHHHHKK...",
    "...KHHhHHHhHHK..",
    "..KHHhHHHHHhHHK.",
    ".KKHHHHHhHHHHHK.",
    "KDDKHHHHhHHHHHK.",
    "KEPDKHHHHHHHHHK.",
    "KDDDKKKKKKKKKKK.",
    ".KDDKYYYYYYYYK..",
    "..KKYYYYYYYYYK..",
    "...KKKKKKKKKK...",
]
SHELLBACK_FEET = [
    ["...KDK..KDK.....", "..KDDK.KDDK.....", "..KKKK.KKKK....."],
    ["....KDK..KDK....", "...KDDK.KDDK....", "...KKKK.KKKK...."],
]
SHELL = [
    "................",
    "................",
    "................",
    "......KKKKK.....",
    "....KKHHHHHKK...",
    "...KHHhHHHhHHK..",
    "..KHHhHHHHHhHHK.",
    "..KHHHHHhHHHHHK.",
    "..KHHHHHhHHHHHK.",
    "..KKKKKKKKKKKKK.",
    "..KYYYYYYYYYYYK.",
    "...KYYYYYYYYYK..",
    "....KKKKKKKKK...",
    "................",
    "................",
    "................",
]

BAT_PAL = {'K': (34, 16, 46), 'V': (156, 86, 206), 'v': (96, 44, 146),
           'E': (255, 255, 255), 'P': (20, 0, 20), 'Y': (255, 200, 60)}
FLAPPER_UP = [
    "................",
    ".V............V.",
    ".VV..........VV.",
    ".VVV..KKKK..VVV.",
    "..VVVKVVVVKVVV..",
    "..vVKVVVVVVKVv..",
    "...KVEPVVEPVK...",
    "...KVVVYYVVVK...",
    "...KvVVYYVVvK...",
    "....KvVVVVvK....",
    ".....KKKKKK.....",
    "......K..K......",
]
FLAPPER_DOWN = [
    "................",
    "................",
    "................",
    "......KKKK......",
    ".....KVVVVK.....",
    "....KVVVVVVK....",
    "...KVEPVVEPVK...",
    ".VVKVVVYYVVVKVV.",
    "VVVKvVVYYVVvKVVV",
    "VV..KvVVVVvK..VV",
    "V....KKKKKK....V",
    "......K..K......",
]

PLANT_PAL = {'K': (40, 10, 30), 'R': (224, 64, 146), 'r': (150, 30, 92),
             'T': (255, 255, 255), 'k': (70, 0, 24), 'L': (90, 200, 80),
             'l': (40, 130, 50)}
PLANT_OPEN = [
    "....KKKKKKKK....",
    "...KRRRRRRRRK...",
    "..KRRrRRRRrRRK..",
    "..KRRRRRRRRRRK..",
    "..KTKTKTKTKTTK..",
    "..KkkkkkkkkkkK..",
    "..KkkkkkkkkkkK..",
    "..KTKTKTKTKTTK..",
    "..KRRRRRRRRRRK..",
    "...KRRrRRrRRK...",
    "....KKKKKKKK....",
    "......KllK......",
    "...KLLKllKLLK...",
    "..KLLLLKlKLLLK..",
    "...KKKKlLKKKK...",
    "......KlLK......",
    "......KlLK......",
    "......KlLK......",
    "......KlLK......",
    "......KlLK......",
]
PLANT_CLOSED = PLANT_OPEN[:4] + [
    "..KRRRRRRRRRRK..",
    "..KTTTTTTTTTTK..",
    "..KRRRRRRRRRRK..",
    "..KRRRRRRRRRRK..",
] + PLANT_OPEN[8:]


# ---------------------------------------------------------------------------
# Items
# ---------------------------------------------------------------------------
SUNFRUIT = [
    "........KK......",
    ".......KlK......",
    "....KKKKLLK.....",
    "...KYYYYKKK.....",
    "..KYWYYYYYYK....",
    ".KYWWYYYYYYYK...",
    ".KYWYYYYYYYYK...",
    ".KYYYYYYYYYYK...",
    ".KYYYYYYYYYyK...",
    ".KYYYYYYYYyyK...",
    "..KYYYYYYyyK....",
    "..KyYYYYyyyK....",
    "...KKyyyyKK.....",
    ".....KKKK.......",
]
SUN_PAL = {'K': (60, 30, 10), 'Y': (255, 204, 44), 'y': (214, 140, 22),
           'W': (255, 255, 230), 'L': (110, 210, 80), 'l': (50, 130, 50)}

EMBER = [
    "......ff........",
    ".....fFf........",
    "....KFfFK.......",
    "...KKKKKKK......",
    "..KRRRRRRRK.....",
    ".KRWRRRRRRRK....",
    ".KRWRRRRRRRK....",
    ".KRRRRRRRRrK....",
    ".KRRRRRRRrrK....",
    "..KRRRRRrrK.....",
    "...KKKKKKK......",
]
EMBER_PAL = {'K': (60, 10, 10), 'R': (232, 44, 64), 'r': (160, 20, 40),
             'W': (255, 220, 220), 'F': (255, 160, 40), 'f': (255, 232, 96)}

FEATHER_ITEM = [
    "..........KK....",
    ".........KWWK...",
    "........KWWBK...",
    ".......KWWBBK...",
    "......KWWBBK....",
    ".....KWWBBK.....",
    "....KWWBBK......",
    "...KWWBBK.......",
    "..KWWBBK........",
    "..KWBBK.........",
    ".KKKKK..........",
    "KK..............",
]
FEATHER_PAL = {'K': (40, 60, 120), 'W': (255, 255, 255), 'B': (120, 180, 255)}

HEART = [
    "................",
    "..KKKK...KKKK...",
    ".KRRRRK.KRRRRK..",
    "KRWWRRRKRRRRRRK.",
    "KRWRRRRRRRRRRRK.",
    "KRRRRRRRRRRRRRK.",
    ".KRRRRRRRRRRRK..",
    "..KRRRRRRRRRK...",
    "...KRRRRRRRK....",
    "....KRRRRRK.....",
    ".....KRRRK......",
    "......KRK.......",
    ".......K........",
]
HEART_PAL = {'K': (70, 10, 30), 'R': (255, 80, 120), 'W': (255, 230, 240)}

POTION = [
    "......KKKK......",
    "......KccK......",
    "......KWWK......",
    ".....KKWWKK.....",
    "....KWWWWWWK....",
    "...KWLLLLLLWK...",
    "..KWLLHLLLLLWK..",
    "..KWLHLLLLLLWK..",
    "..KWLLLLLLLLWK..",
    "..KWLLLLLLLDWK..",
    "...KWLLLLLDWK...",
    "....KKKKKKKK....",
]
FIRE_POTION_PAL = {'K': (70, 40, 10), 'c': (150, 90, 40), 'W': (255, 255, 240),
                   'L': (255, 214, 40), 'H': (255, 250, 200), 'D': (220, 150, 20)}
WATER_POTION_PAL = {'K': (16, 40, 90), 'c': (150, 90, 40), 'W': (240, 250, 255),
                    'L': (60, 150, 255), 'H': (210, 240, 255), 'D': (30, 90, 200)}

ELYTRA_ITEM = [
    "....K......K....",
    "...KAK....KAK...",
    "..KAAK....KAAK..",
    "..KAWK....KWAK..",
    ".KAAWK....KWAAK.",
    ".KAAWK....KWAAK.",
    ".KAAAK....KAAAK.",
    "KAAAAK....KAAAAK",
    "KAAAK......KAAAK",
    "KAAK........KAAK",
    ".KK..........KK.",
]
ELYTRA_PAL = {'K': (40, 26, 70), 'A': (110, 80, 170), 'W': (190, 160, 240)}

JELLY = [
    "....KKKKKKK.....",
    "...KJJJJJJJK....",
    "..KJWJJJJJJJK...",
    "..KJWJJEJJEJK...",
    "..KJJJJEJJEJK...",
    "..KJJJJJJJJJK...",
    "..KKKKKKKKKKK...",
    "...J.j.J.j.J....",
    "...j.J.j.J.j....",
    "...J.j.J.j.J....",
    "....j...j...j...",
]
JELLY_PAL = {'K': (110, 40, 120), 'J': (240, 140, 220), 'W': (255, 230, 250),
             'E': (60, 20, 70), 'j': (200, 100, 200)}


# ---------------------------------------------------------------------------
# Tiles (procedural)
# ---------------------------------------------------------------------------
def _bevel(s, light, dark):
    w, h = s.get_size()
    pygame.draw.line(s, light, (0, 0), (w - 1, 0))
    pygame.draw.line(s, light, (0, 0), (0, h - 1))
    pygame.draw.line(s, dark, (0, h - 1), (w - 1, h - 1))
    pygame.draw.line(s, dark, (w - 1, 0), (w - 1, h - 1))


def make_tiles():
    T = TILE
    t = {}

    def surf():
        return pygame.Surface((T, T), pygame.SRCALPHA)

    # ground with grass top / plain dirt
    dirt = surf()
    dirt.fill((196, 124, 70))
    for (x, y) in [(3, 4), (11, 2), (7, 9), (13, 12), (2, 13), (9, 14), (5, 6)]:
        dirt.set_at((x, y), (150, 86, 46))
        dirt.set_at((x + 1, y), (150, 86, 46))
    t['dirt'] = dirt
    grass = dirt.copy()
    pygame.draw.rect(grass, (88, 200, 72), (0, 0, T, 5))
    pygame.draw.line(grass, (150, 236, 110), (0, 0), (T - 1, 0))
    for x in range(0, T, 3):
        grass.set_at((x, 5), (88, 200, 72))
        grass.set_at((x + 1, 6), (60, 150, 52))
    t['grass'] = grass

    stone = surf()
    stone.fill((150, 150, 170))
    _bevel(stone, (210, 210, 228), (84, 84, 104))
    pygame.draw.rect(stone, (120, 120, 140), (4, 4, 8, 8), 1)
    t['S'] = stone

    brick = surf()
    brick.fill((206, 96, 46))
    mortar = (110, 44, 20)
    for y in (0, 4, 8, 12):
        pygame.draw.line(brick, mortar, (0, y), (T, y))
    for i, y in enumerate((0, 4, 8, 12)):
        off = 0 if i % 2 == 0 else 4
        for x in range(off, T, 8):
            pygame.draw.line(brick, mortar, (x, y), (x, y + 3))
    pygame.draw.line(brick, (250, 160, 110), (0, 1), (T, 1))
    t['B'] = brick
    t['Q'] = brick

    # star blocks (item blocks), 4 shimmer frames
    for i in range(4):
        s = surf()
        base = [(250, 184, 40), (255, 204, 70), (255, 224, 110), (255, 204, 70)][i]
        s.fill(base)
        _bevel(s, (255, 244, 180), (176, 104, 18))
        for (x, y) in [(2, 2), (13, 2), (2, 13), (13, 13)]:
            s.set_at((x, y), (176, 104, 18))
        cx, cy = 8, 8
        pts = []
        for k in range(10):
            r = 5.5 if k % 2 == 0 else 2.4
            a = -math.pi / 2 + k * math.pi / 5
            pts.append((cx + r * math.cos(a), cy + r * math.sin(a)))
        pygame.draw.polygon(s, (255, 255, 255), pts)
        pygame.draw.polygon(s, (190, 110, 20), pts, 1)
        t[f'star{i}'] = s

    used = surf()
    used.fill((150, 100, 60))
    _bevel(used, (190, 140, 96), (90, 56, 30))
    for (x, y) in [(2, 2), (13, 2), (2, 13), (13, 13)]:
        used.set_at((x, y), (90, 56, 30))
    t['U'] = used

    # bounce block: spring coil on magenta
    note = surf()
    note.fill((230, 96, 200))
    _bevel(note, (255, 180, 240), (140, 40, 120))
    for y in (4, 7, 10):
        pygame.draw.line(note, (255, 255, 255), (4, y), (11, y + 1))
    pygame.draw.line(note, (255, 255, 255), (4, 12), (11, 12))
    t['N'] = note

    # toggle blocks
    for key, col, dk in (('R', (232, 60, 60), (130, 20, 20)),
                         ('b', (60, 120, 240), (20, 40, 140))):
        on = surf()
        on.fill(col)
        _bevel(on, tuple(min(255, c + 70) for c in col), dk)
        pygame.draw.rect(on, dk, (4, 4, 8, 8), 1)
        t[key + '_on'] = on
        off = surf()
        for i in range(0, T, 2):
            off.set_at((i, 0), col)
            off.set_at((i, T - 1), col)
            off.set_at((0, i), col)
            off.set_at((T - 1, i), col)
        t[key + '_off'] = off

    # toggle switch: two-tone with arrows
    for state in (0, 1):
        s = surf()
        top = (232, 60, 60) if state == 0 else (60, 120, 240)
        bot = (60, 120, 240) if state == 0 else (232, 60, 60)
        s.fill(top)
        pygame.draw.polygon(s, bot, [(0, T), (T, 0), (T, T)])
        _bevel(s, (255, 255, 255), (30, 30, 50))
        pygame.draw.circle(s, (255, 255, 255), (8, 8), 3)
        pygame.draw.circle(s, (30, 30, 50), (8, 8), 3, 1)
        t[f'T{state}'] = s

    # pipes (teal metal)
    pc, pl, pd = (40, 176, 168), (140, 236, 220), (16, 96, 92)
    for key, w_off, is_top in (('[', 0, True), (']', 1, True), ('{', 0, False), ('}', 1, False)):
        s = surf()
        s.fill(pc)
        if w_off == 0:
            pygame.draw.line(s, (0, 40, 40), (0, 0), (0, T))
            pygame.draw.rect(s, pl, (3, 0, 3, T))
        else:
            pygame.draw.line(s, (0, 40, 40), (T - 1, 0), (T - 1, T))
            pygame.draw.rect(s, pd, (9, 0, 5, T))
        if is_top:
            pygame.draw.line(s, (0, 40, 40), (0, 0), (T, 0))
            pygame.draw.line(s, (0, 40, 40), (0, T - 1), (T, T - 1))
            pygame.draw.line(s, pl, (0, 1), (T, 1))
        t[key] = s

    # one-way cloud platform: outlined and shaded so it never looks like scenery
    cloud = surf()
    outline = (70, 104, 176)
    pygame.draw.ellipse(cloud, outline, (-3, -1, 22, 13))
    pygame.draw.ellipse(cloud, (255, 255, 255), (-2, 0, 20, 11))
    pygame.draw.ellipse(cloud, (196, 218, 255), (-1, 6, 18, 5))
    pygame.draw.line(cloud, (255, 255, 255), (0, 2), (T, 2))
    pygame.draw.line(cloud, outline, (0, 0), (T, 0))
    t['='] = cloud

    spikes = surf()
    for x in range(0, T, 8):
        pygame.draw.polygon(spikes, (220, 220, 230), [(x, T), (x + 4, 6), (x + 8, T)])
        pygame.draw.line(spikes, (120, 120, 140), (x + 4, 6), (x + 8, T))
    t['^'] = spikes
    return t


def _ground_pair(base, speck, top, top_hi, top_dk):
    """A plain ground tile and the same tile with a top layer (grass, crust, sand...)."""
    T = TILE
    plain = pygame.Surface((T, T), pygame.SRCALPHA)
    plain.fill(base)
    for (x, y) in [(3, 4), (11, 2), (7, 9), (13, 12), (2, 13), (9, 14), (5, 6)]:
        plain.set_at((x, y), speck)
        plain.set_at((x + 1, y), speck)
    topped = plain.copy()
    pygame.draw.rect(topped, top, (0, 0, T, 5))
    pygame.draw.line(topped, top_hi, (0, 0), (T - 1, 0))
    for x in range(0, T, 3):
        topped.set_at((x, 5), top)
        topped.set_at((x + 1, 6), top_dk)
    return plain, topped


def _stone(fill, light, dark, inner):
    s = pygame.Surface((TILE, TILE), pygame.SRCALPHA)
    s.fill(fill)
    _bevel(s, light, dark)
    pygame.draw.rect(s, inner, (4, 4, 8, 8), 1)
    return s


def make_theme_tiles():
    """Each world's own look for the ground ('dirt' / 'grass') and stone ('S')."""
    themes = {"sky": {}}
    # Ember Caverns: dark basalt with a glowing crust, scorched stone
    dirt, crust = _ground_pair((70, 50, 52), (40, 26, 28), (150, 60, 40), (255, 150, 60), (90, 30, 24))
    for (x, y) in [(4, 10), (10, 7), (12, 13)]:
        dirt.set_at((x, y), (255, 110, 40))
        crust.set_at((x, y), (255, 110, 40))
    themes["fire"] = {"dirt": dirt, "grass": crust,
                      "S": _stone((96, 70, 70), (150, 110, 100), (40, 24, 26), (255, 120, 50))}
    # Coral Deep: sand and pink coral rock
    dirt, sand = _ground_pair((214, 186, 120), (176, 146, 86), (240, 220, 150), (255, 244, 200), (196, 166, 100))
    themes["water"] = {"dirt": dirt, "grass": sand,
                       "S": _stone((226, 120, 140), (255, 180, 190), (140, 60, 80), (255, 200, 120))}
    # The Void: purple obsidian with glowing veins
    dirt, top = _ground_pair((40, 26, 60), (24, 14, 40), (100, 60, 170), (190, 140, 255), (60, 30, 110))
    themes["void"] = {"dirt": dirt, "grass": top,
                      "S": _stone((54, 34, 84), (150, 110, 230), (20, 10, 34), (120, 220, 230))}
    return themes


def make_liquids():
    """Animated water and lava: 'surface' tiles (with a wavy top) and 'deep' tiles."""
    T = TILE
    out = {}
    for name, deep, light, alpha in (("~", (40, 110, 220), (150, 210, 255), 120),
                                     ("V", (230, 70, 20), (255, 200, 60), 215)):
        surf_frames, deep_frames = [], []
        for f in range(4):
            d = pygame.Surface((T, T), pygame.SRCALPHA)
            d.fill((*deep, alpha))
            for k in range(3):
                x = (k * 6 + f * 2) % T
                y = (k * 5 + 3) % T
                d.fill((*light, alpha // 2), (x, y, 3, 1))
            deep_frames.append(d)
            s = d.copy()
            for x in range(T):
                h = 2 + round(math.sin((x + f * 4) * math.pi / 8))
                s.fill((0, 0, 0, 0), (x, 0, 1, h))
                s.set_at((x, h), (*light, min(255, alpha + 60)))
            surf_frames.append(s)
        out[name] = {"surface": surf_frames, "deep": deep_frames}
    return out


def make_coin_frames():
    frames = []
    for w in (10, 7, 3, 7):
        s = pygame.Surface((16, 16), pygame.SRCALPHA)
        r = pygame.Rect(8 - w // 2, 2, w, 12)
        pygame.draw.ellipse(s, (255, 212, 40), r)
        pygame.draw.ellipse(s, (180, 110, 10), r, 1)
        if w > 4:
            pygame.draw.line(s, (255, 250, 200), (8, 5), (8, 10))
        frames.append(s)
    return frames


def make_goal_icons():
    icons = {}
    s = pygame.Surface((16, 16), pygame.SRCALPHA)       # sun
    pygame.draw.circle(s, (255, 200, 40), (8, 8), 5)
    for k in range(8):
        a = k * math.pi / 4
        pygame.draw.line(s, (255, 150, 30), (8 + 6 * math.cos(a), 8 + 6 * math.sin(a)),
                         (8 + 8 * math.cos(a), 8 + 8 * math.sin(a)))
    icons['sun'] = s
    s = pygame.Surface((16, 16), pygame.SRCALPHA)       # moon
    pygame.draw.circle(s, (230, 230, 160), (8, 8), 6)
    pygame.draw.circle(s, (0, 0, 0, 0), (11, 6), 5)
    icons['moon'] = s
    s = pygame.Surface((16, 16), pygame.SRCALPHA)       # star
    pts = []
    for k in range(10):
        r = 7.5 if k % 2 == 0 else 3.2
        a = -math.pi / 2 + k * math.pi / 5
        pts.append((8 + r * math.cos(a), 8.5 + r * math.sin(a)))
    pygame.draw.polygon(s, (255, 240, 90), pts)
    pygame.draw.polygon(s, (200, 120, 20), pts, 1)
    icons['star'] = s
    return icons


class Assets:
    def __init__(self):
        self.pip = make_pip_frames()
        self.tiles = make_tiles()
        self.coin = make_coin_frames()
        self.goal_icons = make_goal_icons()
        nut = [grid_surface(NUTLING + f, NUT_PAL) for f in NUT_FEET]
        self.nutling = nut
        self.nutling_flat = pygame.transform.scale(nut[0], (16, 7))
        sb = [grid_surface(SHELLBACK_TOP + f, SHELL_PAL) for f in SHELLBACK_FEET]
        self.shellback = {-1: sb, 1: [flip(s) for s in sb]}
        self.shell = grid_surface(SHELL, SHELL_PAL)
        self.flapper = [grid_surface(FLAPPER_UP, BAT_PAL), grid_surface(FLAPPER_DOWN, BAT_PAL)]
        self.plant = [grid_surface(PLANT_OPEN, PLANT_PAL), grid_surface(PLANT_CLOSED, PLANT_PAL)]
        self.sunfruit = grid_surface(SUNFRUIT, SUN_PAL)
        self.ember = grid_surface(EMBER, EMBER_PAL)
        self.feather = grid_surface(FEATHER_ITEM, FEATHER_PAL)
        self.heart = grid_surface(HEART, HEART_PAL)
        self.fireball = []
        for k in range(4):
            s = pygame.Surface((8, 8), pygame.SRCALPHA)
            pygame.draw.circle(s, (255, 120, 20), (4, 4), 4)
            pygame.draw.circle(s, (255, 230, 90), (4 + (1 if k % 2 else -1), 4 + (1 if k > 1 else -1)), 2)
            self.fireball.append(s)
        self.theme_tiles = make_theme_tiles()
        self.liquids = make_liquids()
        self.fire_potion = grid_surface(POTION, FIRE_POTION_PAL)
        self.water_potion = grid_surface(POTION, WATER_POTION_PAL)
        self.elytra = grid_surface(ELYTRA_ITEM, ELYTRA_PAL)
        legs2 = [r.replace('J', '#').replace('j', 'J').replace('#', 'j') for r in JELLY[7:]]
        self.jelly = [grid_surface(JELLY, JELLY_PAL), grid_surface(JELLY[:7] + legs2, JELLY_PAL)]
        # cinder: a little fire sprite with eyes, two flicker frames
        self.cinder = []
        for k in range(2):
            s = pygame.Surface((16, 16), pygame.SRCALPHA)
            pygame.draw.circle(s, (230, 60, 20), (8, 9), 7)
            pygame.draw.polygon(s, (230, 60, 20), [(3, 6), (5 + k, 0), (8, 4), (11 - k, 0), (13, 6)])
            pygame.draw.circle(s, (255, 170, 40), (8, 10), 5)
            pygame.draw.circle(s, (255, 240, 140), (8, 11), 2)
            for ex in (6, 10):
                s.fill((60, 10, 0), (ex - 1, 7, 2, 3))
            self.cinder.append(s)
        # small icons for the effects shown at the top of the screen
        self.icon_fire = pygame.transform.scale(self.fire_potion, (12, 12))
        self.icon_water = pygame.transform.scale(self.water_potion, (12, 12))
