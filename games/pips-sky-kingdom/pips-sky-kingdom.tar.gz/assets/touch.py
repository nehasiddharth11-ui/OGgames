"""On-screen controls for touch screens: joystick on the left, jump on the right and
a run toggle above jump, plus attack and pause. A mouse can press them too.
Their positions and sizes live in the options, and the Settings menu can change them."""

import math

import pygame

from settings import SCREEN_W, SCREEN_H

RADIUS = {"stick": 30, "jump": 24, "run": 17, "attack": 19, "pause": 11}
LABELS = {"jump": "JUMP", "run": "RUN", "attack": "ATK"}
EDIT_NAMES = {"stick": "JOYSTICK", "jump": "JUMP", "run": "RUN TOGGLE", "attack": "ATTACK", "pause": "PAUSE"}
STICK_DEAD = 0.3
TOP_LIMIT = 18          # buttons stay below the score bar / the layout editor's tool bar


class TouchRead:
    __slots__ = ("left", "right", "up", "down", "jump", "run", "attack", "pause")

    def __init__(self):
        self.left = self.right = self.up = self.down = False
        self.jump = self.run = self.attack = self.pause = False


class TouchControls:
    def __init__(self, options):
        self.options = options
        self.pointers = {}          # finger or mouse id -> name of the button it holds
        self.stick_vec = (0.0, 0.0)
        self.run_on = False
        self.finger_seen = False
        self._cache = {}
        try:
            from pygame._sdl2 import touch as sdl_touch
            self.has_touchscreen = sdl_touch.get_num_devices() > 0
        except (ImportError, pygame.error):
            self.has_touchscreen = False

    def active(self):
        mode = self.options["touch_mode"]
        return mode == "ON" or (mode == "AUTO" and (self.has_touchscreen or self.finger_seen))

    def radius(self, name):
        return RADIUS[name] * self.options["touch"][name][2]

    def button_at(self, x, y):
        """The button under a point; a little bigger than it looks, to be easy to hit."""
        best, best_d = None, None
        for name, (bx, by, _size) in self.options["touch"].items():
            d = math.hypot(x - bx, y - by)
            if d <= self.radius(name) + 5 and (best_d is None or d < best_d):
                best, best_d = name, d
        return best

    def clamp(self, name):
        layout = self.options["touch"][name]
        r = self.radius(name)
        layout[0] = max(r, min(SCREEN_W - r, layout[0]))
        layout[1] = max(TOP_LIMIT + r, min(SCREEN_H - r, layout[1]))

    # ---- pointers ---------------------------------------------------------
    def down(self, pid, x, y):
        name = self.button_at(x, y)
        if name is None:
            return False
        self.pointers[pid] = name
        if name == "run":
            self.run_on = not self.run_on
        elif name == "stick":
            self._aim(x, y)
        return True

    def move(self, pid, x, y):
        if self.pointers.get(pid) == "stick":
            self._aim(x, y)

    def up(self, pid):
        if self.pointers.pop(pid, None) == "stick":
            self.stick_vec = (0.0, 0.0)

    def release_all(self):
        self.pointers.clear()
        self.stick_vec = (0.0, 0.0)

    def _aim(self, x, y):
        bx, by, _size = self.options["touch"]["stick"]
        r = self.radius("stick")
        vx, vy = (x - bx) / r, (y - by) / r
        length = math.hypot(vx, vy)
        if length > 1:
            vx, vy = vx / length, vy / length
        self.stick_vec = (vx, vy)

    def read(self):
        t = TouchRead()
        vx, vy = self.stick_vec
        t.left, t.right = vx < -STICK_DEAD, vx > STICK_DEAD
        t.up, t.down = vy < -0.5, vy > 0.5
        held = set(self.pointers.values())
        t.jump = "jump" in held
        t.attack = "attack" in held
        t.pause = "pause" in held
        t.run = self.run_on
        return t

    # ---- drawing ----------------------------------------------------------
    def _disc(self, r, colour, alpha, fill=None):
        """A round button; fill is how solid its middle is (half the outline's by default)."""
        fill = alpha // 2 if fill is None else fill
        key = (r, colour, alpha, fill)
        img = self._cache.get(key)
        if img is None:
            if len(self._cache) > 64:
                self._cache.clear()
            img = pygame.Surface((r * 2 + 2, r * 2 + 2), pygame.SRCALPHA)
            pygame.draw.circle(img, colour + (fill,), (r + 1, r + 1), r)
            pygame.draw.circle(img, (255, 255, 255, alpha), (r + 1, r + 1), r, 1)
            self._cache[key] = img
        return img

    def draw_button(self, surf, pixfont, name, selected=False):
        x, y, _size = self.options["touch"][name]
        r = round(self.radius(name))
        alpha = round(self.options["touch_opacity"] * 2.55)
        held = name in self.pointers.values()
        if name == "stick":
            surf.blit(self._disc(r, (40, 50, 90), alpha), (x - r - 1, y - r - 1))
            vx, vy = self.stick_vec
            knob = max(6, r * 2 // 5)
            surf.blit(self._disc(knob, (220, 230, 255), min(255, alpha + 60)),
                      (x + vx * (r - knob) - knob - 1, y + vy * (r - knob) - knob - 1))
        else:
            lit = held or (name == "run" and self.run_on)
            colour = (240, 190, 50) if lit else (40, 50, 90)
            surf.blit(self._disc(r, colour, alpha, min(255, alpha + 40) if lit else None), (x - r - 1, y - r - 1))
            if name == "pause":
                surf.fill((255, 255, 255), (x - 4, y - 4, 3, 9))
                surf.fill((255, 255, 255), (x + 2, y - 4, 3, 9))
            else:
                text = LABELS[name]
                pixfont.draw(surf, text, x - pixfont.width(text) / 2, y - 3)
        if selected:
            pygame.draw.circle(surf, (255, 220, 90), (round(x), round(y)), r + 2, 1)

    def draw(self, surf, pixfont):
        for name in self.options["touch"]:
            self.draw_button(surf, pixfont, name)
