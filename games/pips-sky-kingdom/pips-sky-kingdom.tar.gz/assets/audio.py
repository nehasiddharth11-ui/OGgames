"""Web version of audio.py: same sounds and music, made ahead of time as small files
(by build_web.py), so the browser doesn't have to download numpy or generate them."""

import os

import pygame

FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), "sounds")


class Audio:
    def __init__(self):
        self.enabled = pygame.mixer.get_init() is not None
        self.muted = False
        self.current = None
        self.music = {}             # songs are only unpacked when first played
        self.music_volume = 1.0
        if not self.enabled:
            return
        pygame.mixer.set_num_channels(16)
        pygame.mixer.set_reserved(1)
        self.music_channel = pygame.mixer.Channel(0)
        self.sfx = {}
        for name in os.listdir(FOLDER):
            if name.startswith("sfx_"):
                self.sfx[name[4:-4]] = pygame.mixer.Sound(os.path.join(FOLDER, name))

    def _song(self, name):
        song = self.music.get(name)
        if song is None:
            song = pygame.mixer.Sound(os.path.join(FOLDER, f"mus_{name}.ogg"))
            song.set_volume(self.music_volume)
            self.music[name] = song
        return song

    def set_volumes(self, master, music, sfx):
        if not self.enabled:
            return
        self.music_volume = master * music / 10000
        for sound in self.music.values():
            sound.set_volume(self.music_volume)
        for sound in self.sfx.values():
            sound.set_volume(master * sfx / 10000)

    def play(self, name):
        if self.enabled and not self.muted and name in self.sfx:
            self.sfx[name].play()

    def play_music(self, name, loop=True):
        if not self.enabled:
            return
        if name == self.current and self.music_channel.get_busy():
            return
        self.current = name
        self.music_channel.stop()
        if not self.muted:
            self.music_channel.play(self._song(name), loops=-1 if loop else 0)

    def stop_music(self):
        if self.enabled:
            self.music_channel.stop()
        self.current = None

    def pause_music(self, paused):
        if self.enabled:
            if paused:
                self.music_channel.pause()
            else:
                self.music_channel.unpause()

    def toggle_mute(self):
        self.muted = not self.muted
        if not self.enabled:
            return
        if self.muted:
            self.music_channel.stop()
        elif self.current:
            name, self.current = self.current, None
            self.play_music(name)
