"""NES-style chiptune synthesizer. All music and sounds are original."""

import numpy as np
import pygame

SR = 44100
NOTE_INDEX = {'C': 0, 'C#': 1, 'D': 2, 'D#': 3, 'E': 4, 'F': 5, 'F#': 6,
              'G': 7, 'G#': 8, 'A': 9, 'A#': 10, 'B': 11}


def note_freq(name):
    pitch, octave = name[:-1], int(name[-1])
    midi = 12 * (octave + 1) + NOTE_INDEX[pitch]
    return 440.0 * 2 ** ((midi - 69) / 12)


# ---------------------------------------------------------------------------
# Oscillators
# ---------------------------------------------------------------------------
def _phase(freq, n):
    if np.isscalar(freq):
        return (np.arange(n) * freq / SR) % 1.0
    return np.cumsum(freq / SR) % 1.0


def square(freq, n, duty=0.5):
    return np.where(_phase(freq, n) < duty, 1.0, -1.0)


def triangle(freq, n):
    return 2.0 * np.abs(2.0 * _phase(freq, n) - 1.0) - 1.0


def noise(n, period=1):
    """NES-ish noise: random levels held for `period` samples."""
    vals = np.random.uniform(-1, 1, n // period + 1)
    return np.repeat(vals, period)[:n]


def envelope(n, attack=0.004, decay=0.07, sustain=0.65, release=0.03):
    env = np.full(n, sustain)
    a = min(n, int(attack * SR))
    d = min(n - a, int(decay * SR))
    r = min(n, int(release * SR))
    if a:
        env[:a] = np.linspace(0, 1, a)
    if d:
        env[a:a + d] = np.linspace(1, sustain, d)
    if r:
        env[n - r:] *= np.linspace(1, 0, r)
    return env


def sweep(f0, f1, dur, wave="square", duty=0.5, vol=0.5, curve=1.0):
    n = int(dur * SR)
    t = np.linspace(0, 1, n) ** curve
    freq = f0 + (f1 - f0) * t
    if wave == "square":
        w = square(freq, n, duty)
    else:
        w = triangle(freq, n)
    return w * np.linspace(1, 0.15, n) * vol


def tone_seq(notes, step, wave="square", duty=0.5, vol=0.45):
    parts = []
    for nm in notes:
        n = int(step * SR)
        if nm == 'r':
            parts.append(np.zeros(n))
            continue
        f = note_freq(nm)
        w = square(f, n, duty) if wave == "square" else triangle(f, n)
        parts.append(w * envelope(n, decay=0.03, sustain=0.6) * vol)
    return np.concatenate(parts)


# ---------------------------------------------------------------------------
# Music sequencer
# ---------------------------------------------------------------------------
def parse_track(bars):
    """Bars of 8 eighth-note tokens. '.' holds the previous note, 'r' rests."""
    events = []
    step = 0
    for bar in bars:
        for tok in bar.split():
            if tok == '.':
                if events and events[-1][2] is not None and events[-1][0] + events[-1][1] == step:
                    events[-1][1] += 1
            elif tok == 'r':
                pass
            else:
                events.append([step, 1, tok])
            step += 1
    return events, step


def _polyblep(t, dt):
    """Smooths the instant jump of a square wave over one sample: removes the
    harsh 'buzz' (aliasing) plain square waves make on high notes."""
    out = np.zeros_like(t)
    m = t < dt
    x = t[m] / dt
    out[m] = x + x - x * x - 1.0
    m = t > 1.0 - dt
    x = (t[m] - 1.0) / dt
    out[m] = x * x + x + x + 1.0
    return out


def clean_square(freq, n, duty=0.5):
    ph = _phase(freq, n)
    dt = freq / SR
    return (np.where(ph < duty, 1.0, -1.0) + _polyblep(ph, dt)
            - _polyblep((ph - duty) % 1.0, dt))


def render_voice(bars, bpm, wave, vol, duty=0.5, sustain=0.65, total_steps=None):
    events, steps = parse_track(bars)
    step_n = int(SR * 60 / bpm / 2)
    total = (total_steps or steps) * step_n
    buf = np.zeros(total)
    for start, length, name in events:
        n = length * step_n
        f = note_freq(name)
        if wave == "square":
            w = clean_square(f, n, duty)
        else:
            w = triangle(f, n)
        w = w * envelope(n, sustain=sustain) * vol
        s = start * step_n
        buf[s:s + n] += w[:max(0, total - s)]
    return buf


def render_drums(pattern_bars, bpm, vol):
    step_n = int(SR * 60 / bpm / 2)
    total = sum(len(b.split()) for b in pattern_bars) * step_n
    buf = np.zeros(total)
    i = 0
    for bar in pattern_bars:
        for tok in bar.split():
            s = i * step_n
            if tok == 'k':
                n = int(0.11 * SR)
                f = np.linspace(140, 45, n)
                w = triangle(f, n) * np.linspace(1, 0, n) ** 1.5
            elif tok == 's':
                n = int(0.10 * SR)
                w = noise(n, 2) * np.linspace(1, 0, n) ** 2 * 0.8
            elif tok == 'h':
                n = int(0.03 * SR)
                w = noise(n, 1) * np.linspace(1, 0, n) * 0.35
            else:
                w = None
            if w is not None:
                end = min(total, s + len(w))
                buf[s:end] += w[:end - s] * vol
            i += 1
    return buf


def bass_from_chords(chords):
    """Bouncy root/octave/fifth bass line, one chord per bar."""
    bars = []
    for ch in chords:
        root = ch.rstrip('m')
        oct3, oct2 = root + '3', root + '2'
        fifth = FIFTHS[root] + ('2' if NOTE_INDEX[FIFTHS[root]] > NOTE_INDEX[root] else '3')
        bars.append(f"{oct2} . {oct3} r {fifth} . {oct3} r")
    return bars


FIFTHS = {'C': 'G', 'D': 'A', 'E': 'B', 'F': 'C', 'G': 'D', 'A': 'E', 'B': 'F#'}

# "Meadow March" - main theme (original composition)
MAIN_CHORDS = ["C", "Am", "F", "G", "C", "Am", "F", "G",
               "F", "G", "Em", "Am", "F", "G", "C", "C"]
MAIN_LEAD = [
    "E5 . G5 C6 . G5 E5 G5",
    "A5 . . G5 E5 . C5 D5",
    "F5 . A5 C6 . A5 F5 A5",
    "G5 . . . B4 C5 D5 r",
    "E5 . G5 C6 . D6 E6 .",
    "D6 C6 A5 . E5 . A5 B5",
    "C6 . A5 F5 G5 . A5 F5",
    "G5 . . . r . r r",
    "A5 r A5 C6 r A5 G5 F5",
    "G5 r G5 B5 r G5 F5 D5",
    "E5 . G5 . B5 . G5 E5",
    "A5 . . . C6 B5 A5 G5",
    "F5 A5 C6 F6 . E6 D6 C6",
    "D6 . B5 G5 . A5 B5 D6",
    "C6 . G5 E5 G5 . E5 D5",
    "C5 . . . r . r r",
]
MAIN_HARMONY = [
    "C5 . . . E5 . . .", "C5 . . . E5 . . .", "A4 . . . C5 . . .", "B4 . . . D5 . . .",
    "C5 . . . G5 . . .", "A4 . . . C5 . . .", "A4 . . . C5 . . .", "B4 . D5 . B4 . r r",
    "C5 . . . A4 . . .", "D5 . . . B4 . . .", "B4 . . . G4 . . .", "C5 . . . E5 . . .",
    "A4 . . . C5 . . .", "B4 . . . D5 . . .", "E5 . . . C5 . . .", "E4 . G4 . C5 . r r",
]
MAIN_DRUMS = ["k h s h k k s h"] * 15 + ["k h s h s s s s"]

# "Cloud Climb" - sky theme (original composition)
SKY_CHORDS = ["G", "D", "Em", "C", "G", "D", "C", "D"]
SKY_LEAD = [
    "B5 . D6 . G6 . D6 B5",
    "A5 . F#5 . D5 . A5 .",
    "G5 . B5 . E6 . D6 B5",
    "C6 . . E6 D6 C6 B5 A5",
    "B5 D6 G6 . F#6 . E6 D6",
    "A5 . . F#5 A5 . D6 .",
    "E6 . D6 C6 B5 . A5 .",
    "A5 . B5 . C6 . F#5 .",
]
SKY_HARMONY = [
    "G4 B4 D5 B4 G4 B4 D5 B4", "F#4 A4 D5 A4 F#4 A4 D5 A4",
    "G4 B4 E5 B4 G4 B4 E5 B4", "G4 C5 E5 C5 G4 C5 E5 C5",
    "G4 B4 D5 B4 G4 B4 D5 B4", "F#4 A4 D5 A4 F#4 A4 D5 A4",
    "G4 C5 E5 C5 G4 C5 E5 C5", "F#4 A4 D5 A4 F#4 A4 C5 A4",
]
SKY_DRUMS = ["k h h s h k s h"] * 7 + ["k s k s s s s s"]

# "Magma March" - Ember Caverns theme (original composition)
FIRE_CHORDS = ["Dm", "C", "Am", "Dm", "F", "C", "A", "Dm"]
FIRE_LEAD = [
    "D5 . F5 A5 . F5 D5 F5",
    "E5 . G5 A5 . G5 E5 C5",
    "C5 . E5 G5 . E5 C5 E5",
    "D5 . E5 F5 G5 . E5 .",
    "A5 . A5 G5 F5 . E5 F5",
    "G5 . G5 F5 E5 . D5 E5",
    "F5 . E5 D5 E5 . C#5 .",
    "D5 . . . r . r r",
]
FIRE_HARMONY = [
    "F4 . . . A4 . . .", "E4 . . . G4 . . .", "E4 . . . A4 . . .", "F4 . . . A4 . . .",
    "A4 . . . C5 . . .", "G4 . . . C5 . . .", "A4 . . . C#5 . . .", "F4 . A4 . D5 . r r",
]
FIRE_DRUMS = ["k h s h k s s h"] * 7 + ["k s k s s s s s"]

# "Coral Lullaby" - Coral Deep theme (original composition)
WATER_CHORDS = ["C", "Am", "F", "G", "C", "Em", "F", "G"]
WATER_LEAD = [
    "E5 . . G5 . . C6 .",
    "A5 . . E5 . . C5 .",
    "F5 . A5 . C6 . A5 .",
    "G5 . . . D5 . . .",
    "E5 . G5 . C6 . E6 .",
    "B5 . . G5 . . E5 .",
    "F5 . A5 . C6 . D6 .",
    "C6 . . . r . r r",
]
WATER_HARMONY = [
    "C4 E4 G4 E4 C4 E4 G4 E4", "A3 C4 E4 C4 A3 C4 E4 C4", "F3 A3 C4 A3 F3 A3 C4 A3",
    "G3 B3 D4 B3 G3 B3 D4 B3", "C4 E4 G4 E4 C4 E4 G4 E4", "E3 G3 B3 G3 E3 G3 B3 G3",
    "F3 A3 C4 A3 F3 A3 C4 A3", "G3 B3 D4 B3 G3 B3 D4 B3",
]
WATER_DRUMS = ["k r h r s r h r"] * 8

# "Starless" - The Void theme (original composition)
VOID_CHORDS = ["Am", "F", "Dm", "E", "Am", "F", "E", "E"]
VOID_LEAD = [
    "A5 . . . E5 . . .",
    "F5 . . . C5 . A4 .",
    "D5 . F5 . A5 . . .",
    "G#5 . . . E5 . . .",
    "A5 . C6 . E6 . . .",
    "F6 . E6 . C6 . A5 .",
    "B5 . . . G#5 . . .",
    "E5 . . . r . r r",
]
VOID_HARMONY = [
    "A4 . . . C5 . . .", "A4 . . . C5 . . .", "F4 . . . A4 . . .", "B4 . . . D5 . . .",
    "C5 . . . E5 . . .", "A4 . . . C5 . . .", "G#4 . . . B4 . . .", "G#4 . . . B4 . . .",
]
VOID_DRUMS = ["k r r h s r r h"] * 8

# fanfare for beating all four worlds
WIN_LEAD = ["C5 E5 G5 C6 E6 G6 . .", "A5 . B5 . C6 . D6 .", "E6 . . . G6 . . .", "C7 . . . . . r r"]
WIN_BASS = ["C3 . . . C3 . . .", "F2 . . . G2 . . .", "A2 . . . G2 . . .", "C3 . . . . . r r"]

CLEAR_LEAD =["C5 E5 G5 C6 . G5 C6 E6", ". . G6 . . . . .", "F6 . E6 . D6 . C6 .", "C6 . . . . . r r"]
CLEAR_BASS = ["C3 . . . C3 . . .", "C3 . . . G2 . . .", "F2 . . . G2 . . .", "C3 . . . . . r r"]
DEATH_LEAD = ["C6 G5 E5 C5 r r r r", "D#5 . D5 . C#5 . C5 .", ". . . . r r r r"]
GAMEOVER_LEAD = ["E5 . C5 . A4 . . .", "F4 G4 A4 . G4 . . .", "E4 . . . . . r r"]
GAMEOVER_BASS = ["A2 . . . A2 . . .", "F2 . . . G2 . . .", "C2 . . . . . r r"]


def mix_song(lead, harmony, bass, drums, bpm, duty_lead=0.25):
    parts = [render_voice(lead, bpm, "square", 0.16, duty=duty_lead, sustain=0.7)]
    steps = parse_track(lead)[1]
    if harmony:
        parts.append(render_voice(harmony, bpm, "square", 0.07, duty=0.5, sustain=0.5, total_steps=steps))
    if bass:
        parts.append(render_voice(bass, bpm, "triangle", 0.30, sustain=0.9, total_steps=steps))
    if drums:
        d = render_drums(drums, bpm, 0.22)
        parts.append(d)
    n = max(len(p) for p in parts)
    out = np.zeros(n)
    for p in parts:
        out[:len(p)] += p
    # keep the loudest moment below full scale instead of chopping it off
    peak = np.abs(out).max()
    if peak > 0.8:
        out *= 0.8 / peak
    return out


# ---------------------------------------------------------------------------
# Sound effects
# ---------------------------------------------------------------------------
def build_sfx():
    s = {}
    s["jump"] = sweep(260, 720, 0.14, duty=0.5, vol=0.35, curve=0.6)
    s["coin"] = np.concatenate([tone_seq(["B5"], 0.05, duty=0.5, vol=0.35),
                                tone_seq(["E6"], 0.22, duty=0.5, vol=0.35) * np.linspace(1, 0, int(0.22 * SR))])
    s["stomp"] = sweep(640, 160, 0.10, duty=0.5, vol=0.45)
    s["bump"] = sweep(180, 90, 0.08, wave="triangle", vol=0.8)
    s["break"] = np.concatenate([noise(int(0.25 * SR), 3) * np.linspace(1, 0, int(0.25 * SR)) * 0.5])
    s["powerup"] = tone_seq(["C5", "E5", "G5", "C6", "D5", "F#5", "A5", "D6", "E5", "G#5", "B5", "E6"],
                            0.035, duty=0.25, vol=0.35)
    s["appear"] = sweep(200, 820, 0.35, duty=0.25, vol=0.3, curve=1.4)
    n = int(0.5 * SR)
    vib = 1 + 0.06 * np.sin(np.arange(n) / SR * 2 * np.pi * 18)
    s["powerdown"] = square(np.linspace(900, 160, n) * vib, n, 0.5) * np.linspace(1, 0, n) * 0.35
    s["fireball"] = sweep(900, 300, 0.07, duty=0.25, vol=0.3)
    s["kick"] = sweep(1000, 420, 0.06, duty=0.5, vol=0.4)
    s["oneup"] = tone_seq(["C6", "G6", "C7", "E7", "G7"], 0.07, duty=0.5, vol=0.3)
    s["checkpoint"] = tone_seq(["G5", "B5", "D6", "G6", "B6"], 0.06, duty=0.25, vol=0.33)
    s["toggle"] = np.concatenate([tone_seq(["A5"], 0.04, vol=0.3), tone_seq(["E5"], 0.04, vol=0.3),
                                  tone_seq(["A5"], 0.04, vol=0.3), tone_seq(["E6"], 0.08, vol=0.3)])
    s["bounce"] = sweep(240, 940, 0.16, wave="triangle", vol=0.8, curve=0.5)
    n = int(0.08 * SR)
    s["flap"] = noise(n, 6) * np.sin(np.linspace(0, np.pi, n)) * 0.3
    s["spin"] = sweep(500, 1300, 0.12, duty=0.125, vol=0.25)
    s["pause"] = np.concatenate([tone_seq(["E6", "r", "E6", "r", "C7"], 0.05, vol=0.3)])
    s["tick"] = tone_seq(["A6"], 0.025, duty=0.25, vol=0.2)
    s["shell_hit"] = sweep(1200, 600, 0.05, duty=0.5, vol=0.35)
    # a soft thud for landing after a long drop
    n = int(0.05 * SR)
    thud = sweep(170, 55, 0.07, wave="triangle", vol=0.45)
    thud[:n] += noise(n, 2) * np.linspace(1, 0, n) ** 2 * 0.12
    s["land"] = thud
    # burnt by lava or fire: a hiss and a falling tone
    n = int(0.45 * SR)
    s["burn"] = (noise(n, 2) * np.linspace(1, 0, n) ** 1.5 * 0.35
                 + sweep(700, 90, 0.45, duty=0.5, vol=0.3))
    n = int(0.2 * SR)
    s["splash"] = noise(n, 3) * np.sin(np.linspace(0, np.pi, n)) ** 2 * 0.4
    n = int(0.07 * SR)
    s["swim"] = noise(n, 8) * np.sin(np.linspace(0, np.pi, n)) * 0.18
    s["potion"] = tone_seq(["E5", "G#5", "B5", "E6", "G#6", "B6"], 0.045, duty=0.25, vol=0.3)
    s["air"] = tone_seq(["A5", "r", "A5"], 0.06, duty=0.5, vol=0.25)
    return s


def build_clean_sfx(oversample=4):
    """The effects rendered at 4x the sample rate, then averaged back down:
    this removes most of the harsh buzz of the square waves. Noise is held 4x
    longer at the high rate, so it keeps its original character."""
    global SR, noise
    sr, plain_noise = SR, noise
    SR = sr * oversample
    noise = lambda n, period=1: plain_noise(n, period * oversample)  # noqa: E731
    try:
        hi = build_sfx()
    finally:
        SR, noise = sr, plain_noise
    out = {}
    for name, x in hi.items():
        x = x[:len(x) // oversample * oversample]
        out[name] = x.reshape(-1, oversample).mean(axis=1)
    return out


def to_sound(mono, volume=1.0):
    mono = np.clip(mono * volume, -1, 1)
    pcm = (mono * 32000).astype(np.int16)
    stereo = np.ascontiguousarray(np.column_stack([pcm, pcm]))
    return pygame.sndarray.make_sound(stereo)


class Audio:
    def __init__(self):
        self.enabled = pygame.mixer.get_init() is not None
        self.muted = False
        self.current = None
        if not self.enabled:
            return
        pygame.mixer.set_num_channels(16)
        pygame.mixer.set_reserved(1)
        self.music_channel = pygame.mixer.Channel(0)
        self.sfx = {k: to_sound(v) for k, v in build_clean_sfx().items()}
        main = mix_song(MAIN_LEAD, MAIN_HARMONY, bass_from_chords(MAIN_CHORDS), MAIN_DRUMS, 150)
        sky = mix_song(SKY_LEAD, SKY_HARMONY, bass_from_chords(SKY_CHORDS), SKY_DRUMS, 165, duty_lead=0.125)
        clear = mix_song(CLEAR_LEAD, None, CLEAR_BASS, None, 170)
        death = mix_song(DEATH_LEAD, None, None, None, 160, duty_lead=0.5)
        over = mix_song(GAMEOVER_LEAD, None, GAMEOVER_BASS, None, 100)
        fire = mix_song(FIRE_LEAD, FIRE_HARMONY, bass_from_chords(FIRE_CHORDS), FIRE_DRUMS, 168)
        water = mix_song(WATER_LEAD, WATER_HARMONY, bass_from_chords(WATER_CHORDS), WATER_DRUMS, 112,
                         duty_lead=0.5)
        void = mix_song(VOID_LEAD, VOID_HARMONY, bass_from_chords(VOID_CHORDS), VOID_DRUMS, 104,
                        duty_lead=0.125)
        win = mix_song(WIN_LEAD, None, WIN_BASS, None, 150)
        self.music = {"main": to_sound(main, 0.9), "sky": to_sound(sky, 0.9),
                      "fire": to_sound(fire, 0.9), "water": to_sound(water, 0.9),
                      "void": to_sound(void, 0.9), "win": to_sound(win),
                      "clear": to_sound(clear), "death": to_sound(death),
                      "gameover": to_sound(over)}

    def set_volumes(self, master, music, sfx):
        """Volumes from the Settings menu, each 0-100. They last for every later play too."""
        if not self.enabled:
            return
        for sound in self.music.values():
            sound.set_volume(master * music / 10000)
        for sound in self.sfx.values():
            sound.set_volume(master * sfx / 10000)

    def play(self, name):
        if self.enabled and not self.muted and name in self.sfx:
            self.sfx[name].play()

    def play_music(self, name, loop=True):
        if not self.enabled:
            return
        if name == self.current and self.music_channel.get_busy():
            return
        self.current = name
        self.music_channel.stop()
        if not self.muted:
            self.music_channel.play(self.music[name], loops=-1 if loop else 0)

    def stop_music(self):
        if self.enabled:
            self.music_channel.stop()
        self.current = None

    def pause_music(self, paused):
        if self.enabled:
            if paused:
                self.music_channel.pause()
            else:
                self.music_channel.unpause()

    def toggle_mute(self):
        self.muted = not self.muted
        if not self.enabled:
            return
        if self.muted:
            self.music_channel.stop()
        elif self.current:
            name, self.current = self.current, None
            self.play_music(name)
